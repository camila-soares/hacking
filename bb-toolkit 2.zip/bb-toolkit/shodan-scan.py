#!/usr/bin/env python3
"""
shodan_scan.py — Enriquecimento de hosts via Shodan API

Enriquece os hosts encontrados no recon com:
  - Portas e serviços abertos
  - Banners de serviço
  - CVEs conhecidas
  - Geolocalização (país, cidade, org, ISP)
  - Sistema operacional detectado

Uso:
  pip install shodan
  python3 shodan_scan.py --key SUA_API_KEY pasta_recon/
  python3 shodan_scan.py --key SUA_API_KEY --hosts "1.2.3.4,5.6.7.8"
  python3 shodan_scan.py --key SUA_API_KEY --hosts-file ips.txt

API Key gratuita em: https://account.shodan.io
  - Plano free: 1 req/s, sem scan ativo, só pesquisa passiva
  - Plano pago: scan ativo, histórico, mais resultados
"""

from __future__ import annotations

import argparse
import json
import socket
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

# ── verificar dependência ─────────────────────────────────────
try:
    import shodan
except ImportError:
    print("[✘] shodan não instalado.")
    print("    pip install shodan")
    sys.exit(1)

# ── argumentos ────────────────────────────────────────────────
parser = argparse.ArgumentParser(
    description="Enriquece hosts do recon com dados do Shodan"
)

group = parser.add_mutually_exclusive_group(required=True)
group.add_argument("pasta",      nargs="?", help="Pasta de saída do recon-full.sh")
group.add_argument("--hosts",    help="IPs ou domínios separados por vírgula")
group.add_argument("--hosts-file", help="Arquivo com IPs/domínios (um por linha)")

parser.add_argument("--key",     required=True, help="Shodan API key")
parser.add_argument("--output",  default=".",   help="Pasta para salvar resultados")
parser.add_argument("--delay",   type=float, default=1.1,
                    help="Delay entre queries (padrão 1.1s — respeita rate limit gratuito)")
parser.add_argument("--max",     type=int, default=50,
                    help="Máximo de hosts para consultar (padrão 50)")
args = parser.parse_args()

OUTPUT_DIR = Path(args.output)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ── inicializar cliente ───────────────────────────────────────
try:
    api = shodan.Shodan(args.key)
    info = api.info()
    print(f"\n[✔] Shodan conectado — créditos: {info.get('query_credits', '?')} queries restantes")
except shodan.APIError as e:
    print(f"[✘] Erro de autenticação Shodan: {e}")
    sys.exit(1)

# ── coletar lista de hosts ────────────────────────────────────
hosts_entrada: list[str] = []

if args.hosts:
    hosts_entrada = [h.strip() for h in args.hosts.split(",") if h.strip()]

elif args.hosts_file:
    hosts_entrada = [
        l.strip() for l in Path(args.hosts_file).read_text(errors="ignore").splitlines()
        if l.strip() and not l.startswith("#")
    ]

else:
    # lê hosts ativos da pasta do recon
    pasta = Path(args.pasta)
    ativos_file = pasta / "hosts" / "ativos.txt"

    if not ativos_file.exists():
        print(f"[✘] {ativos_file} não encontrado — rode recon-full.sh primeiro")
        sys.exit(1)

    for linha in ativos_file.read_text(errors="ignore").splitlines():
        host = linha.split()[0] if linha.strip() else ""
        if host.startswith("http"):
            host = host.replace("https://", "").replace("http://", "").split("/")[0]
        if host:
            hosts_entrada.append(host)

hosts_entrada = list(dict.fromkeys(hosts_entrada))[:args.max]
print(f"[→] {len(hosts_entrada)} hosts para consultar no Shodan\n")

# ── resolver domínios para IP ─────────────────────────────────
def resolver_ip(host: str) -> Optional[str]:
    try:
        return socket.gethostbyname(host)
    except Exception:
        return None

# ── consultar Shodan ──────────────────────────────────────────
resultados: list[dict] = []
nao_encontrados: list[str] = []
cvés_totais: list[dict] = []

SEVERIDADE_COR = {
    "critical": "🔴",
    "high":     "🟠",
    "medium":   "🟡",
    "low":      "🔵",
}

ip_cache: dict = {}  # ip -> {"dados": ...} ou {"erro": ...} — evita consultar o mesmo IP 2x

for i, host in enumerate(hosts_entrada, 1):
    ip = resolver_ip(host) if not host.replace(".", "").isdigit() else host

    if not ip:
        print(f"  [{i}/{len(hosts_entrada)}] {host} — não resolveu IP")
        nao_encontrados.append(host)
        continue

    print(f"  [{i}/{len(hosts_entrada)}] {host} ({ip})")
    # ── busca no Shodan com dedup por IP (economiza query credits) ──
    if ip in ip_cache:
        cache = ip_cache[ip]
        if "erro" in cache:
            if cache["erro"] == "sem_dados":
                print(f"    sem dados no Shodan para {ip} (cache)")
                nao_encontrados.append(host)
            else:
                print(f"    erro Shodan: {cache['erro']} (cache)")
            continue
        dados = cache["dados"]
        print(f"    \u21ba reaproveitado do IP j\u00e1 consultado (0 query)")
    else:
        time.sleep(args.delay)
        try:
            dados = api.host(ip)
            ip_cache[ip] = {"dados": dados}
        except shodan.APIError as e:
            if "No information available" in str(e):
                ip_cache[ip] = {"erro": "sem_dados"}
                print(f"    sem dados no Shodan para {ip}")
                nao_encontrados.append(host)
            else:
                ip_cache[ip] = {"erro": str(e)}
                print(f"    erro Shodan: {e}")
            continue

    # ── portas e serviços ─────────────────────────────────
    portas = sorted(set(dados.get("ports", [])))

    servicos = []
    for item in dados.get("data", []):
        svc = {
            "porta":     item.get("port"),
            "protocolo": item.get("transport", "tcp"),
            "produto":   item.get("product", ""),
            "versao":    item.get("version", ""),
            "banner":    (item.get("data") or "")[:200].strip(),
            "modulo":    item.get("_shodan", {}).get("module", ""),
        }
        servicos.append(svc)

    # ── CVEs ─────────────────────────────────────────────
    cves = []
    for item in dados.get("data", []):
        for cve_id, cve_info in item.get("vulns", {}).items():
            entrada_cve = {
                "cve":        cve_id,
                "cvss":       cve_info.get("cvss", 0),
                "severidade": cve_info.get("summary", ""),
                "referencia": f"https://nvd.nist.gov/vuln/detail/{cve_id}",
                "host":       host,
                "ip":         ip,
                "porta":      item.get("port"),
            }
            cves.append(entrada_cve)
            cvés_totais.append(entrada_cve)

    # ordenar CVEs por CVSS
    cves.sort(key=lambda c: float(c.get("cvss") or 0), reverse=True)

    # ── geolocalização ────────────────────────────────────
    geo = {
        "pais":   dados.get("country_name", ""),
        "cidade": dados.get("city", ""),
        "regiao": dados.get("region_code", ""),
        "org":    dados.get("org", ""),
        "isp":    dados.get("isp", ""),
        "asn":    dados.get("asn", ""),
        "lat":    dados.get("latitude"),
        "lon":    dados.get("longitude"),
    }

    resultado = {
        "host":          host,
        "ip":            ip,
        "os":            dados.get("os"),
        "ultima_atualizacao": dados.get("last_update"),
        "portas":        portas,
        "servicos":      servicos,
        "cves":          cves,
        "total_cves":    len(cves),
        "geo":           geo,
        "hostnames":     dados.get("hostnames", []),
        "dominios":      dados.get("domains", []),
        "tags":          dados.get("tags", []),
    }
    resultados.append(resultado)

    # ── exibir resumo ─────────────────────────────────────
    print(f"    portas    : {', '.join(map(str, portas)) or 'nenhuma'}")
    print(f"    SO        : {dados.get('os') or 'desconhecido'}")
    print(f"    org       : {geo['org']}")
    print(f"    país      : {geo['pais']} / {geo['cidade']}")
    if cves:
        top = cves[0]
        emoji = SEVERIDADE_COR.get(
            "critical" if float(top.get("cvss") or 0) >= 9 else
            "high"     if float(top.get("cvss") or 0) >= 7 else
            "medium"   if float(top.get("cvss") or 0) >= 4 else "low",
            "⚪"
        )
        print(f"    CVEs      : {len(cves)} — topo: {emoji} {top['cve']} (CVSS {top['cvss']})")
# ── relatório JSON completo ───────────────────────────────────
relatorio_json = OUTPUT_DIR / "shodan_report.json"
relatorio_json.write_text(
    json.dumps({
        "data":            datetime.now().isoformat(),
        "total_hosts":     len(hosts_entrada),
        "encontrados":     len(resultados),
        "nao_encontrados": nao_encontrados,
        "total_cves":      len(cvés_totais),
        "resultados":      resultados,
    }, indent=2, ensure_ascii=False),
    encoding="utf-8"
)

# ── relatório de CVEs em texto ────────────────────────────────
cves_txt = OUTPUT_DIR / "shodan_cves.txt"
cvés_totais.sort(key=lambda c: float(c.get("cvss") or 0), reverse=True)
with open(cves_txt, "w") as f:
    f.write(f"# CVEs encontradas via Shodan — {datetime.now().strftime('%d/%m/%Y')}\n")
    f.write(f"# Total: {len(cvés_totais)}\n\n")
    for c in cvés_totais:
        cvss = float(c.get("cvss") or 0)
        emoji = "🔴" if cvss >= 9 else "🟠" if cvss >= 7 else "🟡" if cvss >= 4 else "🔵"
        f.write(f"{emoji} {c['cve']:20s}  CVSS {cvss:4.1f}  {c['host']}:{c['porta']}\n")
        f.write(f"   {c['referencia']}\n\n")

# ── relatório de portas em texto ──────────────────────────────
portas_txt = OUTPUT_DIR / "shodan_portas.txt"
with open(portas_txt, "w") as f:
    f.write(f"# Portas e serviços — Shodan\n\n")
    for r in resultados:
        f.write(f"{'='*50}\n")
        f.write(f"Host : {r['host']} ({r['ip']})\n")
        f.write(f"OS   : {r['os'] or 'desconhecido'}\n")
        f.write(f"Org  : {r['geo']['org']} — {r['geo']['pais']}\n")
        f.write(f"Portas: {', '.join(map(str, r['portas']))}\n")
        for svc in r["servicos"]:
            if svc["banner"]:
                f.write(f"\n  [{svc['porta']}/{svc['protocolo']}] {svc['produto']} {svc['versao']}\n")
                f.write(f"  Banner: {svc['banner'][:100]}\n")
        f.write("\n")

# ── sumário final ─────────────────────────────────────────────
print(f"\n{'═'*55}")
print(f"  Shodan scan concluído")
print(f"  Hosts consultados  : {len(hosts_entrada)}")
print(f"  Com dados          : {len(resultados)}")
print(f"  Sem dados          : {len(nao_encontrados)}")
print(f"  CVEs encontradas   : {len(cvés_totais)}")
if cvés_totais:
    criticas = sum(1 for c in cvés_totais if float(c.get("cvss") or 0) >= 9)
    altas    = sum(1 for c in cvés_totais if 7 <= float(c.get("cvss") or 0) < 9)
    print(f"    🔴 Críticas (CVSS ≥9): {criticas}")
    print(f"    🟠 Altas    (CVSS ≥7): {altas}")
print(f"  Relatório JSON     : {relatorio_json}")
print(f"  CVEs TXT           : {cves_txt}")
print(f"  Portas TXT         : {portas_txt}")
print(f"{'═'*55}")
