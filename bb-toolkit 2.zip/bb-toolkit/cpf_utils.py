#!/usr/bin/env python3
"""
cpf_utils.py — Utilitários de CPF para testes de segurança

Funcionalidades:
  - Validar CPF
  - Gerar CPFs válidos aleatórios
  - Formatar com/sem máscara
  - Detectar campo CPF em formulários HTML
  - Lista de CPFs comuns usados em ambientes de teste

ATENÇÃO: use apenas em ambientes de teste autorizados.
CPFs reais de pessoas físicas NÃO devem ser usados em testes.
"""

from __future__ import annotations

import random
import re
from typing import Optional


# ── CPFs comuns em ambientes de teste / homologação ───────────
# Muitos sistemas gov usam esses CPFs em banco de dados de teste
CPFS_TESTE = [
    "000.000.000-00",
    "111.111.111-11",
    "222.222.222-22",
    "333.333.333-33",
    "444.444.444-44",
    "555.555.555-55",
    "666.666.666-66",
    "777.777.777-77",
    "888.888.888-88",
    "999.999.999-99",
    "123.456.789-09",   # CPF válido clássico de exemplos
    "000.000.001-91",   # usado em alguns sistemas legados
    "098.765.432-10",
    "012.345.678-90",
]

# ── nomes de campos CPF em formulários ────────────────────────
CAMPOS_CPF = [
    "cpf",
    "cpf_cnpj",
    "documento",
    "doc",
    "nr_cpf",
    "num_cpf",
    "cpf_usuario",
    "login",            # sistemas gov frequentemente usam CPF como login
    "usuario",
    "username",
    "identificacao",
    "matricula",
    "nr_documento",
    "tax_id",
]


# ─────────────────────────────────────────────────────────────
#  Validação de CPF
# ─────────────────────────────────────────────────────────────

def validar_cpf(cpf: str) -> bool:
    """
    Valida um CPF usando o algoritmo oficial dos dois dígitos verificadores.
    Aceita CPF com ou sem máscara (000.000.000-00 ou 00000000000).
    """
    # limpar
    numeros = re.sub(r"\D", "", cpf)

    if len(numeros) != 11:
        return False

    # CPFs com todos os dígitos iguais são inválidos
    if len(set(numeros)) == 1:
        return False

    def calcular_digito(parcial: str, pesos: range) -> int:
        soma = sum(int(d) * p for d, p in zip(parcial, pesos))
        resto = soma % 11
        return 0 if resto < 2 else 11 - resto

    # primeiro dígito verificador
    d1 = calcular_digito(numeros[:9], range(10, 1, -1))
    if d1 != int(numeros[9]):
        return False

    # segundo dígito verificador
    d2 = calcular_digito(numeros[:10], range(11, 1, -1))
    if d2 != int(numeros[10]):
        return False

    return True


# ─────────────────────────────────────────────────────────────
#  Formatação
# ─────────────────────────────────────────────────────────────

def formatar_cpf(cpf: str, com_mascara: bool = True) -> str:
    """
    Formata um CPF com ou sem máscara.
    com_mascara=True  → 000.000.000-00
    com_mascara=False → 00000000000
    """
    numeros = re.sub(r"\D", "", cpf)
    if len(numeros) != 11:
        return cpf  # devolve sem alterar se inválido

    if com_mascara:
        return f"{numeros[:3]}.{numeros[3:6]}.{numeros[6:9]}-{numeros[9:]}"
    return numeros


def ambos_formatos(cpf: str) -> list[str]:
    """Retorna o CPF nos dois formatos: com e sem máscara."""
    nums = re.sub(r"\D", "", cpf)
    if len(nums) != 11:
        return [cpf]
    return [
        f"{nums[:3]}.{nums[3:6]}.{nums[6:9]}-{nums[9:]}",
        nums,
    ]


# ─────────────────────────────────────────────────────────────
#  Geração de CPF válido
# ─────────────────────────────────────────────────────────────

def gerar_cpf(com_mascara: bool = True) -> str:
    """Gera um CPF válido aleatório."""
    def digito(parcial: list[int], pesos: range) -> int:
        soma = sum(d * p for d, p in zip(parcial, pesos))
        resto = soma % 11
        return 0 if resto < 2 else 11 - resto

    while True:
        base = [random.randint(0, 9) for _ in range(9)]
        # evitar sequências repetidas (inválidas por regra)
        if len(set(base)) == 1:
            continue

        d1 = digito(base, range(10, 1, -1))
        d2 = digito(base + [d1], range(11, 1, -1))
        cpf_str = "".join(map(str, base + [d1, d2]))

        if com_mascara:
            return f"{cpf_str[:3]}.{cpf_str[3:6]}.{cpf_str[6:9]}-{cpf_str[9:]}"
        return cpf_str


def gerar_lista_cpfs(quantidade: int = 20, com_mascara: bool = True) -> list[str]:
    """Gera uma lista de CPFs válidos únicos."""
    cpfs = set()
    while len(cpfs) < quantidade:
        cpfs.add(gerar_cpf(com_mascara=com_mascara))
    return list(cpfs)


# ─────────────────────────────────────────────────────────────
#  Detecção de campo CPF em HTML
# ─────────────────────────────────────────────────────────────

def detectar_campo_cpf(html: str) -> Optional[str]:
    """
    Detecta o nome do campo CPF em um formulário HTML.
    Retorna o nome do campo ou None se não encontrar.
    """
    # input com name contendo "cpf" ou "documento"
    padroes = [
        r'<input[^>]+name=["\']([^"\']*cpf[^"\']*)["\']',
        r'<input[^>]+name=["\']([^"\']*documento[^"\']*)["\']',
        r'<input[^>]+name=["\']([^"\']*identificacao[^"\']*)["\']',
        r'<input[^>]+name=["\']([^"\']*matricula[^"\']*)["\']',
    ]
    for padrao in padroes:
        m = re.search(padrao, html, re.IGNORECASE)
        if m:
            return m.group(1)

    # label com texto CPF + input próximo
    m = re.search(
        r'<label[^>]*>.*?CPF.*?</label>.*?<input[^>]+name=["\']([^"\']+)["\']',
        html, re.IGNORECASE | re.DOTALL
    )
    if m:
        return m.group(1)

    # placeholder com CPF
    m = re.search(
        r'<input[^>]+placeholder=["\'][^"\']*CPF[^"\']*["\'][^>]+name=["\']([^"\']+)["\']',
        html, re.IGNORECASE
    )
    if m:
        return m.group(1)

    return None


def detectar_formato_cpf(html: str) -> str:
    """
    Detecta se o formulário espera CPF com ou sem máscara.
    Retorna 'mascarado' ou 'numerico'.
    """
    # máscara via pattern ou placeholder
    indicadores_mascara = [
        r'pattern=["\'][^"\']*\d{3}\.[^"\']*["\']',  # pattern com ponto
        r'placeholder=["\'][0-9]{3}\.[0-9]',           # placeholder 000.
        r'data-mask=["\'][^"\']*["\']',                 # jquery mask
        r'v-mask',                                       # Vue mask
        r'ng-mask',                                      # Angular mask
        r'cpf-mask',
        r'mask="###\.###\.###-##"',
    ]
    for ind in indicadores_mascara:
        if re.search(ind, html, re.IGNORECASE):
            return "mascarado"

    # campo maxlength=11 → sem máscara
    # campo maxlength=14 → com máscara (000.000.000-00)
    m = re.search(r'<input[^>]*[Cc][Pp][Ff][^>]*maxlength=["\'](\d+)["\']', html)
    if m:
        return "mascarado" if int(m.group(1)) >= 14 else "numerico"

    return "ambos"  # tenta os dois


# ─────────────────────────────────────────────────────────────
#  Construir lista de credenciais com CPF
# ─────────────────────────────────────────────────────────────

def credenciais_cpf(
    senhas: list[str],
    cpfs_extras: Optional[list[str]] = None,
    gerar_aleatorios: int = 0,
    com_mascara: bool = True,
) -> list[tuple[str, str]]:
    """
    Monta lista de (cpf, senha) para teste.

    Args:
        senhas:           Lista de senhas para testar
        cpfs_extras:      CPFs adicionais a incluir
        gerar_aleatorios: Quantidade de CPFs aleatórios válidos a gerar
        com_mascara:      Formato do CPF (True = 000.000.000-00)

    Returns:
        Lista de tuplas (cpf, senha)
    """
    # base: CPFs de teste + extras
    todos_cpfs: list[str] = []

    for cpf in CPFS_TESTE:
        todos_cpfs.extend(ambos_formatos(cpf) if not com_mascara else [cpf])

    if cpfs_extras:
        for cpf in cpfs_extras:
            if validar_cpf(cpf):
                todos_cpfs.extend(ambos_formatos(cpf))

    if gerar_aleatorios > 0:
        todos_cpfs.extend(gerar_lista_cpfs(gerar_aleatorios, com_mascara))

    # remover duplicatas mantendo ordem
    vistos: set[str] = set()
    cpfs_unicos = []
    for c in todos_cpfs:
        nums = re.sub(r"\D", "", c)
        if nums not in vistos:
            vistos.add(nums)
            cpfs_unicos.append(formatar_cpf(c, com_mascara))

    # cruzar CPFs × senhas
    return [(cpf, senha) for cpf in cpfs_unicos for senha in senhas]


# ─────────────────────────────────────────────────────────────
#  Uso via CLI (validação e geração)
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse, sys

    parser = argparse.ArgumentParser(description="Utilitários de CPF")
    sub = parser.add_subparsers(dest="cmd")

    # validar
    p_val = sub.add_parser("validar", help="Valida um CPF")
    p_val.add_argument("cpf", help="CPF a validar (com ou sem máscara)")

    # gerar
    p_gen = sub.add_parser("gerar", help="Gera CPFs válidos aleatórios")
    p_gen.add_argument("--quantidade", type=int, default=10)
    p_gen.add_argument("--sem-mascara", action="store_true")

    # detectar
    p_det = sub.add_parser("detectar", help="Detecta campo CPF em URL")
    p_det.add_argument("url", help="URL para analisar")

    args = parser.parse_args()

    if args.cmd == "validar":
        ok = validar_cpf(args.cpf)
        fmt = formatar_cpf(args.cpf)
        print(f"  CPF : {fmt}")
        print(f"  Válido: {'✔ SIM' if ok else '✘ NÃO'}")

    elif args.cmd == "gerar":
        com_mascara = not args.sem_mascara
        print(f"Gerando {args.quantidade} CPFs válidos:")
        for cpf in gerar_lista_cpfs(args.quantidade, com_mascara):
            print(f"  {cpf}")

    elif args.cmd == "detectar":
        import requests
        requests.packages.urllib3.disable_warnings()
        resp = requests.get(args.url, verify=False, timeout=10)
        campo = detectar_campo_cpf(resp.text)
        fmt   = detectar_formato_cpf(resp.text)
        print(f"  Campo CPF: {campo or 'não detectado'}")
        print(f"  Formato  : {fmt}")

    else:
        parser.print_help()
