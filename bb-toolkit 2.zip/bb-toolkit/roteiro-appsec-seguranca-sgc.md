# Roteiro de AppSec / Bug Bounty + Checklist de Segurança do SGC

## 1. Onde está o dinheiro

| Caminho | Modelo de renda | Observação |
|---|---|---|
| **Bug bounty** | Variável, por vulnerabilidade | Ótimo pra começar sem pedir permissão a ninguém |
| **Pentest (CLT/PJ)** | Estável | Mais comum no Brasil — forte demanda em setor público e bancário |
| **AppSec / Product Security** | Estável, salário alto | Extensão natural de quem já programa Spring Boot/Angular |

**Plataformas de bug bounty:** HackerOne, Bugcrowd, Intigriti, YesWeHack, BugHunt (BR).

**Vantagem de quem já é dev:** quem escreve Spring Security, JPA e endpoints REST reconhece IDOR, injeção e falha de autorização muito mais rápido que alguém vindo de fora da programação.

**Base legal:** só testar o que se tem autorização escrita para testar. Invasão sem autorização é crime (art. 154-A do Código Penal). Bug bounty e labs resolvem isso porque o escopo já vem definido.

---

## 2. Cronograma de 6 semanas

1. **Semana 1** — Web Security Academy (PortSwigger): trilhas *Authentication* e *Access control*. Burp instalado, interceptando o próprio WebGoat.
2. **Semana 2** — *IDOR / Broken Access Control* a fundo — maior retorno em bounty e o mais fácil de reconhecer vindo de backend.
3. **Semana 3** — *Injection*: SQLi e depois command injection. Rodar sqlmap contra o DVWA para ver o que ele automatiza.
4. **Semana 4** — *XSS* (refletido, armazenado, DOM) — usar o Juice Shop (Angular) para o lado SPA.
5. **Semana 5** — *SSRF, XXE e falhas de API* (REST/GraphQL) — ponto forte natural de quem já projeta APIs.
6. **Semana 6** — Primeiro alvo real: programa público (HackerOne/Bugcrowd) com escopo largo. Escrever writeup mesmo sem achar nada — vira portfólio.

**Depois:** certificação eJPT ou Burp Suite Certified Practitioner para entrada; OSCP ou PNPT para peso no currículo.

---

## 3. Ambiente de treino (Docker, local e autorizado)

```bash
# WebGoat — Spring Boot, dá pra ler o código-fonte da falha
docker run -it -p 8080:8080 -p 9090:9090 webgoat/webgoat

# Juice Shop — SPA em Angular, falhas de front/API
docker run -d -p 3000:3000 bkimminich/juice-shop

# DVWA — fundamentos clássicos
docker run -d -p 80:80 vulnerables/web-dvwa
```

Wordlists padrão do mercado:
```bash
git clone https://github.com/danielmiessler/SecLists
```

---

## 4. Ferramentas essenciais

- **Burp Suite Community** — proxy de interceptação, ferramenta central.
- **OWASP ZAP** — alternativa open-source, boa para automação.
- **ffuf** — fuzzing de endpoints/parâmetros: `ffuf -w wordlist.txt -u https://alvo/FUZZ`
- **nuclei** — scanner por templates de CVEs conhecidas.
- **sqlmap** — automação de SQL injection (só em escopo autorizado).
- **Extensão Autorize (Burp)** — automatiza teste de controle de acesso: navega com usuário de alto privilégio, reproduz com token de baixo privilégio e sinaliza onde a resposta é idêntica.

---

## 5. Checklist de Broken Access Control / IDOR para o SGC

### 5.1 Mapeamento
Listar todo `@PathVariable` que aponta para uma entidade: `Contrato`, `Aditivo`, `TermoAditivo`, `Apostilamento`, `ItemContrato`, `Empenho`, `EmpresaContratada`, `Portaria`.

### 5.2 Perguntas por endpoint
- Existe `@PreAuthorize` ou é só `@Authenticated`?
- Além do role, existe checagem de **posse/vínculo** (o usuário é o gestor/fiscal *daquele* contrato específico)?
- GET, PUT, DELETE e POST no mesmo recurso têm a mesma checagem, ou só o GET foi protegido?

### 5.3 Teste manual com Burp
- Autenticar com dois usuários de perfis diferentes (ex. Fiscal do contrato A e Fiscal do contrato B).
- Trocar o `id` na URL do recurso de A pelo de B, reenviar com o token de A.
- Repetir para todos os verbos HTTP, não só GET.
- Testar endpoints de **download de anexo/PDF** separadamente — costumam ficar esquecidos.

### 5.4 Riscos específicos do domínio SGC
- No fluxo de Aditivo (Reativação Legal, Acréscimo etc.): o service valida o `contratoId` recebido contra o vínculo do usuário logado, ou confia no DTO vindo do frontend?
- Multi-datasource SGC/SGA: uma query read-only pode vazar dado de outra unidade se o filtro estiver só no service e não na query?
- Mass assignment: o DTO de update de `Contrato`/`Aditivo` aceita campos como `status` ou `responsavelId` que o usuário não deveria poder setar diretamente?

### 5.5 Correção recomendada
Centralizar a checagem de posse num único ponto (aspecto/interceptor ou `assertOwnership(contrato, usuario)`), em vez de repetir a lógica em cada `AditivoXService`.

---

## 6. Exemplo de código: vulnerável vs. corrigido

**Vulnerável — falta checagem em nível de objeto:**
```java
@GetMapping("/api/contratos/{id}")
public ContratoDTO buscar(@PathVariable Long id) {
    return service.buscarPorId(id); // qualquer usuário autenticado vê qualquer contrato
}
```

**Corrigido:**
```java
@GetMapping("/api/contratos/{id}")
@PreAuthorize("hasRole('GESTOR')")
public ContratoDTO buscar(@PathVariable Long id,
                          @AuthenticationPrincipal Usuario u) {
    Contrato c = service.buscarPorId(id);
    if (!c.getResponsavel().equals(u.getId())) {
        throw new AccessDeniedException("Sem permissão");
    }
    return toDTO(c);
}
```

---

## 7. Teste de regressão de autorização (JUnit + Spring Security Test)

```xml
<dependency>
    <groupId>org.springframework.security</groupId>
    <artifactId>spring-security-test</artifactId>
    <scope>test</scope>
</dependency>
```

```java
@SpringBootTest
@AutoConfigureMockMvc
class AditivoControllerAuthorizationTest {

    @Autowired
    private MockMvc mockMvc;

    private Long contratoDoFiscalA;

    @BeforeEach
    void setup() {
        contratoDoFiscalA = contratoFixture.criarComFiscal("fiscalA").getId();
    }

    @Test
    @DisplayName("Fiscal B não deve acessar contrato do Fiscal A")
    @WithMockUser(username = "fiscalB", roles = "FISCAL")
    void naoDeveAcessarContratoDeOutroFiscal() throws Exception {
        mockMvc.perform(get("/api/contratos/{id}", contratoDoFiscalA))
            .andExpect(status().isForbidden()); // 403 explícito, nunca 200 ou 404
    }

    @Test
    @DisplayName("Fiscal A acessa seu próprio contrato normalmente")
    @WithMockUser(username = "fiscalA", roles = "FISCAL")
    void devePermitirAcessoAoProprioContrato() throws Exception {
        mockMvc.perform(get("/api/contratos/{id}", contratoDoFiscalA))
            .andExpect(status().isOk());
    }
}
```

### Escalando para todas as rotas sensíveis

```java
record RotaProtegida(String metodo, String path, String role) {}

static Stream<RotaProtegida> rotasSensiveis() {
    return Stream.of(
        new RotaProtegida("GET", "/api/contratos/{id}", "FISCAL"),
        new RotaProtegida("PUT", "/api/aditivos/{id}", "FISCAL"),
        new RotaProtegida("GET", "/api/aditivos/{id}/anexo", "FISCAL"),
        new RotaProtegida("DELETE", "/api/termos-aditivos/{id}", "GESTOR")
        // adicionar toda rota nova aqui — vira checklist viva
    );
}

@ParameterizedTest
@MethodSource("rotasSensiveis")
@WithMockUser(username = "usuarioSemVinculo", roles = {"FISCAL", "GESTOR"})
void nenhumaRotaSensivelDeveVazarParaUsuarioSemVinculo(RotaProtegida rota) throws Exception {
    mockMvc.perform(request(HttpMethod.valueOf(rota.metodo()), rota.path(), recursoDeOutroDono))
        .andExpect(status().isForbidden());
}
```

Esse conjunto de testes funciona como canário: toda vez que um endpoint novo é adicionado, basta incluir uma linha na lista — se a checagem de posse não existir, o teste quebra no CI.

---

## 8. Regra de ouro

Rodar as ferramentas de teste (Burp, ffuf, sqlmap, nuclei) **apenas** contra: labs Docker locais, código próprio, ou escopo explícito de um programa de bug bounty. Nunca contra sistema de terceiro sem autorização escrita.
