#!/usr/bin/env python3
"""
playwright_scan.py — Crawler de browser para alvos com JS pesado (Angular, React, Vue)
Ferramentas estáticas (ffuf, waybackurls) não veem rotas geradas em runtime.
O Playwright executa o JS real e captura tudo.

Uso:
  pip install playwright && playwright install chromium
  python3 playwright_scan.py https://alvo.com
  python3 playwright_scan.py https://alvo.com --output pasta_recon/
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin, urlparse

# ── verificar dependência ─────────────────────────────────────
try:
    from playwright.sync_api import sync_playwright, Request, Response
except ImportError:
    print("[✘] playwright não instalado.")
    print("    pip install playwright && playwright install chromium")
    sys.exit(1)

# ── argumentos ────────────────────────────────────────────────
parser = argparse.ArgumentParser(description="Playwright crawler para bug bounty")
parser.add_argument("url",    help="URL alvo (ex: https://alvo.com)")
parser.add_argument("--output", default=".", help="Pasta de saída (default: .)")
parser.add_argument("--timeout", type=int, default=30, help="Timeout por página (segundos)")
parser.add_argument("--depth",   type=int, default=2,  help="Profundidade de crawl (default: 2)")
parser.add_argument("--screenshot", action="store_true", help="Captura screenshot de cada página")
args = parser.parse_args()

URL_ALVO    = args.url.rstrip("/")
OUTPUT_DIR  = Path(args.output)
TIMEOUT_MS  = args.timeout * 1000
DEPTH_MAX   = args.depth

parsed_alvo = urlparse(URL_ALVO)
DOMINIO     = f"{parsed_alvo.scheme}://{parsed_alvo.netloc}"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
SCREENSHOTS_DIR = OUTPUT_DIR / "screenshots"
if args.screenshot:
    SCREENSHOTS_DIR.mkdir(exist_ok=True)

# ── estado do crawl ───────────────────────────────────────────
visitadas:     set[str]  = set()
fila:          list[tuple[str, int]] = [(URL_ALVO, 0)]  # (url, depth)
requisicoes:   list[dict] = []
endpoints_js:  set[str]   = set()
forms:         list[dict] = []
cookies_found: list[dict] = []

# ── padrões de risco ──────────────────────────────────────────
PADROES_SENSIVEIS = [
    "api/", "graphql", "admin", "swagger", "openapi",
    "internal", "debug", ".env", "token", "secret",
    "password", "passwd", "auth", "login", "upload",
]

def eh_mesmo_dominio(url: str) -> bool:
    try:
        return urlparse(url).netloc == parsed_alvo.netloc
    except Exception:
        return False

def classificar_request(url: str) -> str:
    url_lower = url.lower()
    for padrao in PADROES_SENSIVEIS:
        if padrao in url_lower:
            return "⚠ SENSÍVEL"
    if any(ext in url_lower for ext in [".js", ".css", ".png", ".jpg", ".ico", ".woff"]):
        return "estático"
    return "normal"

def interceptar_request(req: Request) -> None:
    """Captura todas as requisições XHR/fetch feitas pelo JS."""
    if req.resource_type in ("xhr", "fetch", "websocket"):
        url = req.url
        endpoints_js.add(url)
        requisicoes.append({
            "url":     url,
            "method":  req.method,
            "tipo":    req.resource_type,
            "headers": dict(req.headers),
            "post":    req.post_data or "",
            "classe":  classificar_request(url),
        })

# ── crawl principal ───────────────────────────────────────────
print(f"\n{'═'*55}")
print(f"  Playwright Scan — {URL_ALVO}")
print(f"  Profundidade: {DEPTH_MAX}  |  Timeout: {args.timeout}s")
print(f"  Saída: {OUTPUT_DIR}")
print(f"{'═'*55}\n")

with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    ctx     = browser.new_context(
        user_agent="Mozilla/5.0 (compatible; BugBountyScanner/1.0)",
        ignore_https_errors=True,
        java_script_enabled=True,
    )
    ctx.set_default_timeout(TIMEOUT_MS)

    while fila:
        url_atual, profundidade = fila.pop(0)

        if url_atual in visitadas:
            continue
        if profundidade > DEPTH_MAX:
            continue
        if not eh_mesmo_dominio(url_atual):
            continue

        visitadas.add(url_atual)
        print(f"[→] [{profundidade}/{DEPTH_MAX}] {url_atual}")

        page = ctx.new_page()
        page.on("request", interceptar_request)

        try:
            page.goto(url_atual, wait_until="networkidle", timeout=TIMEOUT_MS)
            time.sleep(1)  # aguarda JS renderizar

            # ── captura screenshot ─────────────────────────────
            if args.screenshot:
                slug = url_atual.replace("://", "_").replace("/", "_")[:60]
                page.screenshot(path=str(SCREENSHOTS_DIR / f"{slug}.png"), full_page=True)

            # ── extrai links da página renderizada ─────────────
            hrefs = page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
            for href in hrefs:
                href = href.strip()
                if href and eh_mesmo_dominio(href) and href not in visitadas:
                    fila.append((href, profundidade + 1))

            # ── extrai formulários ────────────────────────────
            forms_pagina = page.eval_on_selector_all("form", """
                forms => forms.map(f => ({
                    action: f.action,
                    method: f.method || 'GET',
                    inputs: Array.from(f.querySelectorAll('input,select,textarea'))
                             .map(i => ({ name: i.name, type: i.type, id: i.id }))
                }))
            """)
            for form in forms_pagina:
                form["pagina"] = url_atual
                forms.append(form)

            # ── captura cookies ────────────────────────────────
            for cookie in ctx.cookies():
                cookie_info = {
                    "name":     cookie.get("name"),
                    "httpOnly": cookie.get("httpOnly"),
                    "secure":   cookie.get("secure"),
                    "sameSite": cookie.get("sameSite"),
                    "domain":   cookie.get("domain"),
                }
                if cookie_info not in cookies_found:
                    cookies_found.append(cookie_info)

            # ── rotas Angular/React detectadas via JS ──────────
            rotas_js = page.evaluate("""() => {
                const rotas = new Set();
                // Angular router
                try {
                    if (window.ng) {
                        const router = ng.getInjector(document.querySelector('[ng-version]'))?.get(ng.core?.Router);
                        if (router?.config) router.config.forEach(r => rotas.add(r.path || ''));
                    }
                } catch(e) {}
                // links com data-route ou router-link
                document.querySelectorAll('[routerLink],[data-route],[ng-href]').forEach(el => {
                    const r = el.getAttribute('routerLink') || el.getAttribute('data-route') || el.getAttribute('ng-href');
                    if (r) rotas.add(r);
                });
                return [...rotas];
            }""")
            for rota in (rotas_js or []):
                url_rota = urljoin(DOMINIO, rota)
                if eh_mesmo_dominio(url_rota) and url_rota not in visitadas:
                    endpoints_js.add(url_rota)
                    fila.append((url_rota, profundidade + 1))

            print(f"    ✔ {len(hrefs)} links  |  {len(forms_pagina)} forms  |  {len(rotas_js or [])} rotas JS")

        except Exception as e:
            print(f"    ✘ Erro: {e}")
        finally:
            page.close()

    browser.close()

# ── relatório ─────────────────────────────────────────────────
RELATORIO = OUTPUT_DIR / "playwright_report.json"
ENDPOINTS_TXT = OUTPUT_DIR / "playwright_endpoints.txt"

dados = {
    "alvo":         URL_ALVO,
    "data":         datetime.now().isoformat(),
    "paginas_visitadas": sorted(visitadas),
    "total_paginas":     len(visitadas),
    "requisicoes_xhr":   requisicoes,
    "total_xhr":         len(requisicoes),
    "endpoints_sensiveis": [r for r in requisicoes if r["classe"] == "⚠ SENSÍVEL"],
    "formularios":       forms,
    "cookies":           cookies_found,
    "endpoints_js":      sorted(endpoints_js),
}

RELATORIO.write_text(json.dumps(dados, indent=2, ensure_ascii=False))

with open(ENDPOINTS_TXT, "w") as f:
    f.write("# Páginas visitadas\n")
    for v in sorted(visitadas):
        f.write(f"{v}\n")
    f.write("\n# Endpoints XHR/fetch\n")
    for r in requisicoes:
        f.write(f"{r['classe']:12s}  {r['method']:6s}  {r['url']}\n")

# ── sumário final ─────────────────────────────────────────────
print(f"\n{'═'*55}")
print(f"  Playwright concluído")
print(f"  Páginas visitadas    : {len(visitadas)}")
print(f"  Requisições XHR/fetch: {len(requisicoes)}")
print(f"  Endpoints sensíveis  : {len(dados['endpoints_sensiveis'])}")
print(f"  Formulários          : {len(forms)}")
print(f"  Cookies              : {len(cookies_found)}")
print(f"  Relatório JSON       : {RELATORIO}")
print(f"  Endpoints TXT        : {ENDPOINTS_TXT}")
print(f"{'═'*55}")

# alertas de cookie sem flags de segurança
print("\n[Cookies sem flags de segurança]")
for c in cookies_found:
    alertas = []
    if not c.get("httpOnly"):  alertas.append("sem HttpOnly")
    if not c.get("secure"):    alertas.append("sem Secure")
    if not c.get("sameSite") or c["sameSite"] == "None": alertas.append("SameSite=None")
    if alertas:
        print(f"  ⚠ {c['name']}: {', '.join(alertas)}")

# endpoints sensíveis
if dados["endpoints_sensiveis"]:
    print("\n[Endpoints sensíveis encontrados]")
    for r in dados["endpoints_sensiveis"]:
        print(f"  ⚠ {r['method']:6s} {r['url']}")
