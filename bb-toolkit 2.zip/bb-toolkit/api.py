#!/usr/bin/env python3
"""
api.py — Backend Flask do Bug Bounty Toolkit
Porta 8080 | REST API + SSE para logs em tempo real
"""

from __future__ import annotations   # corrige Path | None no Python 3.8/3.9

import json
import os
import re
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse

try:
    import requests as _requests
    _REQUESTS_OK = True
except ImportError:
    _REQUESTS_OK = False

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
    _SCHEDULER_OK = True
except ImportError:
    _SCHEDULER_OK = False

# ── flask (com fallback de instalação automática) ─────────────
try:
    from flask import Flask, Response, jsonify, request, send_file
except ImportError:
    import sys
    print("[→] Flask não encontrado. Instalando...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "--quiet"])
    from flask import Flask, Response, jsonify, request, send_file

try:
    from flask_cors import CORS
    _CORS_OK = True
except ImportError:
    _CORS_OK = False

# ── caminhos absolutos (funciona em qualquer diretório) ────────
BASE_DIR   = Path(__file__).parent.resolve()
WEB_DIR    = BASE_DIR / "web"
RECON_FULL = str(BASE_DIR / "recon-full.sh")
REPORT_PY  = str(BASE_DIR / "report.py")

app = Flask(__name__, static_folder=str(WEB_DIR), static_url_path="")
if _CORS_OK:
    CORS(app)

# ── configuração ──────────────────────────────────────────────
RESULTADOS_DIR = Path(os.environ.get("RESULTADOS_DIR", str(BASE_DIR / "resultados")))
RESULTADOS_DIR.mkdir(parents=True, exist_ok=True)

# ── estado em memória ─────────────────────────────────────────
SCANS:     dict = {}
SCANS_LOCK = threading.Lock()

BATCHES:     dict = {}   # { batch_id: { id, alvos, scan_ids, status, inicio } }
BATCHES_LOCK = threading.Lock()

SCHEDULES:     dict = {}  # { schedule_id: { id, alvo, modo, cron, proxima } }
SCHEDULES_LOCK = threading.Lock()

# ── scheduler (APScheduler) ───────────────────────────────────
_scheduler: Optional[BackgroundScheduler] = None
if _SCHEDULER_OK:
    _scheduler = BackgroundScheduler(timezone="America/Recife")
    _scheduler.start()

# ─────────────────────────────────────────────────────────────
#  Normalização de entrada — aceita domínio ou URL completa
# ─────────────────────────────────────────────────────────────

def _normalizar_entrada(entrada: str) -> Tuple[str, str, str]:
    """
    Aceita qualquer formato de entrada e retorna (dominio, url_base, tipo).

    Exemplos aceitos:
      alvo.com                     → dominio="alvo.com", url="https://alvo.com"
      https://alvo.com             → dominio="alvo.com", url="https://alvo.com"
      https://alvo.com/api/v1/     → dominio="alvo.com", url="https://alvo.com/api/v1/"
      http://192.168.1.1:8080/app  → dominio="192.168.1.1", url="http://192.168.1.1:8080/app"
      alvo.com/api/v2              → dominio="alvo.com", url="https://alvo.com/api/v2"

    Retorna:
      dominio  — host sem porta, usado para subfinder/httpx
      url_base — URL completa normalizada, usada para fuzzing focado
      tipo     — "dominio" | "url"  (indica se entrada foi uma URL específica)
    """
    entrada = entrada.strip()

    # adiciona scheme se não tiver (urlparse precisa)
    if re.match(r'^https?://', entrada, re.IGNORECASE):
        url_com_scheme = entrada
    else:
        url_com_scheme = "https://" + entrada

    parsed = urlparse(url_com_scheme)

    # extrai host sem porta
    dominio = (parsed.hostname or "").lower()

    # determina se é URL específica (tem path além de /)
    tem_path = bool(parsed.path and parsed.path not in ("", "/"))
    tipo = "url" if tem_path else "dominio"

    # URL base: scheme + host + port (se tiver) + path
    netloc = parsed.netloc or dominio
    path   = parsed.path.rstrip("/") + "/" if parsed.path and parsed.path != "/" else "/"
    url_base = f"{parsed.scheme}://{netloc}{path if tem_path else ''}"

    return dominio, url_base, tipo

# ─────────────────────────────────────────────────────────────
#  Rotas estáticas
# ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    index_path = WEB_DIR / "index.html"
    if not index_path.exists():
        return "<h2>web/index.html não encontrado</h2><p>Verifique se a pasta web/ está no mesmo diretório que api.py</p>", 404
    return send_file(str(index_path))

@app.route("/api/health")
def health():
    return jsonify({
        "status":     "ok",
        "timestamp":  datetime.now().isoformat(),
        "resultados": str(RESULTADOS_DIR),
        "web_dir":    str(WEB_DIR),
        "recon_ok":   Path(RECON_FULL).exists(),
        "report_ok":  Path(REPORT_PY).exists(),
    })

# ─────────────────────────────────────────────────────────────
#  Scans — CRUD
# ─────────────────────────────────────────────────────────────

@app.route("/api/scans", methods=["GET"])
def listar_scans():
    with SCANS_LOCK:
        lista = [
            {k: v for k, v in s.items() if k != "log"}
            for s in SCANS.values()
        ]
    lista.sort(key=lambda s: s.get("inicio", ""), reverse=True)
    return jsonify(lista)


@app.route("/api/scans", methods=["POST"])
def iniciar_scan():
    body   = request.get_json(force=True, silent=True) or {}
    # aceita tanto "dominio" quanto "alvo" como chave
    entrada = (body.get("alvo") or body.get("dominio") or "").strip()
    modo    = body.get("modo", "rapido")

    if not entrada:
        return jsonify({"erro": "Campo 'alvo' é obrigatório (domínio ou URL)"}), 400

    # normaliza e extrai domínio + url
    try:
        dominio, url_base, tipo = _normalizar_entrada(entrada)
    except Exception as e:
        return jsonify({"erro": f"Entrada inválida: {e}"}), 400

    if not dominio:
        return jsonify({"erro": "Não foi possível extrair o domínio da entrada"}), 400

    # validação básica do domínio extraído
    partes_validas = dominio.replace(".", "").replace("-", "").replace("_", "")
    if not partes_validas.isalnum():
        return jsonify({"erro": f"Domínio inválido: '{dominio}'"}), 400

    # verifica se recon-full.sh existe
    if not Path(RECON_FULL).exists():
        return jsonify({
            "erro": f"recon-full.sh não encontrado em {RECON_FULL}. "
                    "Certifique-se de que todos os arquivos estão na mesma pasta."
        }), 500

    scan_id   = uuid.uuid4().hex[:8]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    with SCANS_LOCK:
        SCANS[scan_id] = {
            "id":         scan_id,
            "entrada":    entrada,      # valor original digitado
            "dominio":    dominio,      # host extraído (para recon)
            "url_base":   url_base,     # URL normalizada (para fuzzing focado)
            "tipo":       tipo,         # "dominio" | "url"
            "modo":       modo,
            "status":     "rodando",
            "inicio":     timestamp,
            "fim":        None,
            "output_dir": None,
            "log":        [],
        }

    threading.Thread(
        target=_executar_scan,
        args=(scan_id, dominio, url_base, tipo, modo, timestamp),
        daemon=True,
    ).start()

    return jsonify({
        "scan_id":  scan_id,
        "dominio":  dominio,
        "url_base": url_base,
        "tipo":     tipo,
    }), 202


@app.route("/api/scans/<scan_id>", methods=["GET"])
def detalhe_scan(scan_id):
    with SCANS_LOCK:
        scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({"erro": "scan não encontrado"}), 404
    return jsonify({k: v for k, v in scan.items() if k != "log"})


@app.route("/api/scans/<scan_id>/log", methods=["GET"])
def stream_log(scan_id):
    """SSE — transmite o log linha a linha em tempo real."""

    def gerar():
        ultimo = 0
        while True:
            with SCANS_LOCK:
                scan = SCANS.get(scan_id)

            if scan is None:
                yield 'data: {"erro": "scan nao encontrado"}\n\n'
                break

            linhas_novas = scan["log"][ultimo:]
            for linha in linhas_novas:
                payload = json.dumps({"linha": linha}, ensure_ascii=False)
                yield f"data: {payload}\n\n"
                ultimo += 1

            if scan["status"] in ("concluido", "erro"):
                yield 'data: {"fim": true}\n\n'
                break

            time.sleep(0.4)

    return Response(
        gerar(),
        mimetype="text/event-stream",
        headers={
            "X-Accel-Buffering": "no",
            "Cache-Control":     "no-cache",
            "Connection":        "keep-alive",
        },
    )


@app.route("/api/scans/<scan_id>/report", methods=["GET"])
def ver_relatorio(scan_id):
    with SCANS_LOCK:
        scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({"erro": "scan não encontrado"}), 404

    if not scan["output_dir"]:
        return jsonify({"erro": "scan ainda em andamento"}), 202

    report = Path(scan["output_dir"]) / "relatorio" / "report.html"
    if report.exists():
        return send_file(str(report))

    return jsonify({"erro": "relatório não gerado ainda — rode report.py manualmente"}), 404


@app.route("/api/scans/<scan_id>", methods=["DELETE"])
def deletar_scan(scan_id):
    with SCANS_LOCK:
        if scan_id not in SCANS:
            return jsonify({"erro": "não encontrado"}), 404
        SCANS.pop(scan_id)
    return jsonify({"deletado": scan_id})


# ─────────────────────────────────────────────────────────────
#  Ferramentas
# ─────────────────────────────────────────────────────────────

@app.route("/api/tools", methods=["GET"])
def verificar_ferramentas():
    tools = {
        "subfinder":    ["subfinder",    "-version"],
        "httpx":        ["httpx",        "-version"],
        "nuclei":       ["nuclei",       "-version"],
        "ffuf":         ["ffuf",         "-V"],
        "gau":          ["gau",          "--version"],
        "waybackurls":  ["waybackurls",  "-h"],
        "dalfox":       ["dalfox",       "version"],
        "python3":      ["python3",      "--version"],
        "go":           ["go",           "version"],
    }
    resultado = {}
    for nome, cmd in tools.items():
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            versao = (out.stdout + out.stderr).split("\n")[0].strip()
            resultado[nome] = {"ok": True, "versao": versao}
        except FileNotFoundError:
            resultado[nome] = {"ok": False, "versao": "não instalado"}
        except Exception as e:
            resultado[nome] = {"ok": False, "versao": str(e)}
    return jsonify(resultado)


# ─────────────────────────────────────────────────────────────
#  Execução do scan (thread separada)
# ─────────────────────────────────────────────────────────────

def _log(scan_id: str, linha: str) -> None:
    with SCANS_LOCK:
        if scan_id in SCANS:
            SCANS[scan_id]["log"].append(linha)


def _executar_scan(
    scan_id: str,
    dominio: str,
    url_base: str,
    tipo: str,
    modo: str,
    timestamp: str,
) -> None:
    _log(scan_id, f"[→] Alvo    : {url_base}")
    _log(scan_id, f"[→] Domínio : {dominio}")
    _log(scan_id, f"[→] Tipo    : {tipo}  |  Modo: {modo}")
    _log(scan_id, f"[→] Início  : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    _log(scan_id, "")

    # quando é URL específica, avisa que subfinder/httpx rodam no domínio raiz
    # mas o fuzzing focará na URL informada
    if tipo == "url":
        _log(scan_id, f"[!] URL específica detectada")
        _log(scan_id, f"    Recon de subdomínios: {dominio}")
        _log(scan_id, f"    Fuzzing focado em: {url_base}")
        _log(scan_id, "")

    cmd = ["bash", RECON_FULL, dominio]
    if modo == "rapido":
        cmd.append("--rapido")

    exito = False
    try:
        env_extra = {
            **os.environ,
            "PATH":     os.environ.get("PATH", "") + ":/root/go/bin:/usr/local/go/bin",
            "URL_ALVO": url_base,   # passado para recon-full.sh usar no fuzzing
            "TIPO_ALVO": tipo,      # "dominio" | "url"
        }
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            cwd=str(RESULTADOS_DIR),
            bufsize=1,
            env=env_extra,
        )

        for linha in iter(proc.stdout.readline, ""):
            _log(scan_id, linha.rstrip())

        proc.wait()
        exito = (proc.returncode == 0)

    except FileNotFoundError:
        _log(scan_id, f"[✘] bash ou recon-full.sh não encontrado em {RECON_FULL}")
    except Exception as e:
        _log(scan_id, f"[✘] Erro ao executar recon: {e}")

    # gerar relatório HTML
    output_dir = _encontrar_output(dominio, timestamp)
    if output_dir and Path(REPORT_PY).exists():
        _log(scan_id, "")
        _log(scan_id, "[→] Gerando relatório HTML...")
        try:
            subprocess.run(
                ["python3", REPORT_PY, str(output_dir)],
                capture_output=True,
                timeout=60,
                cwd=str(RESULTADOS_DIR),
            )
            _log(scan_id, f"[✔] Relatório: {output_dir}/relatorio/report.html")
        except Exception as e:
            _log(scan_id, f"[!] Relatório falhou: {e}")
    elif not output_dir:
        _log(scan_id, "[!] Pasta de saída não encontrada")

    fim    = datetime.now().strftime("%Y%m%d_%H%M%S")
    status = "concluido" if exito else "erro"

    with SCANS_LOCK:
        if scan_id in SCANS:
            SCANS[scan_id]["status"]     = status
            SCANS[scan_id]["fim"]        = fim
            SCANS[scan_id]["output_dir"] = str(output_dir) if output_dir else None

    _log(scan_id, "")
    _log(scan_id, f"[{'✔' if exito else '✘'}] Scan {status} — {fim}")


def _encontrar_output(dominio: str, timestamp: str) -> Optional[Path]:
    """Encontra a pasta de saída mais recente do recon para o domínio."""
    try:
        candidatas = sorted(
            RESULTADOS_DIR.glob(f"recon_{dominio}_*"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        return candidatas[0] if candidatas else None
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────
#  Batch — múltiplos alvos em paralelo
# ─────────────────────────────────────────────────────────────

@app.route("/api/scans/batch", methods=["POST"])
def iniciar_batch():
    """Inicia scans em paralelo para múltiplos alvos."""
    body  = request.get_json(force=True, silent=True) or {}
    alvos = body.get("alvos") or body.get("dominios") or []
    modo  = body.get("modo", "rapido")
    concorrencia = min(int(body.get("concorrencia", 3)), 5)  # máx 5 paralelos

    if not alvos or not isinstance(alvos, list):
        return jsonify({"erro": "'alvos' deve ser uma lista de domínios/URLs"}), 400

    alvos = [a.strip() for a in alvos if a.strip()][:20]  # máx 20 por batch

    batch_id  = uuid.uuid4().hex[:8]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    scan_ids: list[str] = []

    # cria os scans individuais
    for alvo in alvos:
        try:
            dominio, url_base, tipo = _normalizar_entrada(alvo)
        except Exception:
            continue

        scan_id = uuid.uuid4().hex[:8]
        scan_ids.append(scan_id)

        with SCANS_LOCK:
            SCANS[scan_id] = {
                "id":         scan_id,
                "batch_id":   batch_id,
                "entrada":    alvo,
                "dominio":    dominio,
                "url_base":   url_base,
                "tipo":       tipo,
                "modo":       modo,
                "status":     "aguardando",
                "inicio":     timestamp,
                "fim":        None,
                "output_dir": None,
                "log":        [],
            }

    with BATCHES_LOCK:
        BATCHES[batch_id] = {
            "id":          batch_id,
            "alvos":       alvos,
            "scan_ids":    scan_ids,
            "modo":        modo,
            "concorrencia": concorrencia,
            "status":      "rodando",
            "inicio":      timestamp,
            "fim":         None,
        }

    threading.Thread(
        target=_executar_batch,
        args=(batch_id, scan_ids, modo, concorrencia, timestamp),
        daemon=True,
    ).start()

    return jsonify({
        "batch_id": batch_id,
        "scan_ids": scan_ids,
        "total":    len(scan_ids),
        "concorrencia": concorrencia,
    }), 202


@app.route("/api/batches", methods=["GET"])
def listar_batches():
    with BATCHES_LOCK:
        return jsonify(list(BATCHES.values()))


@app.route("/api/batches/<batch_id>", methods=["GET"])
def detalhe_batch(batch_id):
    with BATCHES_LOCK:
        batch = BATCHES.get(batch_id)
    if not batch:
        return jsonify({"erro": "batch não encontrado"}), 404

    # enriquece com status atual de cada scan
    scans_do_batch = []
    with SCANS_LOCK:
        for sid in batch["scan_ids"]:
            s = SCANS.get(sid, {})
            scans_do_batch.append({
                "id":      sid,
                "dominio": s.get("dominio"),
                "status":  s.get("status"),
                "fim":     s.get("fim"),
            })

    return jsonify({**batch, "scans": scans_do_batch})


def _executar_batch(batch_id: str, scan_ids: list, modo: str,
                    concorrencia: int, timestamp: str) -> None:
    """Roda os scans do batch em paralelo com ThreadPoolExecutor."""

    def _rodar_um(scan_id: str) -> str:
        with SCANS_LOCK:
            s = SCANS.get(scan_id, {})
        dominio  = s.get("dominio", "")
        url_base = s.get("url_base", "")
        tipo     = s.get("tipo", "dominio")

        with SCANS_LOCK:
            SCANS[scan_id]["status"] = "rodando"

        _executar_scan(scan_id, dominio, url_base, tipo, modo, timestamp)
        return scan_id

    with ThreadPoolExecutor(max_workers=concorrencia) as pool:
        futures = {pool.submit(_rodar_um, sid): sid for sid in scan_ids}
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                sid = futures[future]
                with SCANS_LOCK:
                    if sid in SCANS:
                        SCANS[sid]["status"] = "erro"
                        SCANS[sid]["log"].append(f"[✘] Erro no batch: {e}")

    fim = datetime.now().strftime("%Y%m%d_%H%M%S")
    with BATCHES_LOCK:
        if batch_id in BATCHES:
            BATCHES[batch_id]["status"] = "concluido"
            BATCHES[batch_id]["fim"]    = fim


# ─────────────────────────────────────────────────────────────
#  Schedules — scans agendados com cron
# ─────────────────────────────────────────────────────────────

@app.route("/api/schedules", methods=["GET"])
def listar_schedules():
    with SCHEDULES_LOCK:
        return jsonify(list(SCHEDULES.values()))


@app.route("/api/schedules", methods=["POST"])
def criar_schedule():
    if not _SCHEDULER_OK or _scheduler is None:
        return jsonify({
            "erro": "APScheduler não instalado. pip install apscheduler"
        }), 503

    body  = request.get_json(force=True, silent=True) or {}
    alvo  = (body.get("alvo") or "").strip()
    modo  = body.get("modo", "rapido")
    cron  = (body.get("cron") or "").strip()
    nome  = body.get("nome") or alvo

    if not alvo:
        return jsonify({"erro": "'alvo' é obrigatório"}), 400
    if not cron:
        return jsonify({
            "erro": "'cron' é obrigatório. Exemplos: '0 9 * * 1' (toda segunda às 9h), '0 */6 * * *' (a cada 6h)"
        }), 400

    try:
        trigger = CronTrigger.from_crontab(cron, timezone="America/Recife")
    except Exception as e:
        return jsonify({"erro": f"Cron inválido: {e}"}), 400

    schedule_id = uuid.uuid4().hex[:8]

    def _job_agendado():
        """Executado pelo APScheduler no horário configurado."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        try:
            dominio, url_base, tipo = _normalizar_entrada(alvo)
        except Exception:
            return

        scan_id = uuid.uuid4().hex[:8]
        with SCANS_LOCK:
            SCANS[scan_id] = {
                "id":          scan_id,
                "schedule_id": schedule_id,
                "entrada":     alvo,
                "dominio":     dominio,
                "url_base":    url_base,
                "tipo":        tipo,
                "modo":        modo,
                "status":      "rodando",
                "inicio":      ts,
                "fim":         None,
                "output_dir":  None,
                "log":         [f"[→] Scan agendado disparado — schedule {schedule_id}"],
            }

        threading.Thread(
            target=_executar_scan,
            args=(scan_id, dominio, url_base, tipo, modo, ts),
            daemon=True,
        ).start()

        # atualiza última execução
        with SCHEDULES_LOCK:
            if schedule_id in SCHEDULES:
                SCHEDULES[schedule_id]["ultima_execucao"] = ts

    job = _scheduler.add_job(
        _job_agendado,
        trigger=trigger,
        id=schedule_id,
        name=nome,
        replace_existing=True,
    )

    proxima = job.next_run_time.strftime("%d/%m/%Y %H:%M") if job.next_run_time else "—"

    with SCHEDULES_LOCK:
        SCHEDULES[schedule_id] = {
            "id":              schedule_id,
            "nome":            nome,
            "alvo":            alvo,
            "modo":            modo,
            "cron":            cron,
            "proxima":         proxima,
            "ultima_execucao": None,
            "criado_em":       datetime.now().strftime("%Y%m%d_%H%M%S"),
        }

    return jsonify({
        "schedule_id": schedule_id,
        "alvo":        alvo,
        "cron":        cron,
        "proxima":     proxima,
    }), 201


@app.route("/api/schedules/<schedule_id>", methods=["DELETE"])
def deletar_schedule(schedule_id):
    if _scheduler:
        try:
            _scheduler.remove_job(schedule_id)
        except Exception:
            pass
    with SCHEDULES_LOCK:
        if schedule_id not in SCHEDULES:
            return jsonify({"erro": "não encontrado"}), 404
        SCHEDULES.pop(schedule_id)
    return jsonify({"deletado": schedule_id})


# ─────────────────────────────────────────────────────────────
#  Ngrok — URL pública do tunnel
# ─────────────────────────────────────────────────────────────

@app.route("/api/ngrok-url", methods=["GET"])
def ngrok_url():
    """Consulta a API local do ngrok para obter a URL pública."""
    if not _REQUESTS_OK:
        return jsonify({"url": None, "erro": "requests não instalado"}), 503

    # ngrok expõe sua API em localhost:4040
    ngrok_api = os.environ.get("NGROK_API", "http://ngrok:4040")
    try:
        resp = _requests.get(f"{ngrok_api}/api/tunnels", timeout=3)
        tunnels = resp.json().get("tunnels", [])
        https = next(
            (t["public_url"] for t in tunnels if t["public_url"].startswith("https")),
            None,
        )
        http = next(
            (t["public_url"] for t in tunnels if t["public_url"].startswith("http")),
            None,
        )
        return jsonify({
            "url":   https or http,
            "https": https,
            "http":  http,
            "todos": [t["public_url"] for t in tunnels],
        })
    except Exception as e:
        return jsonify({"url": None, "erro": str(e)}), 503


# ─────────────────────────────────────────────────────────────
#  Inicialização
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    PORT = int(os.environ.get("PORT", 8080))

    print("═" * 52)
    print("  Bug Bounty Toolkit — API")
    print(f"  http://localhost:{PORT}")
    print(f"  BASE_DIR      : {BASE_DIR}")
    print(f"  WEB_DIR       : {WEB_DIR}  {'✔' if WEB_DIR.exists() else '✘ NÃO ENCONTRADO'}")
    print(f"  RESULTADOS    : {RESULTADOS_DIR}")
    print(f"  recon-full.sh : {'✔' if Path(RECON_FULL).exists() else '✘ NÃO ENCONTRADO'}")
    print(f"  report.py     : {'✔' if Path(REPORT_PY).exists() else '✘ NÃO ENCONTRADO'}")
    print(f"  flask_cors    : {'✔' if _CORS_OK else '✘ não instalado (ok, sem impacto)'}")
    print("═" * 52)

    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
