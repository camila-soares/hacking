# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

`bb-toolkit` is a **bug bounty / recon toolkit** for authorized security testing. It wraps a
pipeline of Go recon tools (subfinder, httpx, gau, waybackurls, ffuf, nuclei, dalfox) behind a
Flask REST API + single-page web UI, and ships standalone Python probes for specific vulnerability
classes. All code, prompts, and reports are in **Brazilian Portuguese**; match that language when
editing user-facing strings, log lines, and report templates.

Every script carries an authorization notice (invasão sem autorização é crime — art. 154-A CP).
Only operate against targets with written authorization. The `recon_*` / `resultados/` directories
are scan output from real runs — treat as scratch data, not source.

## Architecture

The system has two entry points that share the same shell pipeline:

**1. Web service (`api.py` → `recon-full.sh` → `report.py`)**
- `api.py` — Flask server on port 8080. Serves `web/index.html` (the whole UI is one static file)
  and a REST API. Holds all state **in memory** (`SCANS`, `BATCHES`, `SCHEDULES` dicts guarded by
  locks) — nothing is persisted across restarts except the scan output files on disk.
- A scan spawns a background thread that runs `recon-full.sh` via `subprocess.Popen`, streaming
  stdout line-by-line into the scan's in-memory `log` list. The UI tails it over **SSE** at
  `GET /api/scans/<id>/log`.
- On completion the thread calls `report.py <output_dir>` to render `relatorio/report.html`.
- `_normalizar_entrada()` in `api.py` is the input contract: it accepts a bare domain or a full
  URL and returns `(dominio, url_base, tipo)`. `tipo="url"` means focused fuzzing on that exact
  path; `tipo="dominio"` means full subdomain sweep. This triple is passed to `recon-full.sh` via
  the `URL_ALVO` / `TIPO_ALVO` environment variables — not as CLI args.
- Batch (`/api/scans/batch`) runs up to 5 concurrent scans via `ThreadPoolExecutor` (capped: 20
  targets/batch). Schedules (`/api/schedules`) use APScheduler cron triggers, timezone
  `America/Recife`. Both APScheduler and flask-cors are **optional** — guarded by `_SCHEDULER_OK` /
  `_CORS_OK` import flags so the API degrades gracefully when they're missing.

**2. `recon-full.sh` — the 6-phase pipeline** (also runnable directly from the CLI)
Writes everything under `recon_<dominio>_<timestamp>/` with fixed subdirs
(`subdominios/ hosts/ params/ nuclei/ fuzzing/ classificacao/ relatorio/`). Downstream tools and
`report.py` depend on these exact paths and filenames:
1. subfinder → `subdominios/raw.txt`
2. httpx → `hosts/ativos.txt` (active hosts; `--rapido` still runs this)
3. gau + waybackurls → `params/com_parametros.txt`, `params/arquivos_sensiveis.txt`
4. nuclei → `nuclei/findings.{json,txt}` (**skipped in `--rapido` mode**)
5. ffuf fuzzing → `fuzzing/todos_endpoints.txt`
6. **classification** → `classificacao/*.txt` — an embedded Python heredoc that regex-matches
   parameter names against vuln patterns (IDOR, SSRF, Open Redirect, LFI/RFI, XSS, SQLi, Command
   Injection, Mass Assignment, JWT/Auth) and writes one file per class plus
   `resumo_classificacao.md` with per-class testing methodology.

`recon-full.sh` also has standalone sub-modes: `--classify <dir>` and `--fuzz <dir>` re-run only
phase 6 or 5 against an existing output directory.

**3. Standalone probes** (independent CLIs, run manually against classified output or a URL)
- `credcheck.py` — default-credential / credential-stuffing against login endpoints; auto-detects
  rate limiting and stops. Can auto-find login endpoints from a `recon_*/` dir.
- `php_login.py` — PHP auth handler; detects CSRF token scheme per framework (Laravel, Symfony,
  WordPress, CodeIgniter, CakePHP). Usable as an imported module (`PHPLoginHandler`) or a CLI.
- `path_traversal.py` — LFI/path-traversal payloads; reads `classificacao/lfi___rfi.txt` or a URL.
- `playwright_scan.py` — headless-Chromium crawler for JS-heavy SPAs (Angular/React/Vue) that
  static tools miss; captures runtime routes/XHR.
- `shodan scan.py` — enriches discovered hosts via the Shodan API (ports, CVEs, banners). Note the
  **space in the filename** — invoke as `python3 "shodan scan.py"`.
- `cpf_utils.py` — Brazilian CPF generation/validation helpers for form testing (test CPFs only).

When adding a probe that consumes recon output, read from the `classificacao/<vuln>.txt` files —
that's the established hand-off contract from phase 6 to the probes.

## Commands

Docker is the primary path (`Makefile` wraps `docker compose`; help text is in Portuguese):

```bash
make build           # build the image (first build ~15min: Go tools + Chromium)
make up              # run on http://localhost:8080
make down            # stop
make logs            # tail container logs
make bash            # shell into the container
make scan ALVO=alvo.com   # kick a scan via the API from the CLI
make token           # generate + store a random API_TOKEN in .env
make ngrok           # run with an ngrok tunnel (needs NGROK_AUTHTOKEN)
make health          # curl /api/health
make rebuild         # docker compose build --no-cache && up
```

Run the API directly (outside Docker):
```bash
python3 api.py       # serves 0.0.0.0:8080; PORT/RESULTADOS_DIR override via env
```

Run the pipeline / probes directly:
```bash
./recon-full.sh alvo.com                 # full recon
./recon-full.sh alvo.com --rapido        # skip nuclei (fast)
./recon-full.sh https://alvo.com/api/v1/ # URL mode → focused fuzzing on that path
./recon-full.sh --classify recon_alvo.com_.../   # re-run phase 6 only
python3 report.py recon_alvo.com_.../    # (re)generate report.html
python3 credcheck.py --url https://alvo.com/api/login
python3 path_traversal.py recon_alvo.com_.../
```

Install tools on the host (Ubuntu/Debian/Kali/Fedora/macOS):
```bash
bash install.sh                 # Go tools + SecLists (~1GB)
bash install.sh --minimal       # Go tools only
bash install.sh --sem-seclists  # skip the SecLists download
```

There is **no test suite, linter, or build step** for the Python code — it runs directly.

## Conventions & gotchas

- **Optional dependencies degrade, they don't crash.** Every non-core import (`requests`,
  `apscheduler`, `flask_cors`, `shodan`, `playwright`) is wrapped in try/except with an `_OK` flag
  or an install hint. Preserve this pattern — the toolkit must start with a minimal Python env.
- **Wordlists** default to `~/SecLists/...` (raft-medium, api-endpoints, burp-parameter-names). If
  SecLists is absent, `recon-full.sh` falls back to a small embedded wordlist written to
  `/tmp/wl_fallback.txt`. Don't hard-fail on a missing SecLists.
- Tool binaries are expected on `PATH` including `/root/go/bin` and `/usr/local/go/bin` — `api.py`
  appends these to the subprocess `PATH` explicitly.
- The container runs as non-root (`scanner`, uid 1000) with `cap_drop: ALL` and
  `no-new-privileges`. Nuclei templates and the Playwright browser cache live in named volumes so
  they survive rebuilds; `./resultados` is bind-mounted to the host.
- API auth is via the optional `X-API-Token` header (from `API_TOKEN` in `.env`); empty means no
  auth (local use).
- `report.py` derives the target name by stripping `recon_` and the trailing `_<timestamp>` from
  the directory name — keep the `recon_<dominio>_<timestamp>` naming if you touch output paths.
- **Portability (macOS is a first-class target).** The scripts run on both macOS (BSD userland) and
  Linux (GNU). Avoid GNU-only constructs: BSD `grep` has no `-P` (use `-E` with POSIX classes like
  `[0-9]`), and under `set -euo pipefail` a `cmd | head -1` pipeline can SIGPIPE the upstream and
  abort the script — append `|| true` to such assignments. Tool flags also drift across versions:
  nuclei v3 dropped `-json` (use `-o` for text + `-je`/`-jsonl-export` for JSON) and accepts only
  one `-o`; `ffuf` and `httpx` still take `-json`. Verify a flag against the installed binary before
  adding it to a pipeline.
