#!/bin/bash
# ============================================================
#  Bug Bounty Toolkit — install.sh
#  Instala todas as dependências do toolkit completo
#
#  Uso:
#    bash install.sh                   # instalação completa
#    bash install.sh --minimal         # só Go tools + Flask
#    bash install.sh --sem-seclists    # sem SecLists (~1GB)
#    bash install.sh --sem-playwright  # sem Chromium (~400MB)
#    bash install.sh --atualizar       # só atualiza dependências
#
#  Suporte: macOS (Intel + Apple Silicon), Ubuntu/Debian, Kali
# ============================================================

set -euo pipefail

# ── flags ─────────────────────────────────────────────────────
MINIMAL=false
SEM_SECLISTS=false
SEM_PLAYWRIGHT=false
ATUALIZAR=false

for arg in "$@"; do
    case "$arg" in
        --minimal)        MINIMAL=true ;;
        --sem-seclists)   SEM_SECLISTS=true ;;
        --sem-playwright) SEM_PLAYWRIGHT=true ;;
        --atualizar)      ATUALIZAR=true ;;
    esac
done

# ── cores ─────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

ok()      { echo -e "${GREEN}[✔]${NC} $1"; }
info()    { echo -e "${YELLOW}[→]${NC} $1"; }
erro()    { echo -e "${RED}[✘]${NC} $1"; }
passo()   { echo -e "\n${CYAN}${BOLD}▶ $1${NC}"; }
pergunta(){ echo -en "${CYAN}[?]${NC} $1 [S/n]: "; read -r r; [[ -z "$r" || "$r" =~ ^[Ss]$ ]]; }

# ── detectar OS ───────────────────────────────────────────────
detectar_os() {
    [[ "$OSTYPE" == "darwin"* ]]      && echo "macos"  && return
    [[ -f /etc/kali-release ]]        && echo "kali"   && return
    [[ -f /etc/debian_version ]]      && echo "debian" && return
    [[ -f /etc/fedora-release ]]      && echo "fedora" && return
    echo "linux"
}
OS=$(detectar_os)

# ── diretórios ────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOLKIT_DIR="$HOME/bug-bounty-toolkit"
SECLISTS_DIR="$HOME/SecLists"
LOG="$TOOLKIT_DIR/install.log"

mkdir -p "$TOOLKIT_DIR"
exec > >(tee -a "$LOG") 2>&1

# ── banner ────────────────────────────────────────────────────
clear
echo -e "${CYAN}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║     Bug Bounty Toolkit — Instalador      ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  OS: ${CYAN}${OS}${NC}  |  Minimal: ${MINIMAL}  |  SecLists: $( $SEM_SECLISTS && echo 'pular' || echo 'instalar')"
echo -e "  ${RED}Só testar com autorização escrita — art. 154-A CP${NC}\n"

pergunta "Confirmar instalação?" || { echo "Cancelado."; exit 0; }

# ─────────────────────────────────────────────────────────────
# PASSO 1 — Dependências do sistema
# ─────────────────────────────────────────────────────────────
passo "PASSO 1/7 — Dependências do sistema"

instalar_pkg() {
    local p="$1"
    case "$OS" in
        macos)  command -v brew &>/dev/null && brew list "$p" &>/dev/null || brew install "$p" ;;
        kali|debian) dpkg -l "$p" &>/dev/null || sudo apt-get install -y -q "$p" ;;
        fedora) rpm -q "$p" &>/dev/null || sudo dnf install -y -q "$p" ;;
    esac
}

PKGS_LINUX="git curl wget python3 python3-pip build-essential ca-certificates tzdata"
PKGS_MACOS="git curl wget python3"

if [[ "$OS" == "macos" ]]; then
    if ! command -v brew &>/dev/null; then
        info "Instalando Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    for p in $PKGS_MACOS; do instalar_pkg "$p"; done
else
    sudo apt-get update -q 2>/dev/null || true
    for p in $PKGS_LINUX; do instalar_pkg "$p" 2>/dev/null || true; done
fi

ok "Dependências do sistema ok"

# ─────────────────────────────────────────────────────────────
# PASSO 2 — Go language
# ─────────────────────────────────────────────────────────────
passo "PASSO 2/7 — Go language"

GO_VERSION="1.22.4"
GOPATH="$HOME/go"
export GOPATH GOROOT=/usr/local/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin

versao_go_ok() {
    local ver; ver=$(go version 2>/dev/null | grep -oP '\d+\.\d+' | head -1)
    [[ -n "$ver" ]] && python3 -c "
v = tuple(map(int,'$ver'.split('.')))
r = tuple(map(int,'1.21'.split('.')))
exit(0 if v >= r else 1)" 2>/dev/null
}

if versao_go_ok; then
    ok "Go $(go version | awk '{print $3}') já instalado"
else
    info "Instalando Go $GO_VERSION..."
    ARCH=$(uname -m)
    [[ "$ARCH" == "aarch64" || "$ARCH" == "arm64" ]] && GOARCH="arm64" || GOARCH="amd64"

    if [[ "$OS" == "macos" ]]; then
        brew install go
    else
        curl -fsSL "https://go.dev/dl/go${GO_VERSION}.linux-${GOARCH}.tar.gz" -o /tmp/go.tar.gz
        sudo rm -rf /usr/local/go
        sudo tar -C /usr/local -xzf /tmp/go.tar.gz
        rm /tmp/go.tar.gz
    fi
    ok "Go $GO_VERSION instalado"
fi

# ─────────────────────────────────────────────────────────────
# PASSO 3 — Go tools de recon
# ─────────────────────────────────────────────────────────────
passo "PASSO 3/7 — Go tools de recon"

go_install() {
    local nome="$1" pkg="$2"
    if command -v "$nome" &>/dev/null && ! $ATUALIZAR; then
        ok "$nome já instalado"
    else
        info "Instalando $nome..."
        go install "${pkg}@latest" 2>/dev/null && ok "$nome ✔" || erro "$nome falhou"
    fi
}

go_install subfinder   "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
go_install httpx       "github.com/projectdiscovery/httpx/cmd/httpx"
go_install nuclei      "github.com/projectdiscovery/nuclei/v3/cmd/nuclei"
go_install gau         "github.com/lc/gau/v2/cmd/gau"
go_install waybackurls "github.com/tomnomnom/waybackurls"
go_install ffuf        "github.com/ffuf/ffuf/v2"
go_install anew        "github.com/tomnomnom/anew"
go_install dalfox      "github.com/hahwul/dalfox/v2"

if ! $MINIMAL; then
    go_install qsreplace "github.com/tomnomnom/qsreplace"
fi

info "Atualizando templates do nuclei..."
nuclei -update-templates -silent 2>/dev/null && ok "Templates ok" || true

# ─────────────────────────────────────────────────────────────
# PASSO 4 — Python packages
# ─────────────────────────────────────────────────────────────
passo "PASSO 4/7 — Python packages"

PIP="pip3"
command -v pip3 &>/dev/null || PIP="pip"

# requirements.txt mínimo ou completo
if $MINIMAL; then
    info "Modo minimal — instalando só Flask + requests..."
    $PIP install --quiet flask flask-cors requests python-dotenv
else
    if [[ -f "$SCRIPT_DIR/requirements.txt" ]]; then
        info "Instalando de requirements.txt..."
        $PIP install --quiet -r "$SCRIPT_DIR/requirements.txt"
    else
        info "requirements.txt não encontrado — instalando pacotes individualmente..."
        $PIP install --quiet \
            flask flask-cors requests urllib3 \
            apscheduler python-dotenv \
            shodan 2captcha-python \
            beautifulsoup4 lxml
    fi
fi
ok "Python packages instalados"

# ─────────────────────────────────────────────────────────────
# PASSO 5 — Playwright (Chromium headless)
# ─────────────────────────────────────────────────────────────
passo "PASSO 5/7 — Playwright"

if $SEM_PLAYWRIGHT || $MINIMAL; then
    warn() { echo -e "${YELLOW}[!]${NC} $1"; }
    warn "Playwright pulado. Instale depois: python3 -m playwright install chromium"
else
    if python3 -c "from playwright.sync_api import sync_playwright" &>/dev/null; then
        if $ATUALIZAR; then
            info "Atualizando Playwright..."
            python3 -m playwright install chromium 2>/dev/null && ok "Playwright atualizado"
        else
            ok "Playwright já instalado"
        fi
    else
        info "Instalando Playwright + Chromium (~400MB)..."
        $PIP install --quiet playwright
        python3 -m playwright install chromium 2>/dev/null && ok "Playwright ✔"
    fi
fi

# ─────────────────────────────────────────────────────────────
# PASSO 6 — SecLists
# ─────────────────────────────────────────────────────────────
passo "PASSO 6/7 — SecLists"

if $SEM_SECLISTS || $MINIMAL; then
    info "SecLists pulado. Instale depois: git clone https://github.com/danielmiessler/SecLists ~/SecLists"
    # wordlist mínima de fallback
    mkdir -p "$HOME/SecLists/Discovery/Web-Content"
    printf 'admin\napi\nv1\nv2\nlogin\nconfig\nbackup\ntest\ndebug\nhealth\nstatus\nswagger\n' \
        > "$HOME/SecLists/Discovery/Web-Content/raft-medium-words.txt"
    ok "Wordlist mínima criada"
elif [[ -d "$SECLISTS_DIR/.git" ]]; then
    info "SecLists existe — atualizando..."
    git -C "$SECLISTS_DIR" pull --ff-only -q 2>/dev/null && ok "SecLists atualizado" || true
else
    if pergunta "SecLists ocupa ~1GB. Instalar?"; then
        info "Clonando SecLists..."
        git clone --depth 1 -q https://github.com/danielmiessler/SecLists.git "$SECLISTS_DIR"
        ok "SecLists em $SECLISTS_DIR"
    else
        info "Pulando SecLists"
    fi
fi

# ─────────────────────────────────────────────────────────────
# PASSO 7 — Copiar scripts e configurar PATH
# ─────────────────────────────────────────────────────────────
passo "PASSO 7/7 — Configurar toolkit"

# copiar todos os scripts para $TOOLKIT_DIR
SCRIPTS=(
    recon.sh recon-full.sh report.py api.py
    playwright_scan.py path_traversal.py credcheck.py
    shodan_scan.py captcha_solver.py php_login.py cpf_utils.py
    sgc_security_scan.py sgc_checklist.md
    Makefile Makefile.sgc
    requirements.txt
    README.md SECURITY_REVIEW.md
)

for f in "${SCRIPTS[@]}"; do
    if [[ -f "$SCRIPT_DIR/$f" ]]; then
        cp "$SCRIPT_DIR/$f" "$TOOLKIT_DIR/"
        [[ "$f" == *.sh ]] && chmod +x "$TOOLKIT_DIR/$f"
        ok "Copiado: $f"
    fi
done

# copiar pasta web/
if [[ -d "$SCRIPT_DIR/web" ]]; then
    cp -r "$SCRIPT_DIR/web" "$TOOLKIT_DIR/"
    ok "Copiado: web/"
fi

# criar pasta de resultados
mkdir -p "$TOOLKIT_DIR/resultados" "$TOOLKIT_DIR/security-reports"

# ── configurar PATH e aliases ─────────────────────────────────
EXPORT_BLOCK='
# ── Bug Bounty Toolkit ──────────────────────────────────────
export GOPATH="$HOME/go"
export PATH="$PATH:/usr/local/go/bin:$GOPATH/bin"
# ────────────────────────────────────────────────────────────'

ALIAS_BLOCK="
# ── Bug Bounty Toolkit aliases ──────────────────────────────
alias recon='bash ${TOOLKIT_DIR}/recon.sh'
alias recon-full='bash ${TOOLKIT_DIR}/recon-full.sh'
alias bb-report='python3 ${TOOLKIT_DIR}/report.py'
alias bb-api='python3 ${TOOLKIT_DIR}/api.py'
alias bb-cred='python3 ${TOOLKIT_DIR}/credcheck.py'
alias bb-playwright='python3 ${TOOLKIT_DIR}/playwright_scan.py'
alias bb-shodan='python3 ${TOOLKIT_DIR}/shodan_scan.py'
alias bb-sgc='python3 ${TOOLKIT_DIR}/sgc_security_scan.py'
alias bb-php='python3 ${TOOLKIT_DIR}/php_login.py'
alias cpf='python3 ${TOOLKIT_DIR}/cpf_utils.py'
# ────────────────────────────────────────────────────────────"

for SHELLRC in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
    [[ -f "$SHELLRC" ]] || continue
    if ! grep -q "Bug Bounty Toolkit" "$SHELLRC" 2>/dev/null; then
        echo "$EXPORT_BLOCK" >> "$SHELLRC"
        echo "$ALIAS_BLOCK"  >> "$SHELLRC"
        ok "Aliases adicionados em $SHELLRC"
    else
        ok "$SHELLRC já configurado"
    fi
done

# ── criar .env de exemplo ─────────────────────────────────────
if [[ ! -f "$TOOLKIT_DIR/.env" ]]; then
    cat > "$TOOLKIT_DIR/.env" << 'DOTENV'
# Bug Bounty Toolkit — variáveis de ambiente
# Copie este arquivo para .env e preencha os valores

# Token de autenticação da API web (deixe vazio para desabilitar)
# Gerar: openssl rand -hex 32
API_TOKEN=

# Shodan API key (https://account.shodan.io)
SHODAN_KEY=

# 2captcha API key (https://2captcha.com)
CAPTCHA_API_KEY=

# ngrok authtoken (https://ngrok.com)
NGROK_AUTHTOKEN=

# Fuso horário
TZ=America/Recife
DOTENV
    ok ".env criado em $TOOLKIT_DIR/.env"
fi

# ─────────────────────────────────────────────────────────────
# Verificação final
# ─────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}════════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}  Verificação final${NC}"
echo -e "${CYAN}${BOLD}════════════════════════════════════════════${NC}"

verificar() {
    local nome="$1" cmd="$2"
    if eval "$cmd" &>/dev/null; then
        local ver; ver=$(eval "$cmd" 2>&1 | head -1 | grep -oP '\d+[\.\d]*' | head -1)
        ok "$nome ${ver:+(v$ver)}"
    else
        erro "$nome — não encontrado"
    fi
}

verificar "go"           "go version"
verificar "python3"      "python3 --version"
verificar "subfinder"    "$HOME/go/bin/subfinder -version"
verificar "httpx"        "$HOME/go/bin/httpx -version"
verificar "nuclei"       "$HOME/go/bin/nuclei -version"
verificar "ffuf"         "$HOME/go/bin/ffuf -V"
verificar "gau"          "$HOME/go/bin/gau --version"
verificar "waybackurls"  "$HOME/go/bin/waybackurls -h"

python3 -c "import flask"       &>/dev/null && ok "flask" || erro "flask"
python3 -c "import requests"    &>/dev/null && ok "requests" || erro "requests"
python3 -c "import apscheduler" &>/dev/null && ok "apscheduler" || erro "apscheduler"
python3 -c "import shodan"      &>/dev/null && ok "shodan" || erro "shodan (opcional)"
python3 -c "import twocaptcha"  &>/dev/null && ok "2captcha" || erro "2captcha (opcional)"
python3 -c "from playwright.sync_api import sync_playwright" &>/dev/null \
    && ok "playwright" || erro "playwright (instale: python3 -m playwright install chromium)"

[[ -d "$SECLISTS_DIR" ]] && ok "SecLists em $SECLISTS_DIR" || echo -e "${YELLOW}[!]${NC} SecLists não instalado"

# ── resumo ────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✔  Instalação concluída!${NC}"
echo -e "${GREEN}${BOLD}════════════════════════════════════════════${NC}"
echo ""
echo -e "  Toolkit em:  ${CYAN}$TOOLKIT_DIR${NC}"
echo -e "  Log em:      ${CYAN}$LOG${NC}"
echo ""
echo -e "${YELLOW}${BOLD}Próximos passos:${NC}"
echo ""
echo -e "  1. Recarregue o shell:"
echo -e "     ${CYAN}source ~/.bashrc${NC}  ou abra novo terminal"
echo ""
echo -e "  2. Configure suas chaves no .env:"
echo -e "     ${CYAN}nano $TOOLKIT_DIR/.env${NC}"
echo ""
echo -e "  3. Gere o token da API:"
echo -e "     ${CYAN}make token${NC}  (no diretório do toolkit)"
echo ""
echo -e "  4. Suba a interface web:"
echo -e "     ${CYAN}docker compose up --build${NC}"
echo -e "     ${CYAN}open http://localhost:8080${NC}"
echo ""
echo -e "  5. Ou use direto no terminal:"
echo -e "     ${CYAN}recon alvo.com${NC}"
echo -e "     ${CYAN}bb-cred --url https://alvo.com/login --tipo php --cpf${NC}"
echo -e "     ${CYAN}bb-sgc --base http://localhost:8080${NC}"
echo ""
echo -e "  6. Estude (gratuito):"
echo -e "     ${CYAN}https://portswigger.net/web-security${NC}"
echo ""
echo -e "${RED}Lembrete: só testar com autorização escrita.${NC}"
