#!/usr/bin/env python3
"""
report.py — gera relatório HTML profissional a partir do output do recon-full.sh

Uso:
    python3 report.py <pasta_de_saida_do_recon>
    python3 report.py recon_alvo.com_20260827_120000/

ATENÇÃO: use APENAS em alvos com autorização escrita.
"""

import json
import sys
import os
import re
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from collections import defaultdict

# ── argumentos ────────────────────────────────────────────────
if len(sys.argv) < 2:
    print("Uso: python3 report.py <pasta_recon>")
    sys.exit(1)

RECON_DIR = Path(sys.argv[1])
if not RECON_DIR.exists():
    print(f"[ERRO] Pasta não encontrada: {RECON_DIR}")
    sys.exit(1)

ALVO = str(RECON_DIR.name).replace("recon_", "").rsplit("_", 2)[0]
OUTPUT_HTML = RECON_DIR / "relatorio" / "report.html"
OUTPUT_HTML.parent.mkdir(parents=True, exist_ok=True)

# ── leitura dos dados ─────────────────────────────────────────
def ler_linhas(path):
    try:
        return [l.strip() for l in Path(path).read_text(errors="ignore").splitlines() if l.strip()]
    except Exception:
        return []

def ler_json(path):
    try:
        return json.loads(Path(path).read_text(errors="ignore"))
    except Exception:
        return {}

# subdomínios
subdominios = ler_linhas(RECON_DIR / "subdominios" / "raw.txt")

# hosts ativos
hosts_raw = ler_linhas(RECON_DIR / "hosts" / "ativos.txt")
hosts_ativos = []
for linha in hosts_raw:
    partes = linha.split()
    if partes:
        url = partes[0]
        status = next((p.strip("[]") for p in partes if p.startswith("[")), "?")
        titulo = " ".join(partes[2:]) if len(partes) > 2 else ""
        hosts_ativos.append({"url": url, "status": status, "titulo": titulo})

# parâmetros
urls_params = ler_linhas(RECON_DIR / "params" / "com_parametros.txt")
arquivos_sensiveis = ler_linhas(RECON_DIR / "params" / "arquivos_sensiveis.txt")

# endpoints fuzzing
endpoints_fuzz = ler_linhas(RECON_DIR / "fuzzing" / "todos_endpoints.txt")

# nuclei findings
nuclei_txt = ler_linhas(RECON_DIR / "nuclei" / "findings.txt")
nuclei_json_lines = ler_linhas(RECON_DIR / "nuclei" / "findings.json")
nuclei_findings = []
for linha in nuclei_json_lines:
    try:
        nuclei_findings.append(json.loads(linha))
    except Exception:
        pass

# classificação
CLASS_DIR = RECON_DIR / "classificacao"
VULN_TIPOS = [
    ("IDOR",              "idor.txt",             "#e74c3c", "🔴", "Crítico"),
    ("SSRF",              "ssrf.txt",              "#e74c3c", "🔴", "Crítico"),
    ("Command Injection", "command_injection.txt", "#e74c3c", "🔴", "Crítico"),
    ("SQL Injection",     "sql_injection.txt",     "#e67e22", "🟠", "Alto"),
    ("LFI / RFI",         "lfi___rfi.txt",         "#e67e22", "🟠", "Alto"),
    ("Open Redirect",     "open_redirect.txt",     "#f39c12", "🟡", "Médio"),
    ("Mass Assignment",   "mass_assignment.txt",   "#f39c12", "🟡", "Médio"),
    ("JWT / Auth",        "jwt_auth.txt",          "#f39c12", "🟡", "Médio"),
    ("XSS",               "xss.txt",               "#3498db", "🔵", "Baixo"),
]

classificacao = {}
for nome, arquivo, cor, emoji, severidade in VULN_TIPOS:
    linhas = ler_linhas(CLASS_DIR / arquivo)
    urls_achadas = [l for l in linhas if l.startswith("URL")]
    params_achados = [l for l in linhas if l.startswith("PARAM")]
    classificacao[nome] = {
        "cor": cor, "emoji": emoji, "severidade": severidade,
        "total": len(urls_achadas),
        "urls": [u.replace("URL   : ", "") for u in urls_achadas[:50]],
        "params": [p.replace("PARAM : ", "") for p in params_achados[:50]],
    }

# ── métricas gerais ───────────────────────────────────────────
total_params_classificados = sum(v["total"] for v in classificacao.values())
total_criticos = sum(v["total"] for k, v in classificacao.items() if v["severidade"] == "Crítico")
total_altos    = sum(v["total"] for k, v in classificacao.items() if v["severidade"] == "Alto")
total_medios   = sum(v["total"] for k, v in classificacao.items() if v["severidade"] == "Médio")
total_baixos   = sum(v["total"] for k, v in classificacao.items() if v["severidade"] == "Baixo")

# ── geração do HTML ───────────────────────────────────────────
def escapar(s):
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"','&quot;')

def badge_status(status):
    cores = {"200": "#27ae60", "403": "#e67e22", "301": "#3498db", "302": "#3498db", "404": "#95a5a6"}
    cor = cores.get(str(status), "#7f8c8d")
    return f'<span style="background:{cor};color:#fff;padding:2px 8px;border-radius:4px;font-size:12px;font-weight:bold">{escapar(status)}</span>'

def badge_sev(sev):
    cores = {"Crítico": "#e74c3c", "Alto": "#e67e22", "Médio": "#f39c12", "Baixo": "#3498db"}
    cor = cores.get(sev, "#95a5a6")
    return f'<span style="background:{cor};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px">{escapar(sev)}</span>'

def linhas_class_html(nome):
    v = classificacao.get(nome, {})
    if not v.get("urls"):
        return "<p style='color:#95a5a6;font-style:italic'>Nenhum parâmetro encontrado para este tipo.</p>"
    rows = []
    for url, param in zip(v["urls"], v["params"]):
        rows.append(f"""
        <tr>
          <td style='font-family:monospace;font-size:13px;word-break:break-all'>
            <a href='{escapar(url)}' target='_blank' style='color:#3498db'>{escapar(url[:120])}{'...' if len(url) > 120 else ''}</a>
          </td>
          <td><code style='background:#2d2d2d;padding:2px 6px;border-radius:3px;color:#e74c3c'>{escapar(param)}</code></td>
          <td><button onclick="navigator.clipboard.writeText('{escapar(url)}')"
              style='background:#34495e;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px'>
              📋 Copiar
          </button></td>
        </tr>""")
    return f"""<table style='width:100%;border-collapse:collapse'>
        <thead><tr style='background:#2d2d2d'>
          <th style='padding:8px;text-align:left;color:#ecf0f1'>URL</th>
          <th style='padding:8px;text-align:left;color:#ecf0f1'>Parâmetro</th>
          <th style='padding:8px;width:80px'></th>
        </tr></thead>
        <tbody>{''.join(rows)}</tbody>
    </table>"""

def nuclei_html():
    if not nuclei_findings:
        return "<p style='color:#95a5a6;font-style:italic'>Nenhum finding do nuclei encontrado (ou modo rápido ativo).</p>"
    rows = []
    for f in nuclei_findings[:100]:
        nome = f.get("info", {}).get("name", "?")
        sev  = f.get("info", {}).get("severity", "info").capitalize()
        url  = f.get("matched-at", f.get("host", "?"))
        rows.append(f"""<tr style='border-bottom:1px solid #2d2d2d'>
          <td style='padding:8px'>{badge_sev(sev)}</td>
          <td style='padding:8px;font-weight:bold;color:#ecf0f1'>{escapar(nome)}</td>
          <td style='padding:8px;font-family:monospace;font-size:12px;word-break:break-all'>
            <a href='{escapar(url)}' target='_blank' style='color:#3498db'>{escapar(url)}</a>
          </td>
        </tr>""")
    return f"""<table style='width:100%;border-collapse:collapse'>
        <thead><tr style='background:#2d2d2d'>
          <th style='padding:8px;text-align:left;color:#ecf0f1'>Severidade</th>
          <th style='padding:8px;text-align:left;color:#ecf0f1'>Finding</th>
          <th style='padding:8px;text-align:left;color:#ecf0f1'>URL</th>
        </tr></thead>
        <tbody>{''.join(rows)}</tbody>
    </table>"""

tabs_html = ""
paineis_html = ""
for idx, (nome, arquivo, cor, emoji, sev) in enumerate(VULN_TIPOS):
    count = classificacao[nome]["total"]
    if count == 0:
        continue
    tid = nome.lower().replace(" ", "_").replace("/", "_")
    ativo = "active" if idx == 0 else ""
    tabs_html += f"""<button class='tab-btn {ativo}' onclick="showTab('{tid}', this)"
        style='background:{"#1a1a2e" if ativo else "#16213e"};color:#ecf0f1;border:none;
               padding:10px 18px;cursor:pointer;border-bottom:3px solid {""+cor+"" if ativo else "transparent"};
               transition:all .2s;font-size:14px'>
        {emoji} {escapar(nome)} <span style='background:{cor};color:#fff;
        border-radius:10px;padding:1px 7px;font-size:11px;margin-left:4px'>{count}</span>
    </button>"""
    paineis_html += f"""<div id='tab_{tid}' class='tab-panel' style='display:{"block" if ativo else "none"};padding:16px'>
        <h3 style='color:{cor};margin-top:0'>{emoji} {escapar(nome)} {badge_sev(sev)}</h3>
        {linhas_class_html(nome)}
    </div>"""

html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Recon Report — {escapar(ALVO)}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: #0f0f23; color: #ecf0f1; font-family: 'Segoe UI', Arial, sans-serif; }}
  .container {{ max-width: 1200px; margin: 0 auto; padding: 24px; }}
  .header {{ background: linear-gradient(135deg, #1a1a2e, #16213e);
             border-radius: 12px; padding: 28px; margin-bottom: 24px;
             border-left: 5px solid #e74c3c; }}
  .header h1 {{ font-size: 26px; color: #e74c3c; }}
  .header p  {{ color: #95a5a6; margin-top: 6px; font-size: 14px; }}
  .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 16px; margin-bottom: 24px; }}
  .card {{ background: #1a1a2e; border-radius: 10px; padding: 20px; text-align: center;
           border-top: 3px solid var(--c); }}
  .card .num {{ font-size: 36px; font-weight: bold; color: var(--c); }}
  .card .lbl {{ font-size: 13px; color: #95a5a6; margin-top: 4px; }}
  .section {{ background: #1a1a2e; border-radius: 12px; margin-bottom: 20px; overflow: hidden; }}
  .section-header {{ padding: 16px 20px; background: #16213e; display: flex;
                     justify-content: space-between; align-items: center; cursor: pointer; }}
  .section-header h2 {{ font-size: 16px; color: #ecf0f1; }}
  .section-body {{ padding: 16px; }}
  .tab-bar {{ display: flex; flex-wrap: wrap; background: #16213e; border-radius: 8px 8px 0 0;
              overflow: hidden; }}
  .tab-panel {{ background: #1a1a2e; min-height: 200px; border-radius: 0 0 8px 8px; }}
  table {{ font-size: 13px; }}
  tbody tr:hover {{ background: rgba(255,255,255,.04); }}
  td, th {{ padding: 10px 12px; text-align: left; }}
  a {{ color: #3498db; }}
  code {{ font-size: 13px; }}
  .chip {{ display: inline-block; padding: 2px 8px; border-radius: 4px;
           font-size: 12px; font-weight: bold; }}
  .warn {{ background: #2d1b00; border: 1px solid #e67e22; border-radius: 8px;
           padding: 12px 16px; margin: 12px 0; color: #f39c12; font-size: 13px; }}
</style>
</head>
<body>
<div class="container">

  <!-- HEADER -->
  <div class="header">
    <h1>🔍 Recon Report — {escapar(ALVO)}</h1>
    <p>Gerado em {datetime.now().strftime("%d/%m/%Y às %H:%M")} &nbsp;|&nbsp;
       Pasta: {escapar(str(RECON_DIR))}</p>
    <div class="warn">
      ⚠️ Este relatório foi gerado a partir de um programa de bug bounty com autorização escrita.
      Invasão sem autorização é crime (art. 154-A CP). Não compartilhe este arquivo publicamente.
    </div>
  </div>

  <!-- CARDS DE RESUMO -->
  <div class="cards">
    <div class="card" style="--c:#e74c3c">
      <div class="num">{len(subdominios)}</div>
      <div class="lbl">Subdomínios</div>
    </div>
    <div class="card" style="--c:#27ae60">
      <div class="num">{len(hosts_ativos)}</div>
      <div class="lbl">Hosts Ativos</div>
    </div>
    <div class="card" style="--c:#3498db">
      <div class="num">{len(urls_params)}</div>
      <div class="lbl">URLs c/ Params</div>
    </div>
    <div class="card" style="--c:#9b59b6">
      <div class="num">{len(endpoints_fuzz)}</div>
      <div class="lbl">Endpoints Fuzzing</div>
    </div>
    <div class="card" style="--c:#e74c3c">
      <div class="num">{total_criticos}</div>
      <div class="lbl">Críticos</div>
    </div>
    <div class="card" style="--c:#e67e22">
      <div class="num">{total_altos}</div>
      <div class="lbl">Altos</div>
    </div>
    <div class="card" style="--c:#f39c12">
      <div class="num">{total_medios}</div>
      <div class="lbl">Médios</div>
    </div>
    <div class="card" style="--c:#3498db">
      <div class="num">{total_baixos}</div>
      <div class="lbl">Baixos</div>
    </div>
  </div>

  <!-- PARÂMETROS POR VULNERABILIDADE -->
  <div class="section">
    <div class="section-header" onclick="toggleSection('vuln')">
      <h2>🎯 Parâmetros Classificados por Vulnerabilidade ({total_params_classificados})</h2>
      <span id="icon_vuln">▾</span>
    </div>
    <div id="body_vuln">
      <div class="tab-bar">{tabs_html}</div>
      {paineis_html}
    </div>
  </div>

  <!-- NUCLEI FINDINGS -->
  <div class="section">
    <div class="section-header" onclick="toggleSection('nuclei')">
      <h2>⚡ Nuclei Findings ({len(nuclei_findings)})</h2>
      <span id="icon_nuclei">▾</span>
    </div>
    <div id="body_nuclei" style="padding:16px">
      {nuclei_html()}
    </div>
  </div>

  <!-- HOSTS ATIVOS -->
  <div class="section">
    <div class="section-header" onclick="toggleSection('hosts')">
      <h2>🌐 Hosts Ativos ({len(hosts_ativos)})</h2>
      <span id="icon_hosts">▾</span>
    </div>
    <div id="body_hosts" style="padding:16px">
      <table style="width:100%;border-collapse:collapse">
        <thead><tr style="background:#2d2d2d">
          <th style="padding:8px;color:#ecf0f1">Status</th>
          <th style="padding:8px;color:#ecf0f1">URL</th>
          <th style="padding:8px;color:#ecf0f1">Título</th>
        </tr></thead>
        <tbody>
          {"".join(f"<tr style='border-bottom:1px solid #2d2d2d'><td style='padding:8px'>{badge_status(h['status'])}</td><td style='padding:8px;font-family:monospace;font-size:12px'><a href='{escapar(h['url'])}' target='_blank'>{escapar(h['url'])}</a></td><td style='padding:8px;font-size:12px;color:#95a5a6'>{escapar(h['titulo'][:60])}</td></tr>" for h in hosts_ativos[:100])}
        </tbody>
      </table>
    </div>
  </div>

  <!-- ARQUIVOS SENSÍVEIS -->
  <div class="section">
    <div class="section-header" onclick="toggleSection('sensiveis')">
      <h2>⚠️ Arquivos Sensíveis ({len(arquivos_sensiveis)})</h2>
      <span id="icon_sensiveis">▾</span>
    </div>
    <div id="body_sensiveis" style="padding:16px">
      {"".join(f"<div style='margin:6px 0;font-family:monospace;font-size:13px'><a href='{escapar(u)}' target='_blank' style='color:#e67e22'>{escapar(u)}</a></div>" for u in arquivos_sensiveis[:100]) or "<p style='color:#95a5a6;font-style:italic'>Nenhum arquivo sensível encontrado.</p>"}
    </div>
  </div>

  <!-- ENDPOINTS DE FUZZING -->
  <div class="section">
    <div class="section-header" onclick="toggleSection('fuzz')">
      <h2>🔎 Endpoints Descobertos (ffuf) ({len(endpoints_fuzz)})</h2>
      <span id="icon_fuzz">▾</span>
    </div>
    <div id="body_fuzz" style="padding:16px">
      <table style="width:100%;border-collapse:collapse">
        <thead><tr style="background:#2d2d2d">
          <th style="padding:8px;color:#ecf0f1;width:80px">Status</th>
          <th style="padding:8px;color:#ecf0f1;width:100px">Tamanho</th>
          <th style="padding:8px;color:#ecf0f1">URL</th>
        </tr></thead>
        <tbody>
          {"".join((lambda p: f"<tr style='border-bottom:1px solid #2d2d2d'><td style='padding:8px'>{badge_status(p[0])}</td><td style='padding:8px;font-size:12px;color:#95a5a6'>{escapar(p[1]) if len(p)>1 else ''}</td><td style='padding:8px;font-family:monospace;font-size:12px;word-break:break-all'><a href='{escapar(p[2] if len(p)>2 else '')}' target='_blank' style='color:#3498db'>{escapar(p[2] if len(p)>2 else linha[:120])}</a></td></tr>")(linha.split()) for linha in endpoints_fuzz[:200]) or "<p style='color:#95a5a6;font-style:italic'>Nenhum endpoint de fuzzing encontrado.</p>"}
        </tbody>
      </table>
    </div>
  </div>

  <!-- SUBDOMÍNIOS -->
  <div class="section">
    <div class="section-header" onclick="toggleSection('subs')">
      <h2>📡 Subdomínios ({len(subdominios)})</h2>
      <span id="icon_subs">▾</span>
    </div>
    <div id="body_subs" style="padding:16px;display:flex;flex-wrap:wrap;gap:8px">
      {"".join(f"<span style='background:#16213e;padding:4px 10px;border-radius:4px;font-family:monospace;font-size:12px;color:#ecf0f1'>{escapar(s)}</span>" for s in sorted(subdominios))}
    </div>
  </div>

  <p style="text-align:center;color:#2d2d2d;font-size:12px;margin-top:24px">
    Gerado por recon-full.sh + report.py &nbsp;|&nbsp; {escapar(ALVO)} &nbsp;|&nbsp; {datetime.now().strftime("%d/%m/%Y")}
  </p>
</div>

<script>
function showTab(id, btn) {{
  document.querySelectorAll('.tab-panel').forEach(p => p.style.display = 'none');
  document.querySelectorAll('.tab-btn').forEach(b => {{
    b.style.background = '#16213e';
    b.style.borderBottom = '3px solid transparent';
  }});
  document.getElementById('tab_' + id).style.display = 'block';
  btn.style.background = '#1a1a2e';
  btn.style.borderBottom = '3px solid ' + btn.querySelector('span').style.background;
}}

function toggleSection(id) {{
  const body = document.getElementById('body_' + id);
  const icon = document.getElementById('icon_' + id);
  if (body.style.display === 'none') {{
    body.style.display = 'block';
    icon.textContent = '▾';
  }} else {{
    body.style.display = 'none';
    icon.textContent = '▸';
  }}
}}
</script>
</body>
</html>"""

OUTPUT_HTML.write_text(html, encoding="utf-8")
print(f"[✔] Relatório gerado: {OUTPUT_HTML}")
print(f"    Abra no navegador: file://{OUTPUT_HTML.resolve()}")
