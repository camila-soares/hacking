#!/bin/bash
# ============================================================
#  install.sh — instalação automática do Bug Bounty Toolkit
#  Suporte: Ubuntu/Debian, Kali Linux, Fedora/RHEL, macOS
#
#  Uso: bash install.sh [--minimal] [--sem-seclists]
#    --minimal      instala só as Go tools (sem SecLists, sem extras)
#    --sem-seclists  pula o download do SecLists (é grande: ~1GB)
#
#  ATENÇÃO: use APENAS em alvos com autorização escrita.
# ============================================================

set -euo pipefail

# ── flags ─────────────────────────────────────────────────────
MINIMAL=false
SEM_SECLISTS=false
for arg in "$@"; do
    [[ "$arg" == "--minimal"      ]] && MINIMAL=true
    [[ "$arg" == "--sem-seclists" ]] && SEM_SECLISTS=true
done

# ── cores ─────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

# ── helpers ───────────────────────────────────────────────────
ok()      { echo -e "${GREEN}[✔]${NC} $1"; }
info()    { echo -e "${YELLOW}[→]${NC} $1"; }
erro()    { echo -e "${RED}[✘]${NC} $1"; }
passo()   { echo -e "\n${CYAN}${BOLD}▶ $1${NC}"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
destaque(){ echo -e "${BOLD}$1${NC}"; }

pergunta() {
    echo -en "${BLUE}[?]${NC} $1 [S/n]: "
    read -r resp
    [[ -z "$resp" || "$resp" =~ ^[Ss]$ ]]
}

# ── detectar OS ───────────────────────────────────────────────
detectar_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [[ -f /etc/kali-release ]]; then
        echo "kali"
    elif [[ -f /etc/debian_version ]]; then
        echo "debian"
    elif [[ -f /etc/fedora-release ]] || [[ -f /etc/redhat-release ]]; then
        echo "fedora"
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo "linux"
    else
        echo "desconhecido"
    fi
}

OS=$(detectar_os)

# ── banner ────────────────────────────────────────────────────
clear
echo -e "${CYAN}${BOLD}"
cat << 'BANNER'
  ██████╗ ██╗   ██╗ ██████╗     ██████╗  ██████╗ ██╗   ██╗███╗   ██╗████████╗██╗   ██╗
  ██╔══██╗██║   ██║██╔════╝     ██╔══██╗██╔═══██╗██║   ██║████╗  ██║╚══██╔══╝╚██╗ ██╔╝
  ██████╔╝██║   ██║██║  ███╗    ██████╔╝██║   ██║██║   ██║██╔██╗ ██║   ██║    ╚████╔╝
  ██╔══██╗██║   ██║██║   ██║    ██╔══██╗██║   ██║██║   ██║██║╚██╗██║   ██║     ╚██╔╝
  ██████╔╝╚██████╔╝╚██████╔╝    ██████╔╝╚██████╔╝╚██████╔╝██║ ╚████║   ██║      ██║
  ╚═════╝  ╚═════╝  ╚═════╝     ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝   ╚═╝      ╚═╝
BANNER
echo -e "${NC}"
echo -e "  ${BOLD}Bug Bounty Toolkit — Instalador automático${NC}"
echo -e "  OS detectado: ${CYAN}${OS}${NC}  |  Minimal: ${MINIMAL}  |  SecLists: $( $SEM_SECLISTS && echo 'pular' || echo 'instalar')"
echo ""
echo -e "${RED}${BOLD}  AVISO: use APENAS em ambientes de teste e alvos autorizados.${NC}"
echo -e "  Invasão sem autorização é crime — art. 154-A do Código Penal.\n"

pergunta "Confirma que entendeu e quer continuar?" || { echo "Instalação cancelada."; exit 0; }

# ── diretório base ────────────────────────────────────────────
TOOLKIT_DIR="$HOME/bug-bounty-toolkit"
TOOLS_DIR="$HOME/go/bin"
SECLISTS_DIR="$HOME/SecLists"
LOG_FILE="$TOOLKIT_DIR/install.log"

mkdir -p "$TOOLKIT_DIR" "$TOOLS_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

# ─────────────────────────────────────────────────────────────
# PASSO 1 — Dependências do sistema
# ─────────────────────────────────────────────────────────────
passo "PASSO 1/6 — Dependências do sistema"

instalar_pacote() {
    local PKG="$1"
    case "$OS" in
        macos)
            brew list "$PKG" &>/dev/null || brew install "$PKG" ;;
        kali|debian)
            dpkg -l "$PKG" &>/dev/null || sudo apt-get install -y "$PKG" ;;
        fedora)
            rpm -q "$PKG" &>/dev/null || sudo dnf install -y "$PKG" ;;
        *)
            warn "OS não reconhecido — instale $PKG manualmente se der erro";;
    esac
}

# git
if command -v git &>/dev/null; then
    ok "git $(git --version | awk '{print $3}')"
else
    info "Instalando git..."
    instalar_pacote git
    ok "git instalado"
fi

# python3
if command -v python3 &>/dev/null; then
    ok "python3 $(python3 --version 2>&1 | awk '{print $2}')"
else
    info "Instalando python3..."
    instalar_pacote python3
    ok "python3 instalado"
fi

# curl
command -v curl &>/dev/null && ok "curl ok" || { instalar_pacote curl && ok "curl instalado"; }

# make / build tools (necessário para algumas Go tools)
if [[ "$OS" != "macos" ]]; then
    command -v make &>/dev/null && ok "build-essential ok" || {
        info "Instalando build-essential..."
        sudo apt-get install -y build-essential 2>/dev/null || true
        ok "build-essential instalado"
    }
fi

# ─────────────────────────────────────────────────────────────
# PASSO 2 — Go language
# ─────────────────────────────────────────────────────────────
passo "PASSO 2/6 — Go language"

GO_MIN_VERSION="1.21"

versao_go_ok() {
    local ver
    ver=$(go version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+' | head -1)
    [[ -n "$ver" ]] && python3 -c "exit(0 if tuple(map(int,'$ver'.split('.'))) >= tuple(map(int,'$GO_MIN_VERSION'.split('.'))) else 1)" 2>/dev/null
}

if versao_go_ok; then
    ok "Go $(go version | awk '{print $3}') já instalado"
else
    info "Instalando Go ${GO_MIN_VERSION}+..."
    GO_VERSION="1.22.4"

    case "$OS" in
        macos)
            if command -v brew &>/dev/null; then
                brew install go
            else
                erro "Homebrew não encontrado. Instale em: https://brew.sh"
                exit 1
            fi
            ;;
        *)
            ARCH=$(uname -m)
            [[ "$ARCH" == "aarch64" ]] && GOARCH="arm64" || GOARCH="amd64"
            GO_PKG="go${GO_VERSION}.linux-${GOARCH}.tar.gz"
            GO_URL="https://go.dev/dl/${GO_PKG}"

            info "Baixando ${GO_PKG}..."
            curl -fsSL "$GO_URL" -o "/tmp/${GO_PKG}"
            sudo rm -rf /usr/local/go
            sudo tar -C /usr/local -xzf "/tmp/${GO_PKG}"
            rm "/tmp/${GO_PKG}"
            ;;
    esac

    # configurar PATH para Go
    export PATH=$PATH:/usr/local/go/bin
    ok "Go ${GO_VERSION} instalado"
fi

# configurar GOPATH e PATH
export GOPATH="${HOME}/go"
export PATH=$PATH:${GOPATH}/bin:/usr/local/go/bin

# ─────────────────────────────────────────────────────────────
# PASSO 3 — Go tools de recon
# ─────────────────────────────────────────────────────────────
passo "PASSO 3/6 — Ferramentas de recon (Go)"

instalar_go_tool() {
    local NOME="$1"
    local PKG="$2"

    if command -v "$NOME" &>/dev/null; then
        ok "${NOME} já instalado"
        return
    fi

    info "Instalando ${NOME}..."
    if go install "${PKG}@latest" 2>/dev/null; then
        ok "${NOME} instalado"
    else
        erro "${NOME} — falha na instalação (verifique a conexão)"
    fi
}

instalar_go_tool subfinder   "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
instalar_go_tool httpx       "github.com/projectdiscovery/httpx/cmd/httpx"
instalar_go_tool nuclei      "github.com/projectdiscovery/nuclei/v3/cmd/nuclei"
instalar_go_tool gau         "github.com/lc/gau/v2/cmd/gau"
instalar_go_tool waybackurls "github.com/tomnomnom/waybackurls"
instalar_go_tool ffuf        "github.com/ffuf/ffuf/v2"

# extras úteis
if ! $MINIMAL; then
    instalar_go_tool anew   "github.com/tomnomnom/anew"
    instalar_go_tool qsreplace "github.com/tomnomnom/qsreplace"
    instalar_go_tool dalfox "github.com/hahwul/dalfox/v2"
fi

# atualizar templates do nuclei
info "Atualizando templates do nuclei..."
nuclei -update-templates -silent 2>/dev/null && ok "Templates nuclei atualizados" || warn "Nuclei templates: atualização manual pode ser necessária"

# ─────────────────────────────────────────────────────────────
# PASSO 4 — Python dependencies (para report.py)
# ─────────────────────────────────────────────────────────────
passo "PASSO 4/6 — Python"

if ! $MINIMAL; then
    # report.py usa só stdlib — verificar versão
    PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    ok "Python ${PY_VER} — report.py usa apenas stdlib (sem pip necessário)"
fi

# ─────────────────────────────────────────────────────────────
# PASSO 5 — SecLists
# ─────────────────────────────────────────────────────────────
passo "PASSO 5/6 — SecLists (wordlists)"

if $SEM_SECLISTS || $MINIMAL; then
    warn "SecLists pulado. Para instalar depois: git clone https://github.com/danielmiessler/SecLists ~/SecLists"
elif [[ -d "$SECLISTS_DIR/.git" ]]; then
    info "SecLists já existe — atualizando..."
    git -C "$SECLISTS_DIR" pull --ff-only 2>/dev/null && ok "SecLists atualizado" || warn "SecLists: não foi possível atualizar"
else
    if pergunta "SecLists tem ~1GB. Deseja instalar? (recomendado)"; then
        info "Clonando SecLists em ${SECLISTS_DIR}..."
        info "Isso pode demorar alguns minutos dependendo da conexão..."
        git clone --depth 1 \
            https://github.com/danielmiessler/SecLists.git \
            "$SECLISTS_DIR" 2>&1 | tail -5
        ok "SecLists instalado em ${SECLISTS_DIR}"
    else
        # wordlist mínima embutida pra não bloquear o ffuf
        mkdir -p "${SECLISTS_DIR}/Discovery/Web-Content"
        info "Criando wordlist mínima (fallback)..."
        cat > "${SECLISTS_DIR}/Discovery/Web-Content/raft-medium-words.txt" << 'WLIST'
admin
api
v1
v2
v3
backup
config
test
debug
upload
download
export
import
internal
health
status
metrics
swagger
openapi
graphql
login
logout
register
profile
dashboard
settings
users
accounts
orders
files
documents
reports
.env
.git
.htaccess
web.config
WLIST
        ok "Wordlist mínima criada em ${SECLISTS_DIR}"
    fi
fi

# ─────────────────────────────────────────────────────────────
# PASSO 6 — Configurar PATH permanente
# ─────────────────────────────────────────────────────────────
passo "PASSO 6/6 — Configurando PATH"

EXPORT_BLOCK='
# ── Bug Bounty Toolkit ──────────────────────────────────────
export GOPATH="$HOME/go"
export PATH="$PATH:/usr/local/go/bin:$GOPATH/bin"
# ────────────────────────────────────────────────────────────'

adicionar_ao_shell() {
    local ARQUIVO="$1"
    if [[ -f "$ARQUIVO" ]]; then
        if ! grep -q "Bug Bounty Toolkit" "$ARQUIVO" 2>/dev/null; then
            echo "$EXPORT_BLOCK" >> "$ARQUIVO"
            ok "PATH adicionado em ${ARQUIVO}"
        else
            ok "${ARQUIVO} já configurado"
        fi
    fi
}

# detectar shells ativos
[[ -f "$HOME/.bashrc"  ]] && adicionar_ao_shell "$HOME/.bashrc"
[[ -f "$HOME/.zshrc"   ]] && adicionar_ao_shell "$HOME/.zshrc"
[[ -f "$HOME/.profile" ]] && adicionar_ao_shell "$HOME/.profile"

# macOS usa .zshrc por padrão
[[ "$OS" == "macos" && ! -f "$HOME/.zshrc" ]] && {
    touch "$HOME/.zshrc"
    adicionar_ao_shell "$HOME/.zshrc"
}

# ─────────────────────────────────────────────────────────────
# Copiar scripts do toolkit
# ─────────────────────────────────────────────────────────────
info "Copiando scripts para ${TOOLKIT_DIR}..."

# copia os scripts se estiverem na mesma pasta
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in recon.sh recon-full.sh report.py README.md; do
    if [[ -f "${SCRIPT_DIR}/${f}" ]]; then
        cp "${SCRIPT_DIR}/${f}" "${TOOLKIT_DIR}/"
        ok "Copiado: ${f}"
    fi
done

chmod +x "${TOOLKIT_DIR}/recon.sh"    2>/dev/null || true
chmod +x "${TOOLKIT_DIR}/recon-full.sh" 2>/dev/null || true

# criar alias no shell
ALIAS_BLOCK="
# ── Bug Bounty Toolkit aliases ──────────────────────────────
alias recon='${TOOLKIT_DIR}/recon.sh'
alias recon-full='${TOOLKIT_DIR}/recon-full.sh'
alias bb-report='python3 ${TOOLKIT_DIR}/report.py'
# ────────────────────────────────────────────────────────────"

for SHELLRC in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [[ -f "$SHELLRC" ]] && ! grep -q "Bug Bounty Toolkit aliases" "$SHELLRC" 2>/dev/null; then
        echo "$ALIAS_BLOCK" >> "$SHELLRC"
        ok "Aliases adicionados em ${SHELLRC}"
    fi
done

# ─────────────────────────────────────────────────────────────
# VERIFICAÇÃO FINAL
# ─────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}════════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}  Verificação final${NC}"
echo -e "${CYAN}${BOLD}════════════════════════════════════════════${NC}\n"

ERROS=0
verificar() {
    local NOME="$1"
    local CMD="$2"
    if eval "$CMD" &>/dev/null; then
        local VER
        VER=$(eval "$CMD" 2>&1 | grep -oE '[0-9]+\.[0-9]+[0-9.]*' | head -1) || true
        ok "${NOME} ${VER}"
    else
        erro "${NOME} — NÃO encontrado"
        ERROS=$((ERROS + 1))
    fi
}

verificar "go"           "go version"
verificar "python3"      "python3 --version"
verificar "subfinder"    "$HOME/go/bin/subfinder -version"
verificar "httpx"        "$HOME/go/bin/httpx -version"
verificar "nuclei"       "$HOME/go/bin/nuclei -version"
verificar "ffuf"         "$HOME/go/bin/ffuf -V"
verificar "gau"          "$HOME/go/bin/gau --version"
verificar "waybackurls"  "$HOME/go/bin/waybackurls -h"

if ! $MINIMAL; then
    verificar "dalfox" "$HOME/go/bin/dalfox version"
    verificar "anew"   "$HOME/go/bin/anew --help"
fi

[[ -d "$SECLISTS_DIR" ]] && ok "SecLists em ${SECLISTS_DIR}" || warn "SecLists não instalado"

# ─────────────────────────────────────────────────────────────
# RESUMO FINAL
# ─────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}════════════════════════════════════════════${NC}"
if [[ $ERROS -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}  ✔  Instalação concluída sem erros!${NC}"
else
    echo -e "${RED}${BOLD}  ✘  Instalação com ${ERROS} erro(s) — verifique acima${NC}"
fi
echo -e "${CYAN}${BOLD}════════════════════════════════════════════${NC}\n"

echo -e "${BOLD}Toolkit instalado em:${NC} ${CYAN}${TOOLKIT_DIR}${NC}"
echo -e "${BOLD}Log completo em:${NC}      ${CYAN}${LOG_FILE}${NC}"
echo ""
echo -e "${YELLOW}${BOLD}Próximos passos:${NC}"
echo ""
echo -e "  1. Recarregue o shell:"
echo -e "     ${CYAN}source ~/.bashrc${NC}   ou abra um novo terminal"
echo ""
echo -e "  2. Teste a instalação:"
echo -e "     ${CYAN}subfinder -version && httpx -version && ffuf -V${NC}"
echo ""
echo -e "  3. Rode o recon num alvo autorizado:"
echo -e "     ${CYAN}recon-full alvo.com${NC}"
echo ""
echo -e "  4. Gere o relatório HTML:"
echo -e "     ${CYAN}bb-report recon_alvo.com_TIMESTAMP/${NC}"
echo ""
echo -e "  5. Instale o Burp Suite Community (manual):"
echo -e "     ${CYAN}https://portswigger.net/burp/communitydownload${NC}"
echo ""
echo -e "  6. Estude (gratuito):"
echo -e "     ${CYAN}https://portswigger.net/web-security${NC}"
echo ""
echo -e "${RED}Lembrete: só testar com autorização escrita.${NC}"
