# Checklist de defesa web — IDOR / SQLi / BAC no seu stack

Mapeia as 3 falhas da Aula 4 para controles concretos em **Spring Boot 3 / Java 21 + Angular + PostgreSQL** (o stack do SGC). A ideia: para cada coisa que você aprende a explorar no lab, existe aqui a correção + o teste que impede a regressão.

> Regra de ouro das 3 falhas: **negue por padrão, autorize no servidor, valide o dono do recurso.** Frontend é UX, não segurança.

---

## 1. SQL Injection

- [ ] Nunca concatenar string em JPQL nem em query nativa. Usar binding de parâmetros (`?1`, `:nome`).
- [ ] `@Query` sempre com parâmetros nomeados; nunca montar a query com `+ variavel`.
- [ ] Ordenação/filtro vindos do cliente (`sort`, `order`, nome de coluna): **whitelist**, nunca interpolar direto no SQL.
- [ ] Usuário do banco com **menor privilégio** (a app não precisa de `DROP`/`DDL` em runtime).
- [ ] Validação/sanitização de input na borda (Bean Validation nos DTOs).
- [ ] **Teste:** teste de repositório mandando `' OR '1'='1`, `'; DROP TABLE ...` e afins, esperando resultado vazio / erro tratado — não vazamento.

## 2. IDOR (Insecure Direct Object Reference)

- [ ] ID vindo do cliente **nunca** é confiável por si só: sempre checar que o recurso pertence ao principal autenticado.
- [ ] Checagem de posse no service (`recurso.getOwner().equals(usuarioLogado)`), ou `@PostAuthorize("returnObject.owner == authentication.name")`.
- [ ] UUID em vez de ID sequencial é **defesa em profundidade**, não substitui a checagem de autorização.
- [ ] Mesma regra em **todos** os verbos: GET, PUT, PATCH, DELETE.
- [ ] **Teste (você já começou isto no SGC):** matriz Usuário A × recurso do Usuário B para cada endpoint — A recebe 403/404, nunca 200. Rodar no CI.

## 3. Broken Access Control

- [ ] Autorização no **servidor** em cada endpoint, inclusive POST/PUT/DELETE de API.
- [ ] Method security (`@PreAuthorize`) por papel + por posse, com **deny-by-default**.
- [ ] Guards do Angular são só experiência do usuário — a rota `/admin` tem que ser barrada no backend também.
- [ ] JWT com **escopo/roles validados no servidor**; não confiar em claim sem verificar; expiração curta.
- [ ] **Logar** tentativas de acesso negado e alertar sobre padrões suspeitos.
- [ ] **Teste:** matriz endpoint × papel no CI (cada papel só acessa o que deve).

---

## Fechando o loop no SGC

1. Roda o ataque no lab (DVWA / Juice Shop / WebGoat) até entender o padrão.
2. Procura o mesmo padrão nos endpoints do SGC.
3. Aplica o controle da lista acima.
4. Escreve o teste de regressão (JUnit) que trava a falha pra sempre.
5. Bônus de CI: SAST + DAST no pipeline (o "teste de autorização em CI/CD" da aula).

Isso já é, na prática, o formato de um laudo: achado → risco → evidência → correção → teste.
