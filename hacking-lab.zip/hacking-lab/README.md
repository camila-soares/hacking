# hacking-lab

Lab isolado de segurança ofensiva para **Mac M1 (Apple Silicon / ARM64)**, cobrindo as ferramentas da Imersão Start Hacking (aulas 2 a 5): SEToolkit/Metasploit, Wifite, EvilTrust, Shodan, WiGLE, além de web app (IDOR/SQLi/BAC) e engenharia social.

> **Regra única do lab:** todo ataque roda contra máquinas **suas** ou com **autorização escrita**. É o mesmo padrão (rules of engagement) que você vai precisar pra prestar serviço a empresas — o lab já te treina nele.

---

## 1. Pré-requisitos de hardware

- [ ] Mac M1 com ~30 GB livres e 8 GB+ de RAM
- [ ] Adaptador **Wi-Fi USB com modo monitor + AP** (chipset **RTL8812AU** ou **AR9271** — ex.: Alfa AWUS036ACH / AWUS036NHA). Só necessário para o módulo Wi-Fi.

## 2. Host — hypervisor e rede isolada

- **VMware Fusion** (grátis, recomendado) ou **UTM** (grátis, QEMU).
- [ ] Instalar o hypervisor e importar a imagem **Kali ARM64 (Apple Silicon)**
- [ ] Rede **host-only / interna**; NAT só durante o setup
- [ ] Passthrough do adaptador USB para a VM Kali (só para o módulo Wi-Fi)

## 3. Dentro da Kali

```bash
git clone <seu-repo>/hacking-lab.git
cd hacking-lab/setup
chmod +x bootstrap.sh
sudo ./bootstrap.sh          # instala toolkit + diagnósticos
./bootstrap.sh --check       # depois de trocar para host-only, confirma isolamento
```

- [ ] `bootstrap.sh` rodou sem erro
- [ ] Adaptador Wi-Fi detectado com modo monitor (se for fazer o módulo Wi-Fi)
- [ ] `--check` confirma **sem internet** em modo isolado
- [ ] **Snapshot** da VM limpa tirado

## 4. Alvos do lab

- [ ] Web: DVWA, Juice Shop, WebGoat via Docker — subir na rede isolada
- [ ] Windows (Meterpreter): VM Windows 11 ARM *ou* notebook x86 velho dedicado
- [ ] Cliente Wi-Fi / "vítima": um **celular velho seu**
- [ ] AP de teste: o **seu** roteador / um SSID de teste seu

---

## 5. Plano de estudo

### Semana 1 — Infraestrutura
- [ ] Hypervisor + Kali ARM + rede isolada + snapshots
- [ ] Validar roteamento subindo DVWA na rede isolada

### Semana 2 — Payload / Meterpreter (Aula 2, na SUA VM Windows)
- [ ] Gerar payload de teste (`msfvenom`) + `multi/handler`
- [ ] `sysinfo`, `shell`, navegação na VM Windows
- [ ] **Defesa:** detecção por Defender/EDR, por que troca de extensão engana usuário

### Semana 3 — Wi-Fi (Aula 3, adaptador USB + seu roteador)
- [ ] `airmon-ng` → modo monitor
- [ ] Wifite capturando handshake do **seu** roteador
- [ ] EvilTrust: evil twin contra o **seu** SSID, seu celular conectando
- [ ] **Defesa:** WPA3, 802.11w/PMF, detecção de rogue AP

### Semana 4 — OSINT (Aula 3, só nos seus ativos)
- [ ] Shodan / WiGLE / I Know What You Download apontados para os **seus** ativos
- [ ] Mini-relatório de exposição

### Semana 5 — Web AppSec (Aula 4) — seu ponto forte
- [ ] **IDOR:** login com 2 contas de teste -> achar refs (IDs em URL/API) -> trocar ID entre contas -> validar impacto
- [ ] **SQL Injection:** identificar campos sem validação -> confirmar em ambiente de teste
- [ ] **Broken Access Control:** forçar `/admin`, testar POST/PUT/DELETE sem permissão, checar controle só-no-frontend
- [ ] Para **cada** falha, aplicar o controle correspondente em `defesa-web-checklist.md` no SGC + escrever o teste de regressão (JUnit)
- [ ] **AI pentesters (Openclaw/Shannon):** instalar no lab e apontar **só para app sua** — confirmar comandos atuais antes de rodar
- [ ] Bug bounty: só programas **em escopo** (HackerOne/Bugcrowd)

### Semana 6 — Engenharia social (Aula 5)
- [ ] Zphisher em **modo Localhost / rede local**, contra o **seu** segundo dispositivo — entender o ataque + sair com o discurso de conscientização
- [ ] **Defesa:** treinamento anti-phishing, 2FA, verificação de domínio, alertas
- [ ] **Fora do lab:** túnel público (LocalXpose) apontando para página de login falsa — isso é phishing real contra terceiros
- [ ] **Versão profissional (para clientes):** simulação de phishing **autorizada** — escopo assinado, lista de funcionários que consentiram, ferramenta dedicada (ex.: GoPhish). É serviço, não link público pra estranho.

---

## 6. Estrutura

```
hacking-lab/
├── README.md
├── defesa-web-checklist.md   # IDOR/SQLi/BAC -> controles Spring Boot + testes
├── .gitignore
└── setup/
    └── bootstrap.sh
```

Tudo que é sensível (loot, handshakes, payloads, logs) está no `.gitignore` e **nunca** vai pro Git.
