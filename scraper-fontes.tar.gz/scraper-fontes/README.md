# Scraper de Fontes Públicas Brasileiras v2

Scraper que lê o `index.json` (1.040 URLs de fontes públicas brasileiras), acessa cada URL, extrai o conteúdo e salva um JSON individual por link.

## Funcionalidades

- **Scraping inteligente**: requests como padrão, Playwright (headless browser) como fallback automático para SPAs com JavaScript
- **Extração de usuários**: detecta nomes com cargo, emails, telefones, CPFs e CNPJs nas páginas
- **Paralelismo**: até 20 workers simultâneos
- **Resumo**: modo `--resume` para continuar de onde parou
- **Filtros**: por categoria, limite de links, modo de scraping

## Instalação

```bash
# 1. Clonar/baixar os arquivos
# Certifique-se de ter o scraper_fontes.py e o index.json na mesma pasta

# 2. Instalar dependências Python
pip install -r requirements.txt

# 3. Instalar o navegador Chromium (necessário para modo auto/playwright)
playwright install chromium
```

## Uso

```bash
# Rodar tudo (1.040 links)
python scraper_fontes.py

# Limitar a N links
python scraper_fontes.py --limite 10

# Filtrar por categoria
python scraper_fontes.py --categoria "Diários Oficiais"
python scraper_fontes.py --categoria "Busca CPF/CNPJ"

# Escolher modo de scraping
python scraper_fontes.py --modo requests     # só HTTP (mais rápido)
python scraper_fontes.py --modo playwright   # sempre usa navegador headless
python scraper_fontes.py --modo auto         # requests + fallback Playwright (recomendado)

# Ajustar paralelismo e timeout
python scraper_fontes.py --workers 20 --timeout 15

# Retomar execução anterior (pula links já salvos)
python scraper_fontes.py --resume

# Combinar opções
python scraper_fontes.py --categoria "Transparência" --limite 20 --modo auto --workers 5
```

## Argumentos

| Argumento      | Padrão      | Descrição                                      |
|----------------|-------------|-------------------------------------------------|
| `--input`      | index.json  | Caminho do arquivo de índice                    |
| `--output`     | output/     | Pasta de saída                                  |
| `--limite`     | (todos)     | Número máximo de links a processar              |
| `--categoria`  | (todas)     | Filtrar por nome de categoria                   |
| `--workers`    | 10          | Número de workers paralelos                     |
| `--timeout`    | 10          | Timeout por requisição (segundos)               |
| `--resume`     | desativado  | Pular links já processados                      |
| `--modo`       | requests    | Modo: `requests`, `playwright` ou `auto`        |

## Estrutura de Saída

```
output/
├── busca-cpf-cnpj/
│   ├── receita-federal-cpf_a1b2c3d4.json
│   └── receita-federal-cnpj_e5f6g7h8.json
├── diarios-oficiais/
│   ├── diario-oficial-uniao_i9j0k1l2.json
│   └── querido-diario_m3n4o5p6.json
├── transparencia/
│   └── portal-transparencia_q7r8s9t0.json
└── _relatorio.json          ← relatório geral da execução
```

### Formato do JSON de cada link

```json
{
  "fonte_id": "busca-cpf-cnpj/receita-federal-cpf",
  "fonte": "Receita Federal - CPF",
  "categoria": "Busca CPF/CNPJ",
  "categoria_id": "busca-cpf-cnpj",
  "descricao_original": "Consulta de situação cadastral de CPF",
  "tipo_fonte": "federal",
  "uf": null,
  "input_esperado": ["cpf"],
  "output_esperado": ["situacao_cadastral"],
  "url": "https://...",
  "scraping": {
    "timestamp": "2026-09-05T22:00:00+00:00",
    "metodo": "requests",
    "status_code": 200,
    "content_type": "text/html; charset=utf-8",
    "encoding": "utf-8",
    "titulo": "Consulta CPF",
    "meta_tags": {
      "description": "..."
    },
    "texto": "conteúdo em texto plano...",
    "links": [
      {"url": "https://...", "texto": "Link visível"}
    ],
    "formularios": [
      {
        "action": "/consultar",
        "method": "POST",
        "campos": [
          {"name": "cpf", "type": "text", "required": true}
        ]
      }
    ],
    "tabelas": [
      [["col1", "col2"], ["val1", "val2"]]
    ],
    "usuarios": {
      "emails": ["contato@orgao.gov.br"],
      "telefones": ["(11) 3456-7890", "0800 726 0101"],
      "cpfs": ["123.456.789-01"],
      "cnpjs": ["00.360.305/0001-04"],
      "pessoas": [
        {
          "nome": "Carlos Eduardo Silva",
          "cargo": "Diretor Geral",
          "contexto": "...trecho do texto onde foi encontrado..."
        }
      ]
    },
    "tamanho_html_bytes": 45230,
    "tempo_resposta_ms": 1250
  }
}
```

## Como funciona o modo `auto`

1. Tenta acessar a URL com `requests` (HTTP simples)
2. Se o texto extraído tiver menos de 150 caracteres, assume que é uma SPA renderizada por JavaScript
3. Automaticamente re-tenta com Playwright (navegador headless Chromium)
4. Aguarda `networkidle` + 2 segundos extras para JavaScript renderizar

## Extração de Usuários

O scraper detecta automaticamente nas páginas:

- **Emails**: padrão `usuario@dominio.com` (filtra emails de frameworks/spam)
- **Telefones**: formatos `(XX) XXXXX-XXXX`, `0800 XXX XXXX`
- **CPFs**: formato `XXX.XXX.XXX-XX` (incluindo mascarados com `***`)
- **CNPJs**: formato `XX.XXX.XXX/XXXX-XX`
- **Pessoas com cargo**: padrões como `Diretor Geral: Nome Sobrenome`, `Responsável: Nome`, `Elaborado por: Nome`
  - Reconhece 40+ cargos do setor público brasileiro
  - Filtra falsos positivos (menus de navegação, nomes de instituições)

## Extração OSINT Avançada (v2)

Além dos dados básicos (emails, telefones, CPFs, CNPJs, pessoas com cargo), o scraper extrai automaticamente:

- **RGs**: documentos de identidade (`12.345.678-9`)
- **Registros profissionais**: OAB, CRM, CREA (`OAB/SP 123456`)
- **SIAPE**: matrículas de servidores federais (7 dígitos)
- **Processos judiciais**: numeração CNJ (`0001234-56.2026.8.26.0100`)
- **Endereços**: Rua, Avenida, Alameda, Travessa, etc.
- **CEPs**: formato `00000-000`
- **Coordenadas geográficas**: latitude/longitude
- **IPs**: endereços IPv4
- **Domínios**: `.gov.br`, `.org.br`, `.com.br`, etc.
- **Redes sociais**: Instagram, Twitter/X, Facebook, LinkedIn, YouTube, GitHub, Lattes/CNPq
- **Placas de veículos**: formato Mercosul (`ABC1D23`) e antigo (`ABC-1234`)

---

## Módulo de Análise OSINT (`osint_analise.py`)

Processa os JSONs gerados pelo scraper, cruza dados entre fontes e gera relatórios consolidados.

### Funcionalidades

- **Cruzamento de pessoas**: identifica a mesma pessoa em fontes diferentes (similaridade Jaccard ≥ 0.7)
- **Associação de dados**: quando só há 1 pessoa na página, vincula emails/CPFs/telefones a ela
- **Score de exposição**: pontua o nível de exposição de dados pessoais (CPF=5pts, SIAPE=4pts, registro profissional=3pts, email/telefone=2pts)
- **Busca**: pesquisa por nome, CPF, email, telefone ou CNPJ
- **Heatmap**: dados expostos por categoria de fonte
- **Exportação**: relatórios em JSON e/ou Markdown

### Uso

```bash
# Analisar toda a pasta output/ (padrão)
python osint_analise.py

# Pasta personalizada
python osint_analise.py --input output/

# Buscar por nome, CPF, email ou CNPJ
python osint_analise.py --buscar "João Silva"
python osint_analise.py --buscar "123.456.789-01"
python osint_analise.py --buscar "email@orgao.gov.br"

# Filtrar emails por domínio
python osint_analise.py --email cgu.gov.br

# Escolher formato de saída
python osint_analise.py --formato json      # só JSON
python osint_analise.py --formato md        # só Markdown
python osint_analise.py --formato todos     # ambos (padrão)

# Top N pessoas mais expostas
python osint_analise.py --top 20

# Combinar opções
python osint_analise.py --input output/ --formato md --top 50 --output meu_relatorio/
```

### Argumentos do osint_analise.py

| Argumento   | Padrão  | Descrição                                |
|-------------|---------|------------------------------------------|
| `--input`   | output/ | Pasta com os JSONs do scraper            |
| `--output`  | osint/  | Pasta de saída dos relatórios            |
| `--buscar`  | —       | Busca por nome, CPF, email, tel ou CNPJ  |
| `--email`   | —       | Filtra emails por domínio                |
| `--formato` | todos   | Formato: `json`, `md` ou `todos`         |
| `--top`     | 10      | Número de entidades no ranking           |

### Exemplo de relatório

```
════════════════════════════════════════════════════════════
  RELATÓRIO OSINT — FONTES PÚBLICAS BRASILEIRAS
════════════════════════════════════════════════════════════
  Fontes analisadas:  1040
  Pessoas:            342
  Emails:             890
  CPFs:               15
  Cruzamentos:        23 dados em múltiplas fontes
────────────────────────────────────────────────────────────
  Top 10 mais expostos:
    1. Carlos Eduardo Silva (Diretor Geral) — score 18
    2. Maria Santos Oliveira (Secretária) — score 12
    ...
════════════════════════════════════════════════════════════
```

---

## Categorias disponíveis no index.json

São 40 categorias com 1.040 links, incluindo: Busca CPF/CNPJ, Câmeras Online, Consulta de Processos, Diários Oficiais, Transparência, Benefícios Sociais, Dados Geoespaciais, entre outras.

Para listar todas:
```bash
python -c "import json; cats = set(e['categoria'] for e in json.load(open('index.json'))); print('\n'.join(sorted(cats)))"
```

---

## Executando com Docker

A forma mais simples — não precisa instalar Python nem dependências no sistema.

### Build e execução rápida

```bash
# Construir a imagem
docker build -t scraper-fontes .

# Rodar com 10 links (padrão)
docker run --rm -v $(pwd)/output:/app/output scraper-fontes

# Rodar com argumentos personalizados
docker run --rm -v $(pwd)/output:/app/output scraper-fontes \
  --modo auto --limite 50 --categoria "Diários Oficiais"

# Rodar tudo (1.040 links)
docker run --rm -v $(pwd)/output:/app/output scraper-fontes \
  --modo auto --limite 0

# Usar seu próprio index.json
docker run --rm \
  -v $(pwd)/output:/app/output \
  -v $(pwd)/meu-index.json:/app/index.json \
  scraper-fontes --modo auto
```

### Com Docker Compose

```bash
# Construir e rodar
docker compose up --build

# Rodar com argumentos diferentes
docker compose run --rm scraper --limite 50 --modo auto --categoria "Transparência"

# Rodar em background
docker compose up -d --build
docker compose logs -f scraper
```

Os resultados ficam na pasta `./output/` da sua máquina.

### Dicas Docker

- A imagem tem ~1.5GB por causa do Chromium — o build inicial demora, depois é instantâneo
- Use `--rm` para não acumular containers parados
- O volume `-v $(pwd)/output:/app/output` garante que os JSONs ficam no seu disco
- Para `--resume` funcionar entre execuções, mantenha o mesmo volume de output

---

## Executando no Kali Linux

Kali é baseado em Debian, então funciona bem. Só precisa instalar algumas dependências do sistema que o Playwright/Chromium exige.

### Instalação passo a passo

```bash
# 1. Atualizar o sistema
sudo apt update && sudo apt upgrade -y

# 2. Instalar Python e pip (se não tiver)
sudo apt install -y python3 python3-pip python3-venv

# 3. Criar um ambiente virtual (recomendado no Kali)
python3 -m venv venv
source venv/bin/activate

# 4. Instalar dependências Python
pip install -r requirements.txt

# 5. Instalar dependências do sistema para o Chromium
#    (O Playwright tem um comando que faz isso automaticamente)
sudo playwright install-deps chromium

# 6. Instalar o Chromium
playwright install chromium

# 7. Testar
python3 scraper_fontes.py --limite 5 --modo auto
```

### Se `playwright install-deps` não funcionar

Instale manualmente as libs que o Chromium precisa:

```bash
sudo apt install -y \
  libnss3 \
  libatk1.0-0 \
  libatk-bridge2.0-0 \
  libcups2 \
  libdrm2 \
  libdbus-1-3 \
  libxkbcommon0 \
  libxcomposite1 \
  libxdamage1 \
  libxrandr2 \
  libgbm1 \
  libpango-1.0-0 \
  libcairo2 \
  libasound2 \
  libxshmfence1 \
  fonts-liberation
```

### Rodar como root no Kali

Se estiver rodando como root (padrão no Kali), o Chromium precisa do flag `--no-sandbox`. O scraper já inclui esse flag automaticamente, então funciona sem alterações.

### Usando com proxychains/tor (opcional)

Para rotear o tráfego pelo Tor no Kali:

```bash
# Instalar tor e proxychains
sudo apt install -y tor proxychains4

# Iniciar o tor
sudo systemctl start tor

# Rodar o scraper via proxychains (modo requests apenas)
proxychains4 python3 scraper_fontes.py --modo requests --limite 10
```

> **Nota:** Proxychains funciona bem com `--modo requests`. Para Playwright, configure o proxy diretamente no navegador (requer alteração no código).

### Docker no Kali

Kali também suporta Docker nativamente:

```bash
# Instalar Docker no Kali
sudo apt install -y docker.io docker-compose
sudo systemctl enable --now docker

# Usar normalmente
docker build -t scraper-fontes .
docker run --rm -v $(pwd)/output:/app/output scraper-fontes --modo auto --limite 20
```

---

## Requisitos

- Python 3.9+
- Conexão com a internet
- Chromium (instalado automaticamente pelo Playwright)
- Docker (opcional, alternativa à instalação local)
