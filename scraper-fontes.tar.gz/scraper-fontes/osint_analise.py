#!/usr/bin/env python3
"""
OSINT Analyzer — Fontes Públicas Brasileiras
=============================================

Processa os JSONs gerados pelo scraper_fontes.py, cruza dados entre
fontes e gera relatórios OSINT consolidados.

Funcionalidades:
  • Cruzamento de pessoas entre fontes (mesmo nome em sites diferentes)
  • Grafo de relações: email↔pessoa, CPF↔pessoa, telefone↔pessoa
  • Consolidação de dados por entidade (pessoa, órgão, domínio)
  • Estatísticas e heatmap de dados expostos por categoria
  • Exporta relatório em JSON e Markdown

Uso:
  python osint_analise.py                              # analisa tudo em output/
  python osint_analise.py --input output/              # pasta específica
  python osint_analise.py --buscar "João Silva"        # busca por nome
  python osint_analise.py --buscar "123.456.789-01"    # busca por CPF
  python osint_analise.py --email dominio.gov.br       # filtra por domínio de email
  python osint_analise.py --formato md                 # relatório em Markdown
  python osint_analise.py --formato json               # relatório em JSON
  python osint_analise.py --formato todos              # ambos (padrão)
  python osint_analise.py --top 20                     # top N entidades expostas
"""

import argparse
import json
import logging
import os
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


# ── Estruturas de dados ──────────────────────────────────────

@dataclass
class Pessoa:
    """Entidade pessoa encontrada em uma ou mais fontes."""
    nome: str
    cargos: list = field(default_factory=list)
    fontes: list = field(default_factory=list)
    emails: list = field(default_factory=list)
    telefones: list = field(default_factory=list)
    cpfs: list = field(default_factory=list)
    registros_prof: list = field(default_factory=list)
    siape: list = field(default_factory=list)
    redes_sociais: list = field(default_factory=list)
    contextos: list = field(default_factory=list)

    def score_exposicao(self) -> int:
        """Quanto mais dados expostos, maior o score."""
        return (
            len(self.emails) * 2 +
            len(self.telefones) * 2 +
            len(self.cpfs) * 5 +
            len(self.registros_prof) * 3 +
            len(self.siape) * 4 +
            len(self.redes_sociais) +
            len(self.fontes) +
            len(self.cargos)
        )


@dataclass
class DominioInfo:
    """Informações agregadas sobre um domínio."""
    dominio: str
    emails: list = field(default_factory=list)
    paginas: list = field(default_factory=list)
    ips: list = field(default_factory=list)
    subdominos: list = field(default_factory=list)
    tecnologias: list = field(default_factory=list)


# ── Funções auxiliares ────────────────────────────────────────

def _normalizar_nome(nome: str) -> str:
    """Normaliza nome para comparação (lowercase, sem acentos excessivos)."""
    nome = nome.strip().lower()
    # Remove preposições para matching
    nome = re.sub(r"\b(de|da|do|dos|das|e)\b", " ", nome)
    return " ".join(nome.split())


def _similaridade_nome(nome1: str, nome2: str) -> float:
    """Calcula similaridade entre dois nomes (0-1)."""
    n1 = set(_normalizar_nome(nome1).split())
    n2 = set(_normalizar_nome(nome2).split())
    if not n1 or not n2:
        return 0.0
    intersecao = n1 & n2
    uniao = n1 | n2
    return len(intersecao) / len(uniao)


def _extrair_dominio_email(email: str) -> str:
    """Extrai o domínio de um email."""
    return email.split("@")[-1].lower() if "@" in email else ""


def _carregar_jsons(pasta: str) -> list:
    """Carrega todos os JSONs de resultado do scraper."""
    resultados = []
    pasta = Path(pasta)

    if not pasta.exists():
        logger.error("Pasta não encontrada: %s", pasta)
        return resultados

    for json_file in sorted(pasta.rglob("*.json")):
        if json_file.name.startswith("_"):  # pula _relatorio.json
            continue
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if "scraping" in data:
                data["_arquivo"] = str(json_file)
                resultados.append(data)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.warning("Erro lendo %s: %s", json_file, e)

    logger.info("Carregados %d JSONs de %s", len(resultados), pasta)
    return resultados


# ── Motor de análise ─────────────────────────────────────────

class OSINTAnalyzer:
    """Analisador OSINT que cruza dados entre fontes."""

    def __init__(self):
        self.resultados = []
        self.pessoas = {}           # nome_normalizado → Pessoa
        self.emails_index = defaultdict(set)      # email → {nomes}
        self.telefones_index = defaultdict(set)    # tel → {nomes}
        self.cpfs_index = defaultdict(set)         # cpf → {nomes}
        self.dominios = {}          # dominio → DominioInfo
        self.stats = defaultdict(int)

        # Índices para busca rápida
        self._email_fontes = defaultdict(list)     # email → [fonte_ids]
        self._tel_fontes = defaultdict(list)
        self._cpf_fontes = defaultdict(list)
        self._cnpj_fontes = defaultdict(list)

    def carregar(self, pasta: str):
        """Carrega e indexa todos os resultados."""
        self.resultados = _carregar_jsons(pasta)
        self._indexar()

    def _indexar(self):
        """Indexa todos os dados para cruzamento."""
        for r in self.resultados:
            scraping = r.get("scraping", {})
            usuarios = scraping.get("usuarios", {})
            fonte_id = r.get("fonte_id", "desconhecido")
            fonte_nome = r.get("fonte", fonte_id)
            url = r.get("url", "")
            categoria = r.get("categoria", "")

            # Stats gerais
            self.stats["total_fontes"] += 1
            if scraping.get("status_code") == 200:
                self.stats["fontes_ok"] += 1

            # ── Indexar pessoas ──
            for p in usuarios.get("pessoas", []):
                nome = p.get("nome", "").strip()
                if not nome:
                    continue
                nome_norm = _normalizar_nome(nome)

                # Busca pessoa existente com nome similar
                pessoa_key = self._encontrar_pessoa(nome_norm)
                if pessoa_key is None:
                    pessoa_key = nome_norm
                    self.pessoas[pessoa_key] = Pessoa(nome=nome)

                pessoa = self.pessoas[pessoa_key]
                cargo = p.get("cargo", "")
                if cargo and cargo not in pessoa.cargos:
                    pessoa.cargos.append(cargo)
                fonte_ref = {"fonte": fonte_nome, "url": url, "categoria": categoria}
                if fonte_ref not in pessoa.fontes:
                    pessoa.fontes.append(fonte_ref)
                ctx = p.get("contexto", "")
                if ctx and ctx not in pessoa.contextos:
                    pessoa.contextos.append(ctx)

                self.stats["total_pessoas"] += 1

            # ── Indexar emails ──
            for email in usuarios.get("emails", []):
                self._email_fontes[email.lower()].append(fonte_id)
                dominio = _extrair_dominio_email(email)
                if dominio:
                    if dominio not in self.dominios:
                        self.dominios[dominio] = DominioInfo(dominio=dominio)
                    if email not in self.dominios[dominio].emails:
                        self.dominios[dominio].emails.append(email)
                self.stats["total_emails"] += 1

            # ── Indexar telefones ──
            for tel in usuarios.get("telefones", []):
                tel_clean = re.sub(r"[\s.\-()]", "", tel)
                self._tel_fontes[tel_clean].append(fonte_id)
                self.stats["total_telefones"] += 1

            # ── Indexar CPFs ──
            for cpf in usuarios.get("cpfs", []):
                cpf_clean = re.sub(r"[\s.\-]", "", cpf)
                self._cpf_fontes[cpf_clean].append(fonte_id)
                self.stats["total_cpfs"] += 1

            # ── Indexar CNPJs ──
            for cnpj in usuarios.get("cnpjs", []):
                cnpj_clean = re.sub(r"[\s.\-/\\]", "", cnpj)
                self._cnpj_fontes[cnpj_clean].append(fonte_id)
                self.stats["total_cnpjs"] += 1

            # ── OSINT extras ──
            for rg in usuarios.get("rgs", []):
                self.stats["total_rgs"] += 1
            for reg in usuarios.get("registros_profissionais", []):
                self.stats["total_reg_prof"] += 1
            for siape in usuarios.get("siape", []):
                self.stats["total_siape"] += 1
            for proc in usuarios.get("processos", []):
                self.stats["total_processos"] += 1
            for end in usuarios.get("enderecos", []):
                self.stats["total_enderecos"] += 1
            for cep in usuarios.get("ceps", []):
                self.stats["total_ceps"] += 1
            for coord in usuarios.get("coordenadas", []):
                self.stats["total_coordenadas"] += 1
            for ip in usuarios.get("ips", []):
                self.stats["total_ips"] += 1
            for dom in usuarios.get("dominios", []):
                self.stats["total_dominios"] += 1
                if dom not in self.dominios:
                    self.dominios[dom] = DominioInfo(dominio=dom)
                if url not in self.dominios[dom].paginas:
                    self.dominios[dom].paginas.append(url)
            for social in usuarios.get("redes_sociais", []):
                self.stats["total_redes_sociais"] += 1
            for placa in usuarios.get("placas", []):
                self.stats["total_placas"] += 1

            # Associar emails/tel/cpf a pessoas na mesma página
            self._associar_dados_pessoa(usuarios, fonte_nome)

    def _encontrar_pessoa(self, nome_norm: str) -> Optional[str]:
        """Busca pessoa existente com nome similar (>= 0.7 Jaccard)."""
        for key in self.pessoas:
            if _similaridade_nome(nome_norm, key) >= 0.7:
                return key
        return None

    def _associar_dados_pessoa(self, usuarios: dict, fonte: str):
        """Se só tem 1 pessoa na página, associa os dados a ela."""
        pessoas = usuarios.get("pessoas", [])
        if len(pessoas) != 1:
            return

        nome_norm = _normalizar_nome(pessoas[0].get("nome", ""))
        pessoa_key = self._encontrar_pessoa(nome_norm)
        if pessoa_key is None:
            return

        pessoa = self.pessoas[pessoa_key]

        for email in usuarios.get("emails", []):
            if email not in pessoa.emails:
                pessoa.emails.append(email)
        for tel in usuarios.get("telefones", []):
            if tel not in pessoa.telefones:
                pessoa.telefones.append(tel)
        for cpf in usuarios.get("cpfs", []):
            if cpf not in pessoa.cpfs:
                pessoa.cpfs.append(cpf)
        for reg in usuarios.get("registros_profissionais", []):
            if reg not in pessoa.registros_prof:
                pessoa.registros_prof.append(reg)
        for siape in usuarios.get("siape", []):
            if siape not in pessoa.siape:
                pessoa.siape.append(siape)
        for social in usuarios.get("redes_sociais", []):
            if social not in pessoa.redes_sociais:
                pessoa.redes_sociais.append(social)

    def buscar(self, termo: str) -> dict:
        """Busca OSINT por termo (nome, CPF, email, telefone, CNPJ)."""
        resultado = {
            "termo": termo,
            "pessoas": [],
            "emails": [],
            "telefones": [],
            "cpfs": [],
            "cnpjs": [],
            "fontes": [],
        }

        termo_lower = termo.lower().strip()
        termo_clean = re.sub(r"[\s.\-/\\()]", "", termo)

        # Busca em pessoas
        for key, pessoa in self.pessoas.items():
            if (termo_lower in key or
                    _similaridade_nome(termo_lower, key) >= 0.5 or
                    any(termo_lower in c.lower() for c in pessoa.cargos)):
                resultado["pessoas"].append({
                    "nome": pessoa.nome,
                    "cargos": pessoa.cargos,
                    "emails": pessoa.emails,
                    "telefones": pessoa.telefones,
                    "cpfs": pessoa.cpfs,
                    "registros_profissionais": pessoa.registros_prof,
                    "siape": pessoa.siape,
                    "redes_sociais": pessoa.redes_sociais,
                    "fontes": pessoa.fontes,
                    "score_exposicao": pessoa.score_exposicao(),
                })

        # Busca em emails
        for email, fontes in self._email_fontes.items():
            if termo_lower in email:
                resultado["emails"].append({"email": email, "fontes": fontes})

        # Busca em telefones
        for tel, fontes in self._tel_fontes.items():
            if termo_clean in tel or tel in termo_clean:
                resultado["telefones"].append({"telefone": tel, "fontes": fontes})

        # Busca em CPFs
        for cpf, fontes in self._cpf_fontes.items():
            if termo_clean in cpf or cpf in termo_clean:
                resultado["cpfs"].append({"cpf": cpf, "fontes": fontes})

        # Busca em CNPJs
        for cnpj, fontes in self._cnpj_fontes.items():
            if termo_clean in cnpj or cnpj in termo_clean:
                resultado["cnpjs"].append({"cnpj": cnpj, "fontes": fontes})

        # Busca em fontes
        for r in self.resultados:
            fonte = r.get("fonte", "")
            url = r.get("url", "")
            texto = r.get("scraping", {}).get("texto", "")
            if (termo_lower in fonte.lower() or
                    termo_lower in url.lower() or
                    termo_lower in texto.lower()):
                resultado["fontes"].append({
                    "fonte": fonte,
                    "url": url,
                    "categoria": r.get("categoria", ""),
                })

        return resultado

    def filtrar_por_dominio_email(self, dominio: str) -> list:
        """Retorna todos os emails de um domínio específico."""
        dominio = dominio.lower().strip()
        resultados = []
        for email, fontes in self._email_fontes.items():
            if email.endswith(f"@{dominio}") or email.endswith(f".{dominio}"):
                resultados.append({"email": email, "fontes": fontes})
        return sorted(resultados, key=lambda x: x["email"])

    def top_expostos(self, n: int = 10) -> list:
        """Top N pessoas com mais dados expostos."""
        ranking = []
        for pessoa in self.pessoas.values():
            ranking.append({
                "nome": pessoa.nome,
                "score": pessoa.score_exposicao(),
                "cargos": pessoa.cargos,
                "n_fontes": len(pessoa.fontes),
                "n_emails": len(pessoa.emails),
                "n_telefones": len(pessoa.telefones),
                "n_cpfs": len(pessoa.cpfs),
                "n_registros": len(pessoa.registros_prof),
            })
        return sorted(ranking, key=lambda x: x["score"], reverse=True)[:n]

    def cruzamentos(self) -> dict:
        """Identifica dados que aparecem em múltiplas fontes."""
        cruz = {
            "emails_multi_fonte": [],
            "telefones_multi_fonte": [],
            "cpfs_multi_fonte": [],
            "cnpjs_multi_fonte": [],
            "pessoas_multi_fonte": [],
        }

        for email, fontes in self._email_fontes.items():
            fontes_unicas = list(set(fontes))
            if len(fontes_unicas) > 1:
                cruz["emails_multi_fonte"].append({
                    "email": email,
                    "fontes": fontes_unicas,
                    "n_fontes": len(fontes_unicas),
                })

        for tel, fontes in self._tel_fontes.items():
            fontes_unicas = list(set(fontes))
            if len(fontes_unicas) > 1:
                cruz["telefones_multi_fonte"].append({
                    "telefone": tel,
                    "fontes": fontes_unicas,
                    "n_fontes": len(fontes_unicas),
                })

        for cpf, fontes in self._cpf_fontes.items():
            fontes_unicas = list(set(fontes))
            if len(fontes_unicas) > 1:
                cruz["cpfs_multi_fonte"].append({
                    "cpf": cpf,
                    "fontes": fontes_unicas,
                    "n_fontes": len(fontes_unicas),
                })

        for cnpj, fontes in self._cnpj_fontes.items():
            fontes_unicas = list(set(fontes))
            if len(fontes_unicas) > 1:
                cruz["cnpjs_multi_fonte"].append({
                    "cnpj": cnpj,
                    "fontes": fontes_unicas,
                    "n_fontes": len(fontes_unicas),
                })

        for key, pessoa in self.pessoas.items():
            if len(pessoa.fontes) > 1:
                cruz["pessoas_multi_fonte"].append({
                    "nome": pessoa.nome,
                    "cargos": pessoa.cargos,
                    "n_fontes": len(pessoa.fontes),
                    "fontes": [f["fonte"] for f in pessoa.fontes],
                })

        # Ordena por quantidade de fontes
        for k in cruz:
            cruz[k] = sorted(cruz[k], key=lambda x: x.get("n_fontes", 0), reverse=True)

        return cruz

    def heatmap_categorias(self) -> list:
        """Mapa de calor: quantidade de dados expostos por categoria."""
        cats = defaultdict(lambda: defaultdict(int))

        for r in self.resultados:
            cat = r.get("categoria", "Sem categoria")
            usuarios = r.get("scraping", {}).get("usuarios", {})

            for campo in ["emails", "telefones", "cpfs", "cnpjs", "rgs",
                          "registros_profissionais", "siape", "processos",
                          "enderecos", "ceps", "coordenadas", "dominios",
                          "ips", "redes_sociais", "placas", "pessoas"]:
                cats[cat][campo] += len(usuarios.get(campo, []))

            cats[cat]["_paginas"] += 1

        result = []
        for cat, dados in sorted(cats.items()):
            total = sum(v for k, v in dados.items() if not k.startswith("_"))
            result.append({
                "categoria": cat,
                "paginas": dados["_paginas"],
                "total_dados": total,
                **{k: v for k, v in dados.items() if not k.startswith("_")},
            })

        return sorted(result, key=lambda x: x["total_dados"], reverse=True)

    def gerar_relatorio(self, top_n: int = 10) -> dict:
        """Gera relatório OSINT completo."""
        return {
            "meta": {
                "gerado_em": datetime.utcnow().isoformat() + "Z",
                "versao": "2.0-osint",
                "total_fontes_analisadas": len(self.resultados),
            },
            "resumo": dict(self.stats),
            "top_expostos": self.top_expostos(top_n),
            "cruzamentos": self.cruzamentos(),
            "heatmap_categorias": self.heatmap_categorias(),
            "dominios": {
                dom: {
                    "emails": info.emails,
                    "paginas": info.paginas[:10],
                }
                for dom, info in sorted(self.dominios.items())
                if info.emails  # só domínios com emails
            },
        }


# ── Exportadores ─────────────────────────────────────────────

def exportar_json(relatorio: dict, caminho: str):
    """Salva relatório como JSON."""
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(relatorio, f, ensure_ascii=False, indent=2)
    logger.info("Relatório JSON salvo: %s", caminho)


def exportar_markdown(relatorio: dict, caminho: str):
    """Gera relatório em Markdown."""
    lines = []
    meta = relatorio["meta"]
    resumo = relatorio["resumo"]

    lines.append("# Relatório OSINT — Fontes Públicas Brasileiras")
    lines.append(f"\nGerado em: {meta['gerado_em']}")
    lines.append(f"Fontes analisadas: {meta['total_fontes_analisadas']}")
    lines.append("")

    # ── Resumo
    lines.append("## Resumo de Dados Encontrados")
    lines.append("")
    lines.append("| Tipo | Quantidade |")
    lines.append("|------|-----------|")

    campos_label = [
        ("total_fontes", "Fontes acessadas"),
        ("fontes_ok", "Fontes com sucesso"),
        ("total_pessoas", "Pessoas identificadas"),
        ("total_emails", "Emails"),
        ("total_telefones", "Telefones"),
        ("total_cpfs", "CPFs"),
        ("total_cnpjs", "CNPJs"),
        ("total_rgs", "RGs"),
        ("total_reg_prof", "Registros profissionais (OAB/CRM/CREA)"),
        ("total_siape", "Matrículas SIAPE"),
        ("total_processos", "Processos judiciais"),
        ("total_enderecos", "Endereços"),
        ("total_ceps", "CEPs"),
        ("total_coordenadas", "Coordenadas"),
        ("total_dominios", "Domínios"),
        ("total_ips", "IPs"),
        ("total_redes_sociais", "Perfis de redes sociais"),
        ("total_placas", "Placas de veículo"),
    ]

    for campo, label in campos_label:
        val = resumo.get(campo, 0)
        if val > 0:
            lines.append(f"| {label} | {val} |")

    lines.append("")

    # ── Top expostos
    top = relatorio.get("top_expostos", [])
    if top:
        lines.append("## Top Pessoas com Maior Exposição")
        lines.append("")
        lines.append("| # | Nome | Cargo | Score | Fontes | Emails | Tel | CPFs |")
        lines.append("|---|------|-------|-------|--------|--------|-----|------|")
        for i, p in enumerate(top, 1):
            cargo = p["cargos"][0] if p["cargos"] else "—"
            lines.append(
                f"| {i} | {p['nome']} | {cargo} | {p['score']} | "
                f"{p['n_fontes']} | {p['n_emails']} | {p['n_telefones']} | {p['n_cpfs']} |"
            )
        lines.append("")

    # ── Cruzamentos
    cruz = relatorio.get("cruzamentos", {})

    pessoas_multi = cruz.get("pessoas_multi_fonte", [])
    if pessoas_multi:
        lines.append("## Pessoas em Múltiplas Fontes")
        lines.append("")
        for p in pessoas_multi[:20]:
            cargos = ", ".join(p["cargos"]) if p["cargos"] else "sem cargo"
            fontes = ", ".join(p["fontes"])
            lines.append(f"- **{p['nome']}** ({cargos}) — {p['n_fontes']} fontes: {fontes}")
        lines.append("")

    emails_multi = cruz.get("emails_multi_fonte", [])
    if emails_multi:
        lines.append("## Emails em Múltiplas Fontes")
        lines.append("")
        for e in emails_multi[:20]:
            fontes = ", ".join(e["fontes"])
            lines.append(f"- `{e['email']}` — {e['n_fontes']} fontes: {fontes}")
        lines.append("")

    # ── Heatmap
    heatmap = relatorio.get("heatmap_categorias", [])
    if heatmap:
        lines.append("## Exposição por Categoria")
        lines.append("")
        lines.append("| Categoria | Páginas | Total | Pessoas | Emails | Tel | CPFs | CNPJs |")
        lines.append("|-----------|---------|-------|---------|--------|-----|------|-------|")
        for h in heatmap[:30]:
            lines.append(
                f"| {h['categoria']} | {h['paginas']} | {h['total_dados']} | "
                f"{h.get('pessoas', 0)} | {h.get('emails', 0)} | "
                f"{h.get('telefones', 0)} | {h.get('cpfs', 0)} | {h.get('cnpjs', 0)} |"
            )
        lines.append("")

    # ── Domínios com emails
    dominios = relatorio.get("dominios", {})
    if dominios:
        lines.append("## Domínios com Emails Expostos")
        lines.append("")
        for dom, info in list(dominios.items())[:30]:
            n_emails = len(info["emails"])
            lines.append(f"- **{dom}** — {n_emails} email(s)")
            for email in info["emails"][:5]:
                lines.append(f"  - `{email}`")
            if n_emails > 5:
                lines.append(f"  - ... e mais {n_emails - 5}")
        lines.append("")

    lines.append("---")
    lines.append(f"*Gerado automaticamente por osint_analise.py v{meta['versao']}*")

    with open(caminho, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    logger.info("Relatório Markdown salvo: %s", caminho)


# ── CLI ──────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="OSINT Analyzer — Cruza dados das fontes públicas brasileiras"
    )
    parser.add_argument("--input", default="output",
                        help="Pasta com os JSONs do scraper (default: output/)")
    parser.add_argument("--output", default="osint",
                        help="Pasta de saída dos relatórios (default: osint/)")
    parser.add_argument("--buscar", metavar="TERMO",
                        help="Buscar por nome, CPF, email, telefone ou CNPJ")
    parser.add_argument("--email", metavar="DOMINIO",
                        help="Listar emails de um domínio específico (ex: gov.br)")
    parser.add_argument("--formato", choices=["json", "md", "todos"],
                        default="todos",
                        help="Formato do relatório (default: todos)")
    parser.add_argument("--top", type=int, default=10,
                        help="Top N entidades mais expostas (default: 10)")
    args = parser.parse_args()

    # Carregar dados
    analyzer = OSINTAnalyzer()
    analyzer.carregar(args.input)

    if not analyzer.resultados:
        logger.error("Nenhum resultado encontrado em %s", args.input)
        logger.error("Execute primeiro: python scraper_fontes.py --modo auto")
        sys.exit(1)

    # Criar pasta de saída
    os.makedirs(args.output, exist_ok=True)

    # ── Modo busca
    if args.buscar:
        resultado = analyzer.buscar(args.buscar)
        print(json.dumps(resultado, ensure_ascii=False, indent=2))

        busca_path = os.path.join(args.output, "busca_resultado.json")
        with open(busca_path, "w", encoding="utf-8") as f:
            json.dump(resultado, f, ensure_ascii=False, indent=2)
        logger.info("Resultado da busca salvo: %s", busca_path)
        return

    # ── Modo filtro por domínio
    if args.email:
        resultados = analyzer.filtrar_por_dominio_email(args.email)
        print(f"\n{'='*60}")
        print(f"  Emails encontrados para: {args.email}")
        print(f"  Total: {len(resultados)}")
        print(f"{'='*60}\n")
        for r in resultados:
            fontes_str = ", ".join(r["fontes"][:3])
            if len(r["fontes"]) > 3:
                fontes_str += f" +{len(r['fontes'])-3}"
            print(f"  {r['email']}")
            print(f"    Fontes: {fontes_str}")
            print()
        return

    # ── Relatório completo
    logger.info("Gerando relatório OSINT...")
    relatorio = analyzer.gerar_relatorio(top_n=args.top)

    # Exibe resumo no terminal
    print(f"\n{'═'*60}")
    print(f"  RELATÓRIO OSINT — FONTES PÚBLICAS BRASILEIRAS")
    print(f"{'═'*60}")
    print(f"  Fontes analisadas:  {relatorio['resumo'].get('total_fontes', 0)}")
    print(f"  Fontes OK:          {relatorio['resumo'].get('fontes_ok', 0)}")
    print(f"{'─'*60}")
    print(f"  Pessoas:            {relatorio['resumo'].get('total_pessoas', 0)}")
    print(f"  Emails:             {relatorio['resumo'].get('total_emails', 0)}")
    print(f"  Telefones:          {relatorio['resumo'].get('total_telefones', 0)}")
    print(f"  CPFs:               {relatorio['resumo'].get('total_cpfs', 0)}")
    print(f"  CNPJs:              {relatorio['resumo'].get('total_cnpjs', 0)}")
    print(f"  Reg. profissionais: {relatorio['resumo'].get('total_reg_prof', 0)}")
    print(f"  SIAPE:              {relatorio['resumo'].get('total_siape', 0)}")
    print(f"  Processos:          {relatorio['resumo'].get('total_processos', 0)}")
    print(f"  Endereços:          {relatorio['resumo'].get('total_enderecos', 0)}")
    print(f"  Redes sociais:      {relatorio['resumo'].get('total_redes_sociais', 0)}")
    print(f"  IPs:                {relatorio['resumo'].get('total_ips', 0)}")
    print(f"  Domínios:           {relatorio['resumo'].get('total_dominios', 0)}")

    cruz = relatorio.get("cruzamentos", {})
    n_multi = sum(len(v) for v in cruz.values())
    print(f"{'─'*60}")
    print(f"  Cruzamentos:        {n_multi} dados em múltiplas fontes")

    top = relatorio.get("top_expostos", [])
    if top:
        print(f"{'─'*60}")
        print(f"  Top {len(top)} mais expostos:")
        for i, p in enumerate(top[:5], 1):
            cargo = p["cargos"][0] if p["cargos"] else ""
            cargo_str = f" ({cargo})" if cargo else ""
            print(f"    {i}. {p['nome']}{cargo_str} — score {p['score']}")
    print(f"{'═'*60}\n")

    # Salva relatórios
    if args.formato in ("json", "todos"):
        exportar_json(relatorio, os.path.join(args.output, "relatorio_osint.json"))

    if args.formato in ("md", "todos"):
        exportar_markdown(relatorio, os.path.join(args.output, "relatorio_osint.md"))

    logger.info("Concluído! Relatórios em: %s/", args.output)


if __name__ == "__main__":
    main()
