#!/usr/bin/env python3
"""
Scraper de Fontes Públicas Brasileiras v2
==========================================

Lê o arquivo index.json (índice achatado de links), acessa cada URL,
extrai o conteúdo da página e salva um JSON individual por link
na pasta output/<categoria_id>/<fonte_id>.json

v2 — Novidades:
  • Playwright (navegador headless) como fallback para SPAs/JavaScript
  • Extração de usuários/pessoas: nomes, emails, telefones, CPFs parciais,
    cargos, responsáveis encontrados nas páginas

Uso:
  python scraper_fontes.py                           # roda tudo
  python scraper_fontes.py --limite 10               # só os 10 primeiros
  python scraper_fontes.py --categoria "Consulta de Processos"
  python scraper_fontes.py --workers 20              # mais paralelismo
  python scraper_fontes.py --timeout 15              # timeout por request
  python scraper_fontes.py --resume                  # retoma de onde parou
  python scraper_fontes.py --modo playwright         # força Playwright em tudo
  python scraper_fontes.py --modo auto               # requests + fallback PW

Dependências:
  pip install requests beautifulsoup4 lxml playwright
  playwright install chromium
"""

import argparse
import asyncio
import hashlib
import json
import logging
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

# ── Configuração ────────────────────────────────────────────

DEFAULT_INDEX = "index.json"
DEFAULT_OUTPUT_DIR = "output"
DEFAULT_WORKERS = 10
DEFAULT_TIMEOUT = 12  # segundos
DEFAULT_DELAY = 0.3   # delay entre requests ao mesmo domínio

# Mínimo de texto para considerar que requests capturou conteúdo real
MIN_TEXTO_CHARS = 150

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0.0.0 Safari/537.36"
)

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.5",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
}

# ── Logging ─────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("scraper.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("scraper")


# ── Regex para extração de usuários/pessoas ─────────────────

# CPF: 000.000.000-00 ou parcialmente mascarado ***.000.000-**
_CPF_RE = re.compile(
    r"(?<!\d)"
    r"(?:\d{3}|\*{3})[.\s]?"
    r"(?:\d{3})[.\s]?"
    r"(?:\d{3})[.\s-]?"
    r"(?:\d{2}|\*{2})"
    r"(?!\d)"
)

# CNPJ: 00.000.000/0000-00
_CNPJ_RE = re.compile(
    r"\d{2}[.\s]?\d{3}[.\s]?\d{3}[/\\]\d{4}[.\s-]?\d{2}"
)

# Email
_EMAIL_RE = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
)

# Telefone BR: (00) 0000-0000 ou (00) 00000-0000 ou 0800 ...
_TELEFONE_RE = re.compile(
    r"(?:"
    r"\(?\d{2}\)?\s*\d{4,5}[\s.\-]?\d{4}"   # (XX) XXXXX-XXXX
    r"|0[38]00[\s.\-]?\d{3}[\s.\-]?\d{4}"    # 0800/0300
    r")"
)

# ── Regex OSINT adicionais ────────────────────────────────────

# RG (varia por estado, padrão genérico)
_RG_RE = re.compile(
    r"(?:RG|R\.G\.?|Identidade|Doc\.?\s*Identidade)[\s:nº°]+(\d{1,3}[.\s]?\d{3}[.\s]?\d{3}[\s.\-]?[\dxX]?)",
    re.IGNORECASE,
)

# OAB: OAB/SP 123456 ou OAB-RJ 78901
_OAB_RE = re.compile(
    r"OAB[\s/\-]*([A-Z]{2})[\s/\-]*(\d{3,6})",
    re.IGNORECASE,
)

# CRM: CRM/SP 123456
_CRM_RE = re.compile(
    r"CRM[\s/\-]*([A-Z]{2})[\s/\-]*(\d{3,6})",
    re.IGNORECASE,
)

# CREA: CREA/SP 123456-D
_CREA_RE = re.compile(
    r"CREA[\s/\-]*([A-Z]{2})[\s/\-]*(\d{4,7}[\s\-]?[A-Z]?)",
    re.IGNORECASE,
)

# Matrícula SIAPE (servidores federais): 7 dígitos
_SIAPE_RE = re.compile(
    r"(?:SIAPE|Matr[íi]cula)[\s:nº°]+(\d{7})",
    re.IGNORECASE,
)

# Processo judicial: 0000000-00.0000.0.00.0000 (CNJ)
_PROCESSO_RE = re.compile(
    r"\d{7}[\-.]?\d{2}[.\s]?\d{4}[.\s]?\d[.\s]?\d{2}[.\s]?\d{4}"
)

# CEP: 00000-000
_CEP_RE = re.compile(r"\b\d{5}[\-.]?\d{3}\b")

# Endereço (heurística: Rua/Av/Alameda + texto + número)
_ENDERECO_RE = re.compile(
    r"(?:Rua|Av\.?|Avenida|Alameda|Travessa|Praça|Rodovia|Estrada|BR[\s\-]?\d{3})"
    r"[^,\n]{5,80}(?:,\s*(?:n[ºo°]?\s*)?\d{1,6})?",
    re.IGNORECASE,
)

# Coordenadas geográficas: -23.5505, -46.6333 ou -23° 33' 01"
_COORD_RE = re.compile(
    r"[\-]?\d{1,3}[.,]\d{4,8}[\s,;]+[\-]?\d{1,3}[.,]\d{4,8}"
)

# IPs (v4)
_IP_RE = re.compile(
    r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
)

# Domínios (.gov.br, .org.br, .com.br etc)
_DOMINIO_RE = re.compile(
    r"\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:gov|jus|leg|mp|def|mil|org|com|edu|net)\.[a-z]{2,3}\b"
)

# Redes sociais (URLs ou @handles)
_SOCIAL_PATTERNS = {
    "instagram": re.compile(r"(?:instagram\.com|instagr\.am)/([A-Za-z0-9_.]{1,30})", re.IGNORECASE),
    "twitter": re.compile(r"(?:twitter\.com|x\.com)/([A-Za-z0-9_]{1,15})", re.IGNORECASE),
    "facebook": re.compile(r"facebook\.com/([A-Za-z0-9_.]{1,50})", re.IGNORECASE),
    "linkedin": re.compile(r"linkedin\.com/in/([A-Za-z0-9\-]{1,100})", re.IGNORECASE),
    "youtube": re.compile(r"youtube\.com/(?:@|channel/|user/)([A-Za-z0-9_\-]{1,100})", re.IGNORECASE),
    "github": re.compile(r"github\.com/([A-Za-z0-9\-]{1,39})", re.IGNORECASE),
    "lattes": re.compile(r"lattes\.cnpq\.br/(\d{16})", re.IGNORECASE),
}

# Placa de veículo (Mercosul e antigo)
_PLACA_RE = re.compile(
    r"\b[A-Z]{3}[\-\s]?\d[A-Z0-9]\d{2}\b"
)

# Nome composto (Heurística: 2+ palavras capitalizadas, sem números)
# Pega padrões como "Dr. João Silva", "Maria da Costa Pereira"
_PREPOSICOES = {"de", "da", "do", "dos", "das", "e", "di", "del", "van", "von"}
_TITULOS = {"dr", "dra", "sr", "sra", "prof", "profa", "eng", "adv", "des", "min"}

# Padrões de cargo/função em contexto brasileiro
_CARGO_PATTERNS = [
    r"(?:diretor|diretora|gerente|coordenador|coordenadora|"
    r"superintendente|presidente|vice[\s-]?presidente|"
    r"secretário|secretária|ministro|ministra|"
    r"procurador|procuradora|promotor|promotora|"
    r"juiz|juíza|desembargador|desembargadora|"
    r"delegado|delegada|defensor|defensora|"
    r"assessor|assessora|analista|técnico|técnica|"
    r"ouvidor|ouvidora|auditor|auditora|"
    r"prefeito|prefeita|governador|governadora|"
    r"vereador|vereadora|deputado|deputada|senador|senadora|"
    r"chefe|responsável|servidor|servidora|"
    r"contador|contadora|tesoureiro|tesoureira|"
    r"oficial|escrivão|escrivã|tabelião|"
    r"pregoeiro|pregoeira|comissário|comissária|"
    r"reitor|reitora|professor|professora)"
    r"(?:[ \t]+(?:de|da|do|geral|adjunto|adjunta|substituto|substituta|executivo|executiva)"
    r"(?:[ \t]+[A-ZÀ-Úa-zà-ú]+)?)?"
]
_CARGO_RE = re.compile(
    r"(?:^|\b)(" + "|".join(_CARGO_PATTERNS) + r")\b",
    re.IGNORECASE,
)

# Padrões que associam cargo a nome
# Usa [ \t] em vez de \s para não cruzar linhas, evitando capturas multi-linha
_CARGO_NOME_RE = re.compile(
    r"(?:" + "|".join(_CARGO_PATTERNS) + r")"
    r"[\ \t:–\-]+([A-ZÀ-ÚÇ][a-zà-úç]+(?:[\ \t]+(?:(?:d[aeoiu]s?|e)[\ \t]+)?[A-ZÀ-ÚÇ][a-zà-úç]+){1,5})",
    re.IGNORECASE | re.UNICODE,
)

# Responsável/contato: "Responsável: Nome Sobrenome"
# Nota: removidos "atendimento" e "ouvidoria" pois geram falsos positivos
# em menus de navegação de sites governamentais
_RESPONSAVEL_RE = re.compile(
    r"(?:responsável|ouvidor|"
    r"titular|gestor|gestora|encarregado|encarregada|"
    r"elaborado por|aprovado por|assinado por|autorizado por)"
    r"[\ \t:–\-]+([A-ZÀ-ÚÇ][a-zà-úç]+(?:[\ \t]+(?:(?:d[aeoiu]s?|e)[\ \t]+)?[A-ZÀ-ÚÇ][a-zà-úç]+){1,5})",
    re.IGNORECASE | re.UNICODE,
)


def _limpar_nome(nome: str) -> str:
    """Remove artefatos de um nome extraído."""
    nome = nome.strip(" .,;:-–—/\\|()[]{}\"'")
    # Remove título se grudado
    for t in _TITULOS:
        if nome.lower().startswith(t + "."):
            nome = nome[len(t) + 1:].strip()
            break
    return nome.strip()


def _eh_nome_valido(nome: str) -> bool:
    """Verifica se parece um nome de pessoa (não um lugar/instituição genérico)."""
    if not nome or len(nome) < 5:
        return False
    # Rejeitar nomes com quebras de linha (artefatos de navegação)
    if "\n" in nome:
        return False
    # Rejeitar nomes muito longos (provavelmente texto genérico)
    if len(nome) > 80:
        return False
    palavras = nome.split()
    if len(palavras) < 2:
        return False
    # Deve ter pelo menos 2 palavras capitalizadas (excluindo preposições)
    caps = [p for p in palavras if p[0].isupper() and p.lower() not in _PREPOSICOES]
    if len(caps) < 2:
        return False
    # Rejeitar se parece instituição (palavras típicas)
    inst_words = {"tribunal", "ministério", "secretaria", "governo",
                  "prefeitura", "câmara", "senado", "assembleia", "instituto",
                  "fundação", "universidade", "federal", "estadual", "municipal",
                  "nacional", "brasil", "estado", "república", "justiça",
                  "defensoria", "procuradoria", "corregedoria",
                  "aplicativos", "canais", "telefones", "digital", "digitais",
                  "todos", "programa", "programas", "produtos", "serviços"}
    if any(p.lower() in inst_words for p in palavras):
        return False
    return True


def extrair_usuarios(texto: str, soup: BeautifulSoup = None) -> dict:
    """
    Extrai informações de usuários/pessoas encontradas na página.

    Retorna:
      {
        "emails": [...],
        "telefones": [...],
        "cpfs": [...],
        "cnpjs": [...],
        "pessoas": [
          {"nome": "...", "cargo": "...", "contexto": "..."},
        ]
      }
    """
    resultado = {
        "emails": [],
        "telefones": [],
        "cpfs": [],
        "cnpjs": [],
        "pessoas": [],
        "rgs": [],
        "registros_profissionais": [],   # OAB, CRM, CREA
        "siape": [],
        "processos": [],
        "enderecos": [],
        "ceps": [],
        "coordenadas": [],
        "dominios": [],
        "ips": [],
        "redes_sociais": [],
        "placas": [],
    }

    if not texto:
        return resultado

    # ── Emails ──
    emails_raw = _EMAIL_RE.findall(texto)
    # Deduplica e filtra emails genéricos de framework
    emails_ignore = {"example.com", "email.com", "teste.com", "sentry.io",
                     "w3.org", "schema.org", "jquery.com", "googleapis.com",
                     "noreply", "no-reply", "mailer-daemon"}
    for e in emails_raw:
        e_lower = e.lower()
        if any(ig in e_lower for ig in emails_ignore):
            continue
        if e_lower not in [x.lower() for x in resultado["emails"]]:
            resultado["emails"].append(e)

    # ── Telefones ──
    telefones_raw = _TELEFONE_RE.findall(texto)
    seen_tel = set()
    for t in telefones_raw:
        t_clean = re.sub(r"[\s.\-()]", "", t)
        if len(t_clean) >= 10 and t_clean not in seen_tel:
            seen_tel.add(t_clean)
            resultado["telefones"].append(t.strip())

    # ── CPFs ──
    cpfs_raw = _CPF_RE.findall(texto)
    seen_cpf = set()
    for c in cpfs_raw:
        c_clean = re.sub(r"[\s.\-]", "", c)
        if len(c_clean) == 11 and c_clean not in seen_cpf:
            seen_cpf.add(c_clean)
            resultado["cpfs"].append(c.strip())

    # ── CNPJs ──
    cnpjs_raw = _CNPJ_RE.findall(texto)
    seen_cnpj = set()
    for c in cnpjs_raw:
        c_clean = re.sub(r"[\s.\-/\\]", "", c)
        if len(c_clean) == 14 and c_clean not in seen_cnpj:
            seen_cnpj.add(c_clean)
            resultado["cnpjs"].append(c.strip())

    # ── Pessoas (cargo + nome) ──
    pessoas_vistas = set()

    # Padrão 1: "Cargo: Nome Sobrenome"
    for m in _CARGO_NOME_RE.finditer(texto):
        nome = _limpar_nome(m.group(1))
        if _eh_nome_valido(nome) and nome.lower() not in pessoas_vistas:
            cargo = m.group(0).split(nome)[0].strip(" :–\-\n")
            pessoas_vistas.add(nome.lower())
            # Pega contexto (30 chars antes e depois)
            start = max(0, m.start() - 30)
            end = min(len(texto), m.end() + 30)
            contexto = texto[start:end].replace("\n", " ").strip()
            resultado["pessoas"].append({
                "nome": nome,
                "cargo": cargo.strip(),
                "contexto": contexto,
            })

    # Padrão 2: "Responsável: Nome"
    for m in _RESPONSAVEL_RE.finditer(texto):
        nome = _limpar_nome(m.group(1))
        if _eh_nome_valido(nome) and nome.lower() not in pessoas_vistas:
            pessoas_vistas.add(nome.lower())
            label = m.group(0).split(nome)[0].strip(" :–\-\n")
            start = max(0, m.start() - 30)
            end = min(len(texto), m.end() + 30)
            contexto = texto[start:end].replace("\n", " ").strip()
            resultado["pessoas"].append({
                "nome": nome,
                "cargo": label.strip(),
                "contexto": contexto,
            })

    # Padrão 3: Buscar em elementos HTML específicos (se soup disponível)
    if soup:
        # Tabelas de equipe, contato, responsáveis
        for td in soup.find_all(["td", "dd", "span", "p", "li"]):
            cell_text = td.get_text(strip=True)
            if not cell_text or len(cell_text) > 100:
                continue
            # Checa se o texto anterior (header/label) indica pessoa
            prev = td.find_previous(["th", "dt", "label", "strong", "b"])
            if prev:
                prev_text = prev.get_text(strip=True).lower()
                is_person_field = any(kw in prev_text for kw in [
                    "nome", "responsável", "responsavel", "contato",
                    "servidor", "titular", "gestor", "elaborado",
                    "aprovado", "assinado", "encarregado", "ouvidor",
                    "pregoeiro", "autoridade",
                ])
                if is_person_field:
                    nome = _limpar_nome(cell_text)
                    if _eh_nome_valido(nome) and nome.lower() not in pessoas_vistas:
                        pessoas_vistas.add(nome.lower())
                        resultado["pessoas"].append({
                            "nome": nome,
                            "cargo": prev_text.strip(": "),
                            "contexto": f"{prev_text}: {cell_text}",
                        })

    # ── OSINT: RGs ──
    for m in _RG_RE.finditer(texto):
        rg = m.group(1).strip()
        if rg not in resultado["rgs"]:
            resultado["rgs"].append(rg)

    # ── OSINT: Registros profissionais (OAB, CRM, CREA) ──
    for label, regex in [("OAB", _OAB_RE), ("CRM", _CRM_RE), ("CREA", _CREA_RE)]:
        for m in regex.finditer(texto):
            uf = m.group(1).upper()
            num = m.group(2).strip()
            entry = f"{label}/{uf} {num}"
            if entry not in resultado["registros_profissionais"]:
                resultado["registros_profissionais"].append(entry)

    # ── OSINT: SIAPE ──
    for m in _SIAPE_RE.finditer(texto):
        siape = m.group(1)
        if siape not in resultado["siape"]:
            resultado["siape"].append(siape)

    # ── OSINT: Processos judiciais ──
    for m in _PROCESSO_RE.finditer(texto):
        proc = m.group(0).strip()
        if proc not in resultado["processos"]:
            resultado["processos"].append(proc)

    # ── OSINT: Endereços ──
    for m in _ENDERECO_RE.finditer(texto):
        end = m.group(0).strip()
        if len(end) > 15 and end not in resultado["enderecos"]:
            resultado["enderecos"].append(end)

    # ── OSINT: CEPs ──
    seen_cep = set()
    for m in _CEP_RE.finditer(texto):
        cep = m.group(0)
        cep_clean = cep.replace("-", "").replace(".", "")
        # Filtra CEPs inválidos (todos iguais, começa com 0 seguido de zeros)
        if len(cep_clean) == 8 and cep_clean not in seen_cep and len(set(cep_clean)) > 1:
            seen_cep.add(cep_clean)
            resultado["ceps"].append(cep)

    # ── OSINT: Coordenadas geográficas ──
    for m in _COORD_RE.finditer(texto):
        coord = m.group(0).strip()
        if coord not in resultado["coordenadas"]:
            resultado["coordenadas"].append(coord)

    # ── OSINT: Domínios ──
    dominios_ignore = {"w3.org", "schema.org", "jquery.com", "googleapis.com",
                       "cloudflare.com", "gstatic.com", "google.com",
                       "facebook.com", "twitter.com", "instagram.com",
                       "youtube.com", "linkedin.com", "github.com"}
    for m in _DOMINIO_RE.finditer(texto):
        dom = m.group(0).lower()
        if dom not in dominios_ignore and dom not in resultado["dominios"]:
            resultado["dominios"].append(dom)

    # ── OSINT: IPs ──
    ips_ignore = {"0.0.0.0", "127.0.0.1", "255.255.255.255", "192.168.0.1",
                  "192.168.1.1", "10.0.0.1"}
    for m in _IP_RE.finditer(texto):
        ip = m.group(0)
        if ip not in ips_ignore and ip not in resultado["ips"]:
            resultado["ips"].append(ip)

    # ── OSINT: Redes sociais ──
    full_text = texto
    if soup:
        # Pega URLs de links também (mais confiável que texto)
        for a in soup.find_all("a", href=True):
            full_text += " " + a["href"]
    seen_social = set()
    for plataforma, regex in _SOCIAL_PATTERNS.items():
        for m in regex.finditer(full_text):
            handle = m.group(1).strip("/").lower()
            # Filtra handles genéricos
            if handle in {"share", "sharer", "intent", "dialog", "watch",
                          "channel", "user", "pages", "groups", "events",
                          "hashtag", "search", "explore", "login", "signup"}:
                continue
            key = f"{plataforma}:{handle}"
            if key not in seen_social:
                seen_social.add(key)
                resultado["redes_sociais"].append({
                    "plataforma": plataforma,
                    "handle": handle if plataforma == "lattes" else m.group(1),
                    "url": m.group(0) if "://" in m.group(0) else None,
                })

    # ── OSINT: Placas de veículo ──
    for m in _PLACA_RE.finditer(texto):
        placa = m.group(0).upper().replace(" ", "")
        if placa not in resultado["placas"]:
            resultado["placas"].append(placa)

    # Limita resultados
    for key in resultado:
        if isinstance(resultado[key], list):
            resultado[key] = resultado[key][:50]

    return resultado


# ── Funções auxiliares ──────────────────────────────────────

def slugify(text: str) -> str:
    """Converte texto em slug seguro para nome de arquivo."""
    text = text.lower().strip()
    text = re.sub(r"[àáâãä]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôõö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[ç]", "c", text)
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = text.strip("-")
    if len(text) > 120:
        text = text[:120].rsplit("-", 1)[0]
    return text or "sem-nome"


def extrair_texto_limpo(soup: BeautifulSoup) -> str:
    """Extrai texto visível da página, removendo scripts e estilos."""
    for tag in soup.find_all(["script", "style", "noscript", "iframe",
                              "svg", "path", "meta", "link"]):
        tag.decompose()

    texto = soup.get_text(separator="\n", strip=True)
    linhas = [l.strip() for l in texto.splitlines() if l.strip()]
    texto_limpo = "\n".join(linhas)

    if len(texto_limpo) > 50_000:
        texto_limpo = texto_limpo[:50_000] + "\n[... truncado em 50.000 caracteres]"

    return texto_limpo


def extrair_links_pagina(soup: BeautifulSoup, base_url: str) -> list[dict]:
    """Extrai links da página com texto âncora."""
    links = []
    seen = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith(("#", "javascript:", "mailto:", "tel:")):
            continue
        if href.startswith("/"):
            parsed = urlparse(base_url)
            href = f"{parsed.scheme}://{parsed.netloc}{href}"
        elif not href.startswith("http"):
            continue
        if href in seen:
            continue
        seen.add(href)
        texto = a.get_text(strip=True)[:200]
        links.append({"url": href, "texto": texto})
    return links[:100]


def extrair_formularios(soup: BeautifulSoup) -> list[dict]:
    """Extrai informações de formulários da página."""
    forms = []
    for form in soup.find_all("form"):
        campos = []
        for inp in form.find_all(["input", "select", "textarea"]):
            campo = {
                "tipo": inp.get("type", inp.name),
                "nome": inp.get("name", ""),
                "id": inp.get("id", ""),
                "placeholder": inp.get("placeholder", ""),
                "obrigatorio": inp.has_attr("required"),
            }
            if inp.name == "select":
                opcoes = [opt.get_text(strip=True) for opt in inp.find_all("option")]
                campo["opcoes"] = opcoes[:20]
            campos.append(campo)
        forms.append({
            "action": form.get("action", ""),
            "method": form.get("method", "GET").upper(),
            "campos": campos,
        })
    return forms


def extrair_tabelas(soup: BeautifulSoup) -> list[dict]:
    """Extrai tabelas da página como lista de dicts."""
    tabelas = []
    for table in soup.find_all("table"):
        headers = [th.get_text(strip=True) for th in table.find_all("th")]
        linhas = []
        for tr in table.find_all("tr"):
            cols = [td.get_text(strip=True) for td in tr.find_all("td")]
            if cols:
                if headers and len(cols) == len(headers):
                    linhas.append(dict(zip(headers, cols)))
                else:
                    linhas.append(cols)
        if linhas:
            tabelas.append({
                "headers": headers,
                "linhas": linhas[:50],
                "total_linhas": len(linhas),
            })
    return tabelas[:10]


def extrair_meta_tags(soup: BeautifulSoup) -> dict:
    """Extrai meta tags relevantes."""
    meta = {}
    for tag in soup.find_all("meta"):
        name = tag.get("name", tag.get("property", "")).lower()
        content = tag.get("content", "")
        if name and content and name in (
            "description", "keywords", "author", "robots",
            "og:title", "og:description", "og:image", "og:type",
            "twitter:title", "twitter:description",
        ):
            meta[name] = content[:500]
    return meta


# ── Processar HTML (comum a requests e Playwright) ──────────

def processar_html(html: str, url: str, scraping: dict):
    """Parseia HTML e preenche o dict scraping com os dados extraídos."""
    soup = BeautifulSoup(html, "lxml")

    # Título
    tag_title = soup.find("title")
    scraping["titulo"] = tag_title.get_text(strip=True) if tag_title else None

    # Meta tags
    scraping["meta_tags"] = extrair_meta_tags(soup)

    # Texto (opera numa cópia para não destruir o soup original)
    soup_texto = BeautifulSoup(html, "lxml")
    scraping["texto"] = extrair_texto_limpo(soup_texto)

    # Links
    scraping["links"] = extrair_links_pagina(soup, url)

    # Formulários
    scraping["formularios"] = extrair_formularios(soup)

    # Tabelas
    scraping["tabelas"] = extrair_tabelas(soup)

    # Usuários/Pessoas
    scraping["usuarios"] = extrair_usuarios(scraping["texto"], soup)

    return soup


# ── Playwright (navegador headless) ─────────────────────────

_PW_BROWSER = None
_PW_PLAYWRIGHT = None


async def _get_browser():
    """Retorna instância singleton do browser Playwright."""
    global _PW_BROWSER, _PW_PLAYWRIGHT
    if _PW_BROWSER is None:
        from playwright.async_api import async_playwright
        _PW_PLAYWRIGHT = await async_playwright().start()
        _PW_BROWSER = await _PW_PLAYWRIGHT.chromium.launch(
            executable_path="/opt/pw-browsers/chromium-1194/chrome-linux/chrome",
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        logger.info("Playwright browser iniciado")
    return _PW_BROWSER


async def _close_browser():
    """Fecha o browser Playwright."""
    global _PW_BROWSER, _PW_PLAYWRIGHT
    if _PW_BROWSER:
        await _PW_BROWSER.close()
        _PW_BROWSER = None
    if _PW_PLAYWRIGHT:
        await _PW_PLAYWRIGHT.stop()
        _PW_PLAYWRIGHT = None


async def scrape_url_playwright(url: str, timeout: int) -> tuple[str, int]:
    """
    Acessa a URL com Playwright, aguarda o JS renderizar,
    e retorna (html, status_code).
    """
    browser = await _get_browser()
    context = await browser.new_context(
        user_agent=USER_AGENT,
        locale="pt-BR",
        viewport={"width": 1280, "height": 800},
    )
    page = await context.new_page()

    try:
        resp = await page.goto(url, wait_until="networkidle", timeout=timeout * 1000)
        status = resp.status if resp else 0

        # Espera extra para SPAs que carregam após networkidle
        await page.wait_for_timeout(2000)

        # Tenta esperar por conteúdo dinâmico
        try:
            await page.wait_for_selector("body *:not(script):not(style)", timeout=3000)
        except Exception:
            pass

        html = await page.content()
        return html, status

    finally:
        await context.close()


def scrape_com_playwright(url: str, timeout: int) -> tuple[str, int]:
    """Wrapper síncrono para o Playwright."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(scrape_url_playwright(url, timeout))
    finally:
        loop.close()


# ── Scraper principal ───────────────────────────────────────

def scrape_url(entry: dict, timeout: int = DEFAULT_TIMEOUT,
               modo: str = "auto") -> dict:
    """
    Faz o scraping de uma URL e retorna um dict completo.

    modo:
      "requests"   — só requests (rápido, sem JS)
      "playwright"  — só Playwright (lento, renderiza JS)
      "auto"        — requests primeiro; se pouco conteúdo, tenta Playwright
    """
    url = entry["url"]
    resultado = {
        "fonte_id": entry.get("fonte_id", ""),
        "fonte": entry.get("fonte", ""),
        "categoria": entry.get("categoria", ""),
        "categoria_id": entry.get("categoria_id", ""),
        "descricao_original": entry.get("descricao", ""),
        "tipo_fonte": entry.get("tipo_fonte", ""),
        "uf": entry.get("uf"),
        "input_esperado": entry.get("input", []),
        "output_esperado": entry.get("output", []),
        "url": url,
        "scraping": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metodo": None,  # "requests" ou "playwright"
            "status_code": None,
            "content_type": None,
            "encoding": None,
            "titulo": None,
            "meta_tags": {},
            "texto": "",
            "links": [],
            "formularios": [],
            "tabelas": [],
            "usuarios": {"emails": [], "telefones": [], "cpfs": [],
                         "cnpjs": [], "pessoas": []},
            "tamanho_html_bytes": 0,
            "tempo_resposta_ms": 0,
            "erro": None,
        },
    }

    scraping = resultado["scraping"]
    usar_playwright = modo == "playwright"
    tentou_requests = False

    # ── Tentativa 1: requests (se não forçou Playwright) ────
    if modo in ("requests", "auto"):
        tentou_requests = True
        try:
            inicio = time.monotonic()
            resp = requests.get(
                url, headers=HEADERS, timeout=timeout,
                allow_redirects=True, verify=True,
            )
            scraping["tempo_resposta_ms"] = round((time.monotonic() - inicio) * 1000)
            scraping["status_code"] = resp.status_code
            scraping["content_type"] = resp.headers.get("Content-Type", "")
            scraping["encoding"] = resp.encoding
            scraping["tamanho_html_bytes"] = len(resp.content)
            scraping["metodo"] = "requests"

            ct = scraping["content_type"].lower()
            if not any(t in ct for t in ("html", "xml", "text")):
                scraping["erro"] = f"Conteúdo não-HTML: {ct}"
                logger.info("  [%d] %s — tipo: %s", resp.status_code, url[:60], ct)
                return resultado

            processar_html(resp.text, url, scraping)

            # Se pouco conteúdo e modo auto, marca para fallback PW
            if modo == "auto" and len(scraping["texto"]) < MIN_TEXTO_CHARS:
                logger.info("  [%d] %s — pouco conteúdo (%d chars), tentando Playwright…",
                            resp.status_code, url[:60], len(scraping["texto"]))
                usar_playwright = True
            else:
                _log_resultado(scraping, url)
                return resultado

        except requests.exceptions.Timeout:
            if modo == "auto":
                logger.info("  [TIMEOUT requests] %s — tentando Playwright…", url[:60])
                usar_playwright = True
            else:
                scraping["erro"] = f"Timeout após {timeout}s"
                scraping["metodo"] = "requests"
                logger.warning("  [TIMEOUT] %s", url[:80])
                return resultado

        except requests.exceptions.SSLError as e:
            if modo == "auto":
                logger.info("  [SSL requests] %s — tentando Playwright…", url[:60])
                usar_playwright = True
            else:
                scraping["erro"] = f"Erro SSL: {str(e)[:200]}"
                scraping["metodo"] = "requests"
                return resultado

        except requests.exceptions.ConnectionError as e:
            scraping["erro"] = f"Erro de conexão: {str(e)[:200]}"
            scraping["metodo"] = "requests"
            logger.warning("  [CONN] %s — %s", url[:60], str(e)[:80])
            return resultado

        except Exception as e:
            scraping["erro"] = f"{type(e).__name__}: {str(e)[:200]}"
            scraping["metodo"] = "requests"
            logger.error("  [ERRO] %s — %s", url[:60], str(e)[:80])
            return resultado

    # ── Tentativa 2 (ou única): Playwright ──────────────────
    if usar_playwright:
        try:
            inicio = time.monotonic()
            html, status = scrape_com_playwright(url, timeout)
            scraping["tempo_resposta_ms"] = round((time.monotonic() - inicio) * 1000)
            scraping["status_code"] = status
            scraping["tamanho_html_bytes"] = len(html.encode("utf-8", errors="replace"))
            scraping["metodo"] = "playwright"
            scraping["erro"] = None  # limpa erro anterior do requests

            processar_html(html, url, scraping)
            _log_resultado(scraping, url, "(PW)")

        except Exception as e:
            if not scraping.get("erro"):
                scraping["erro"] = f"Playwright: {type(e).__name__}: {str(e)[:200]}"
            scraping["metodo"] = "playwright"
            logger.warning("  [PW ERRO] %s — %s", url[:60], str(e)[:80])

    return resultado


def _log_resultado(scraping: dict, url: str, extra: str = ""):
    """Log padronizado de resultado."""
    n_usuarios = sum(
        len(v) for v in scraping.get("usuarios", {}).values()
        if isinstance(v, list)
    )
    logger.info(
        "  [%s] %s %s— %s (%d chars, %d links, %d forms, %d users)",
        scraping["status_code"],
        url[:55],
        extra + " " if extra else "",
        (scraping["titulo"] or "sem título")[:35],
        len(scraping["texto"]),
        len(scraping["links"]),
        len(scraping["formularios"]),
        n_usuarios,
    )


# ── Salvar / Carregar ──────────────────────────────────────

def salvar_resultado(resultado: dict, output_dir: str):
    """Salva o resultado em output/<categoria_id>/<slug>.json"""
    cat_id = resultado.get("categoria_id", "sem-categoria")
    fonte_id = resultado.get("fonte_id", "")

    if "/" in fonte_id:
        nome_arquivo = fonte_id.split("/")[-1]
    else:
        nome_arquivo = slugify(resultado.get("fonte", "sem-nome"))

    url_hash = hashlib.md5(resultado["url"].encode()).hexdigest()[:8]
    nome_arquivo = f"{slugify(nome_arquivo)}_{url_hash}"

    pasta = Path(output_dir) / slugify(cat_id)
    pasta.mkdir(parents=True, exist_ok=True)

    caminho = pasta / f"{nome_arquivo}.json"
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(resultado, f, ensure_ascii=False, indent=2)

    return str(caminho)


def carregar_progresso(output_dir: str) -> set[str]:
    """Retorna URLs já processadas (para --resume)."""
    processadas = set()
    output_path = Path(output_dir)
    if not output_path.exists():
        return processadas

    for json_file in output_path.rglob("*.json"):
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                url = data.get("url", "")
                if url:
                    processadas.add(url)
        except (json.JSONDecodeError, KeyError):
            continue

    return processadas


# ── Main ────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Scraper de fontes públicas brasileiras v2"
    )
    parser.add_argument(
        "--index", default=DEFAULT_INDEX,
        help=f"Caminho do arquivo index.json (padrão: {DEFAULT_INDEX})",
    )
    parser.add_argument(
        "--output", default=DEFAULT_OUTPUT_DIR,
        help=f"Pasta de saída (padrão: {DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "--workers", type=int, default=DEFAULT_WORKERS,
        help=f"Número de threads paralelas (padrão: {DEFAULT_WORKERS})",
    )
    parser.add_argument(
        "--timeout", type=int, default=DEFAULT_TIMEOUT,
        help=f"Timeout por request em segundos (padrão: {DEFAULT_TIMEOUT})",
    )
    parser.add_argument(
        "--limite", type=int, default=0,
        help="Limitar a N links (0 = todos)",
    )
    parser.add_argument(
        "--categoria", type=str, default="",
        help="Filtrar por nome da categoria",
    )
    parser.add_argument(
        "--resume", action="store_true",
        help="Retomar de onde parou (pula URLs já salvas)",
    )
    parser.add_argument(
        "--delay", type=float, default=DEFAULT_DELAY,
        help=f"Delay entre requests em segundos (padrão: {DEFAULT_DELAY})",
    )
    parser.add_argument(
        "--modo", choices=["requests", "playwright", "auto"], default="auto",
        help="Modo de scraping: requests (rápido), playwright (JS), auto (padrão)",
    )

    args = parser.parse_args()

    # Verificar Playwright se necessário
    if args.modo in ("playwright", "auto"):
        try:
            import playwright
            logger.info("Playwright disponível — fallback para SPAs ativado")
        except ImportError:
            if args.modo == "playwright":
                logger.error("Playwright não instalado. Rode: pip install playwright && playwright install chromium")
                sys.exit(1)
            else:
                logger.warning("Playwright não instalado — SPAs não serão renderizadas. "
                               "Para instalar: pip install playwright && playwright install chromium")
                args.modo = "requests"

    # Carregar índice
    logger.info("Carregando índice: %s", args.index)
    with open(args.index, "r", encoding="utf-8") as f:
        data = json.load(f)

    links = data.get("links", [])
    logger.info("Total de links no índice: %d", len(links))

    if args.categoria:
        links = [l for l in links if args.categoria.lower() in l.get("categoria", "").lower()]
        logger.info("Filtrado por '%s': %d links", args.categoria, len(links))

    if args.limite > 0:
        links = links[:args.limite]
        logger.info("Limitado a %d links", len(links))

    if args.resume:
        processadas = carregar_progresso(args.output)
        antes = len(links)
        links = [l for l in links if l["url"] not in processadas]
        logger.info("Resume: %d já processados, %d restantes", antes - len(links), len(links))

    if not links:
        logger.info("Nenhum link para processar.")
        return

    Path(args.output).mkdir(parents=True, exist_ok=True)

    # Ajustar workers para Playwright (mais pesado)
    workers = args.workers
    if args.modo == "playwright":
        workers = min(workers, 4)  # Playwright é pesado
        logger.info("Modo Playwright: limitando a %d workers", workers)

    logger.info(
        "Iniciando scraping v2: %d links, %d workers, timeout=%ds, modo=%s",
        len(links), workers, args.timeout, args.modo,
    )

    stats = {"ok": 0, "erro": 0, "timeout": 0, "total": len(links),
             "pw_fallback": 0, "com_usuarios": 0}
    inicio_total = time.monotonic()

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {}
        for i, entry in enumerate(links):
            future = executor.submit(scrape_url, entry, args.timeout, args.modo)
            futures[future] = (i, entry)

        for future in as_completed(futures):
            i, entry = futures[future]
            try:
                resultado = future.result()
                salvar_resultado(resultado, args.output)

                s = resultado["scraping"]
                erro = s.get("erro")
                if erro:
                    if "Timeout" in erro:
                        stats["timeout"] += 1
                    else:
                        stats["erro"] += 1
                else:
                    stats["ok"] += 1

                if s.get("metodo") == "playwright":
                    stats["pw_fallback"] += 1

                # Contar se encontrou usuários
                usuarios = s.get("usuarios", {})
                total_u = sum(len(v) for v in usuarios.values() if isinstance(v, list))
                if total_u > 0:
                    stats["com_usuarios"] += 1

                progresso = stats["ok"] + stats["erro"] + stats["timeout"]
                if progresso % 50 == 0 or progresso == stats["total"]:
                    elapsed = time.monotonic() - inicio_total
                    logger.info(
                        "══ Progresso: %d/%d (%.0f%%) — OK:%d Erro:%d PW:%d Users:%d — %.0fs",
                        progresso, stats["total"],
                        100 * progresso / stats["total"],
                        stats["ok"], stats["erro"],
                        stats["pw_fallback"], stats["com_usuarios"],
                        elapsed,
                    )

            except Exception as e:
                stats["erro"] += 1
                logger.error("Falha ao processar %s: %s", entry.get("url", "?"), e)

            time.sleep(args.delay)

    # Fechar Playwright se usado
    if args.modo in ("playwright", "auto"):
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(_close_browser())
            loop.close()
        except Exception:
            pass

    # Relatório final
    elapsed_total = time.monotonic() - inicio_total
    logger.info("═" * 55)
    logger.info("SCRAPING v2 CONCLUÍDO")
    logger.info("  Total:         %d", stats["total"])
    logger.info("  OK:            %d", stats["ok"])
    logger.info("  Erros:         %d", stats["erro"])
    logger.info("  Timeouts:      %d", stats["timeout"])
    logger.info("  Playwright:    %d fallbacks", stats["pw_fallback"])
    logger.info("  Com usuários:  %d páginas", stats["com_usuarios"])
    logger.info("  Tempo:         %.1f min", elapsed_total / 60)
    logger.info("  Saída:         %s/", args.output)
    logger.info("═" * 55)

    relatorio = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "versao": "2.0",
        "total_links": stats["total"],
        "sucesso": stats["ok"],
        "erros": stats["erro"],
        "timeouts": stats["timeout"],
        "playwright_fallbacks": stats["pw_fallback"],
        "paginas_com_usuarios": stats["com_usuarios"],
        "tempo_total_segundos": round(elapsed_total, 1),
        "config": {
            "workers": workers,
            "timeout": args.timeout,
            "delay": args.delay,
            "modo": args.modo,
        },
    }
    relatorio_path = Path(args.output) / "_relatorio.json"
    with open(relatorio_path, "w", encoding="utf-8") as f:
        json.dump(relatorio, f, ensure_ascii=False, indent=2)
    logger.info("Relatório salvo em: %s", relatorio_path)


if __name__ == "__main__":
    main()
