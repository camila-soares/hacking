# 03 — Treinamento dos Funcionários

Formato sugerido: workshop de **60–90 min** + um material de 1 página (quick reference) que fica com cada pessoa.

## Parte 1 — O que é engenharia social (10 min)

Atacante não precisa "invadir" — ele convence a pessoa a entregar. Tipos:
- **Phishing:** e-mail/site falso imitando algo legítimo.
- **Vishing:** golpe por telefone/voz.
- **Pretexting:** cria um cenário falso ("sou do TI, preciso da sua senha").
- **Baiting:** isca física (pen drive "achado") ou digital ("brinde grátis").

## Parte 2 — Como reconhecer um phishing (25 min)

Sinais de alerta:
- **Urgência/medo:** "sua conta será bloqueada em 24h".
- **Remetente estranho:** nome bonito, mas o e-mail real não bate com o domínio oficial.
- **Link suspeito:** o texto diz um endereço, mas passar o mouse mostra outro.
- **Anexo inesperado**, principalmente `.exe`, `.zip`, documento pedindo "habilitar macros".
- **Pedido de credencial ou pagamento** por link.
- Erros de português, saudação genérica ("Prezado cliente").

Exercício: mostrar 4–5 e-mails (alguns reais/legítimos, alguns falsos) e a turma vota "phishing ou não".

## Parte 3 — A regra de ouro (15 min)

- Passe o mouse no link **antes** de clicar e confira o domínio.
- **Nunca** digite senha a partir de um link recebido por e-mail. Abra o site digitando o endereço você mesmo.
- Desconfie de urgência. Golpe vive de pressa.
- Confirme por **outro canal** (ligue para a pessoa/setor) antes de pagar ou enviar dado.
- Na dúvida, **não clique**.

## Parte 4 — O que fazer ao suspeitar (10 min)

- Não clique, não responda, não encaminhe para colegas.
- **Reporte** pelo canal definido (e-mail de segurança / botão de reporte / avisar TI).
- Reportar rápido é o comportamento mais valioso — ensine que reportar é elogiável, não motivo de vergonha.

## Parte 5 — Higiene básica (10 min)

- **2FA** em tudo que permitir.
- Senhas únicas por serviço + gerenciador de senhas.
- Atualizar sistema e navegador.
- Cuidado com Wi-Fi público e com pen drives desconhecidos.

## Material de 1 página (entregar impresso/PDF)

Um resumão com: os 6 sinais de alerta, a regra de ouro, e o canal de reporte da empresa. É o que fica na mesa da pessoa.
