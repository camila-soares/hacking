# 02 — Termo de Autorização e Escopo

> Documento a ser **assinado pela direção do cliente antes de qualquer teste**. É o que autoriza a simulação e o que te protege. Adapte e valide com um advogado antes de usar em contrato real.

---

## Termo de Autorização para Simulação de Phishing e Treinamento

**Contratante:** __________________________ (empresa, CNPJ)
**Responsável autorizador:** __________________ (nome, cargo — deve ter poder para autorizar)
**Prestador:** Camila __________________________
**Data:** ____ / ____ / ______

### 1. Objeto
O Contratante autoriza o Prestador a conduzir um programa de conscientização de segurança que inclui **simulação controlada de phishing** e **treinamento** dos seus colaboradores, com finalidade exclusivamente educativa e preventiva.

### 2. Escopo autorizado
- Destinatários: **apenas colaboradores do Contratante**, conforme lista fornecida pela direção.
- Domínios/e-mails de teste: ____________________
- Janela de execução: de ____/____ a ____/____
- Canais: e-mail simulado + página de treinamento.

### 3. O que **será** feito
- Envio de e-mails simulados de phishing aos colaboradores listados.
- Registro de eventos: abertura, clique, envio de formulário, reporte.
- Redirecionamento de quem clicar para página educativa.
- Treinamento e relatório.

### 4. O que **NÃO** será feito
- **Não** haverá captura ou armazenamento de senhas reais.
- **Não** haverá teste em sistemas de produção, invasão de rede ou exploração técnica fora deste escopo.
- **Não** haverá teste em terceiros (clientes, fornecedores) nem em quem não conste na lista autorizada.
- **Não** haverá exposição pública de dados dos colaboradores.

### 5. Confidencialidade e dados
- Resultados são confidenciais e entregues apenas ao responsável autorizador.
- Dados coletados limitam-se a métricas de comportamento (quem clicou/reportou), tratados conforme a LGPD.
- Os dados serão descartados após ____ dias da entrega do relatório.

### 6. Responsabilidades
- O Contratante confirma ter autoridade para autorizar o teste sobre os colaboradores listados.
- O foco é melhoria coletiva; recomenda-se **não punir** colaboradores individualmente pelos resultados.

### 7. Assinaturas
Contratante: ______________________  Prestador: ______________________
