# 05 — Modelo de Relatório Final

Documento entregue à direção. Mantém o formato de laudo: **achado → risco → recomendação**. Preencha os campos entre colchetes.

---

# Relatório — Programa de Conscientização Anti-Phishing

**Cliente:** [empresa]
**Prestador:** Camila [—]
**Período:** [data início] a [data fim]
**Autorização:** Termo assinado em [data] por [nome, cargo]

## 1. Sumário executivo

Em [N] colaboradores testados, a taxa de clique inicial foi de **[X]%** e a de reporte de **[Y]%**. Após o treinamento, o re-teste mostrou clique de **[X2]%** e reporte de **[Y2]%** — uma [melhora/variação] de [—]. As principais recomendações estão na seção 5.

## 2. Escopo e metodologia

- Escopo autorizado: [domínios/lista].
- Ferramenta: GoPhish, com captura de credenciais **desativada** (medição de comportamento, sem coleta de senhas).
- Etapas: simulação baseline → treinamento → re-teste.

## 3. Resultados

| Métrica | Baseline | Pós-treino |
|---|---|---|
| Entregues | [—] | [—] |
| Abriram | [—]% | [—]% |
| Clicaram | [—]% | [—]% |
| Enviaram formulário | [—]% | [—]% |
| Reportaram | [—]% | [—]% |
| Tempo médio até reportar | [—] | [—] |

## 4. Achados

- **[Achado 1]** — ex.: alta taxa de clique no setor [X]. *Risco:* [—].
- **[Achado 2]** — ex.: baixo índice de reporte / ausência de canal claro. *Risco:* [—].
- **[Achado 3]** — ex.: e-mail sem SPF/DKIM/DMARC facilita spoofing. *Risco:* [—].

## 5. Recomendações priorizadas

| # | Recomendação | Prioridade | Prazo |
|---|---|---|---|
| 1 | Ativar 2FA nos sistemas críticos | Alta | 30 dias |
| 2 | Configurar SPF, DKIM e DMARC no domínio | Alta | 30 dias |
| 3 | Criar canal de reporte de phishing (botão/e-mail) | Média | 60 dias |
| 4 | Treinamento recorrente + simulações periódicas | Média | Contínuo |
| 5 | Política de segurança / manual de conduta digital | Média | 90 dias |

## 6. Próximos passos

Sugestão de acompanhamento contínuo (pacote de gestão) com simulações [mensais/trimestrais] e relatório de evolução.

## 7. Anexos

- Cópia do termo de autorização.
- Material de treinamento entregue.
