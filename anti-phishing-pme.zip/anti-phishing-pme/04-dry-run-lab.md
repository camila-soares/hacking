# 04 — Ensaio no lab (dry-run): do setup ao envio e monitoramento

Objetivo: validar o pipeline **inteiro** do GoPhish contra **você mesma**, na sua máquina, antes de tocar em qualquer cliente. Alvo = seu próprio e-mail. Sem terceiros, sem escopo externo — é só um teste do seu ferramental.

Duas opções de envio; comece pela A.

- **A) Offline (recomendado):** um "coletor" de e-mail local (Mailpit). Nada sai da sua máquina — zero risco de spam/entrega. Valida template, link, landing e dashboard.
- **B) Caixa real:** envia pro seu segundo e-mail de verdade. Use depois, pra validar **entrega** e **abertura** (pixel).

---

## Passo 1 — Subir o GoPhish

```bash
# baixe o release da sua plataforma: https://github.com/gophish/gophish/releases
unzip gophish-*.zip -d gophish && cd gophish
chmod +x gophish
./gophish
```

- Anote a **senha admin temporária** impressa no primeiro start.
- Abra `https://127.0.0.1:3333` (aceite o certificado autoassinado) e troque a senha.
- No `config.json`, confira o phish server:
  ```json
  "phish_server": { "listen_url": "0.0.0.0:8080", "use_tls": false }
  ```
  Vamos usar a porta **8080** pro dry-run (evita conflito com a 80). A URL da campanha será `http://127.0.0.1:8080`.

---

## Passo 2 — SMTP do ensaio

### Opção A — Mailpit (offline)

```bash
docker run -d --name mailpit -p 1025:1025 -p 8025:8025 axllent/mailpit
```

- SMTP local: `localhost:1025`  ·  Interface web (caixa de entrada falsa): `http://localhost:8025`
- No GoPhish, **Sending Profiles → New Profile**:
  - **Host:** `localhost:1025`
  - **From:** `rh@teste.local`
  - Username/Password: em branco. Marque "Ignore Certificate Errors" se aparecer.
- Clique em **Send Test Email** e confirme que ele aparece em `http://localhost:8025`.

### Opção B — Caixa real (mais tarde)

- **Sending Profiles → New Profile** com o SMTP do seu provedor (host, porta, usuário e **app password**).
- **From:** você  ·  destinatário do teste = **seu segundo e-mail**.

---

## Passo 3 — Landing Page (educativa, senha DESLIGADA)

**Landing Pages → New Page**:

- **Capture Submitted Data:** ligado (pra medir "enviou o formulário").
- **Capture Passwords:** **DESLIGADO** — a trava que você vai conferir no fim.
- **Redirect to:** a URL da sua página educativa (o `educativo.html` da peça `04-gophish-passo-a-passo.md`). No dry-run, pode ser qualquer página sua; o que importa é ver o redirect acontecer.
- Para a página de isca, use um formulário simples e genérico (ex.: "Portal de RH"). No GoPhish dá pra digitar/colar um HTML básico com um campo de usuário/senha e um botão.

---

## Passo 4 — Email Template

**Email Templates → New Template**, marque **Add Tracking Image** e cole:

```
Assunto: [RH] Confirme seus dados de benefício

Olá {{.FirstName}},

Precisamos que você confirme seu cadastro até sexta.
Confirmar: {{.URL}}

Equipe de RH
{{.Tracker}}
```

- `{{.URL}}` = link rastreado → sua landing.  ·  `{{.Tracker}}` = pixel de abertura.

---

## Passo 5 — Group (só você)

**Users & Groups → New Group**, importe um CSV com **uma linha — você**:

```csv
First Name,Last Name,Email,Position
Camila,Teste,SEU-EMAIL@exemplo.com,Você
```

(Na Opção A, o e-mail pode ser qualquer coisa, tipo `camila@teste.local` — o Mailpit captura tudo mesmo.)

---

## Passo 6 — Lançar a campanha

**Campaigns → New Campaign**:

- **Name:** `Dry-run — lab`
- **Email Template / Landing Page / Sending Profile:** os que você criou.
- **URL:** `http://127.0.0.1:8080`
- **Launch Date:** agora.
- **Launch.**

---

## Passo 7 — Monitorar (a parte que você quer ver)

Abra o dashboard da campanha e acompanhe os estados subirem:

**Se Opção A (Mailpit):**
1. Vá em `http://localhost:8025` e abra o e-mail capturado.
2. Confira se `{{.FirstName}}` virou "Camila" e o link apareceu.
3. Clique no link → cai na landing → é redirecionada pra página educativa.
4. Volte ao dashboard do GoPhish: **Clicked** (e **Submitted Data**, se preencher o form) sobem.
5. *Opened* provavelmente não dispara aqui (o coletor não carrega o pixel) — isso você valida na Opção B.

**Se Opção B (caixa real):**
1. Abra no seu segundo e-mail e **carregue as imagens** → dispara **Opened**.
2. Clique no link → **Clicked**.
3. Preencha e envie o form → **Submitted Data** (sem senha).

A **Timeline** da campanha mostra cada evento com horário, por destinatário.

---

## Passo 8 — Checklist de validação

O ensaio passou se **tudo** abaixo aconteceu:

- [ ] Send Test Email chegou (Mailpit ou sua caixa).
- [ ] Template renderizou `{{.FirstName}}`.
- [ ] Link `{{.URL}}` abriu a landing page.
- [ ] Depois do envio, houve **redirect** pra página educativa.
- [ ] Dashboard registrou **Clicked** (e **Submitted Data**).
- [ ] (Opção B) **Opened** disparou ao carregar imagens.
- [ ] **Confirme nos dados capturados que NÃO há senha** — só o evento. Essa é a prova de que a config ética está certa.

---

## Passo 9 — Encerrar o ensaio

```bash
docker rm -f mailpit        # se usou a Opção A
# Ctrl+C no terminal do gophish
```

- **Archive** a campanha no GoPhish.
- Tire um **snapshot** da VM com tudo configurado — no próximo cliente você só troca Sending Profile, Group e URL.

Quando esse checklist fechar 100%, você está pronta pra rodar em cliente real seguindo o `04-gophish-passo-a-passo.md` (que começa no Passo 0: termo assinado).
