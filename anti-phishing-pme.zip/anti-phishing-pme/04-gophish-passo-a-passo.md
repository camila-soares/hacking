# 04 — Runbook: Simulação de Phishing Autorizada (GoPhish)

Passo a passo operacional para rodar uma campanha de conscientização com o GoPhish, de ponta a ponta. Objetivo: **medir comportamento** (quem clica, quem reporta). Você **não** coleta senha.

> Companheiro da peça `04-simulacao-phishing.md` (visão geral). Este arquivo é o "faça exatamente isto".

---

## Passo 0 — Portão de entrada (não pule)

Só avance quando **todos** estiverem OK:

- [ ] Termo de autorização (peça 02) **assinado** pela direção.
- [ ] Lista de destinatários **fornecida pela empresa** (só colaboradores dela).
- [ ] Janela de execução definida no termo.
- [ ] Gestão avisada do cronograma + canal de suporte combinado.
- [ ] (Ideal) TI do cliente vai fazer *allowlist* do seu IP/domínio de envio, pra o e-mail chegar e não cair no filtro.

Sem o Passo 0 completo, não existe Passo 1.

---

## Passo 1 — Ambiente

- Rode o GoPhish numa **máquina sua**: uma VM do seu lab ou um VPS pequeno, isolado.
- Portas: **3333** (painel admin) e **80/443** (servidor de phishing, que serve a landing page).
- Domínio: use um **domínio seu, dedicado à simulação**. Não registre imitação de marca real; o pretexto será interno e genérico.
- Para realismo e boa entrega, aponte um DNS com **SPF/DKIM** no domínio de envio (também é assunto que você vende como recomendação depois).

---

## Passo 2 — Instalar o GoPhish

```bash
# baixe o release da sua plataforma em https://github.com/gophish/gophish/releases
unzip gophish-*.zip -d gophish && cd gophish
chmod +x gophish
./gophish
```

- No **primeiro start**, o GoPhish gera uma **senha admin temporária** e imprime no terminal/log. Anote e troque no primeiro login.
- Painel: `https://127.0.0.1:3333` (certificado autoassinado — aceite o aviso).
- No `config.json`, mantenha o **admin_server** ouvindo só em `127.0.0.1:3333` (nunca exponha o painel na internet) e o **phish_server** em `0.0.0.0:80` (ou 443 com TLS).

---

## Passo 3 — Sending Profile (o remetente)

Menu **Sending Profiles → New Profile**:

- **Host:** SMTP autorizado (caixa dedicada do seu domínio de simulação ou relay transacional).
- **From:** o remetente do pretexto aprovado (ex.: `rh@seudominio-sim.com`).
- Clique em **Send Test Email** e confirme que chega bonito na sua caixa antes de qualquer coisa.

---

## Passo 4 — Landing Page (educativa, captura DESLIGADA)

Menu **Landing Pages → New Page**. Aqui está a trava que define o serviço:

- **Capture Submitted Data:** pode deixar **LIGADO** — serve pra medir quem *enviou* o formulário (sinal forte de risco).
- **Capture Passwords:** **DESLIGADO.** Você registra que houve envio, nunca o que foi digitado.
- **Redirect to:** a URL da sua **página educativa** (abaixo). Quem "cair" é levado na hora pro momento ensinável.

A página de isca em si deve ser um formulário **interno e genérico** (ex.: "Portal de RH"), não um clone de banco/marca. O valor está no redirect educativo, não em colher dado.

### Página educativa (salve como `educativo.html` e hospede junto)

```html
<!doctype html>
<html lang="pt-BR">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Isto foi um teste de segurança</title>
<style>
  body{font-family:system-ui,Arial,sans-serif;background:#f4f6f9;color:#1a1a1a;margin:0;padding:40px}
  .card{max-width:640px;margin:0 auto;background:#fff;border-radius:12px;padding:32px;box-shadow:0 4px 20px rgba(0,0,0,.08)}
  h1{color:#1F3A5F;margin-top:0} .tag{display:inline-block;background:#E8EEF5;color:#1F3A5F;padding:4px 12px;border-radius:999px;font-size:14px;font-weight:600}
  ul{line-height:1.7} .foot{color:#6B7280;font-size:14px;margin-top:24px}
</style></head>
<body><div class="card">
  <span class="tag">Simulação de segurança</span>
  <h1>Calma — isto foi um teste.</h1>
  <p>Este e-mail fez parte de um <strong>treinamento de conscientização anti-phishing</strong> autorizado pela sua empresa. Nenhuma senha foi capturada e nenhum dado seu foi comprometido.</p>
  <p>O objetivo é te ajudar a reconhecer golpes reais. Da próxima vez, fique atento(a) a:</p>
  <ul>
    <li>Urgência e ameaça ("sua conta será bloqueada").</li>
    <li>Remetente cujo domínio não bate com o oficial.</li>
    <li>Link que, ao passar o mouse, aponta pra outro endereço.</li>
    <li>Pedido de senha ou pagamento por link.</li>
  </ul>
  <p><strong>Na dúvida, não clique</strong> — reporte pelo canal de segurança da empresa.</p>
  <p class="foot">Treinamento conduzido por [SUA MARCA]. Dúvidas: [seu contato].</p>
</div></body></html>
```

---

## Passo 5 — Email Template (o pretexto aprovado)

Menu **Email Templates → New Template**. Use o pretexto do escopo. Exemplo genérico:

```
Assunto: [RH] Confirmação de dados de benefício — ação necessária

Olá {{.FirstName}},

Estamos atualizando o cadastro de benefícios e precisamos que você confirme
seus dados até sexta-feira para não haver interrupção.

Confirmar agora: {{.URL}}

Obrigado,
Equipe de RH
{{.Tracker}}
```

- `{{.URL}}` é o link rastreado que leva à sua landing page.
- `{{.Tracker}}` é o pixel de abertura (marque **Add Tracking Image**).
- Mantenha o pretexto **interno**; não personifique marca externa real.

---

## Passo 6 — Groups (destinatários autorizados)

Menu **Users & Groups → New Group**. Importe o CSV da lista autorizada:

```csv
First Name,Last Name,Email,Position
Maria,Silva,maria.silva@cliente.com,Financeiro
João,Souza,joao.souza@cliente.com,Operações
```

Só entram aqui pessoas da **lista fornecida pela empresa**.

---

## Passo 7 — Campaign (lançar dentro da janela)

Menu **Campaigns → New Campaign**:

- **Name:** ex. `Cliente X — Baseline — set/2026`.
- **Email Template / Landing Page / Sending Profile:** os que você criou.
- **URL:** o endereço do seu phish server (o que vai no `{{.URL}}`).
- **Launch Date** e, se quiser diluir o envio, **Send Emails By** (evita pico e cara de spam).
- **Launch** — dentro da janela do termo.

---

## Passo 8 — Monitoramento

No dashboard da campanha você acompanha em tempo real:

- **Sent / Delivered** — envio e entrega.
- **Opened** — abertura (pelo pixel).
- **Clicked** — clique no link.
- **Submitted Data** — enviou o formulário (interação; sem conteúdo de senha).
- **Reported** — reportou. Meça pelo **canal de reporte do cliente** (caixa de segurança/botão) e marque no acompanhamento. É a métrica mais valiosa: **tempo médio até reportar**.

---

## Passo 9 — Encerramento

- [ ] **Complete/Archive** a campanha ao fim da janela.
- [ ] **Exporte os resultados** (CSV do GoPhish) para alimentar o relatório.
- [ ] **Desligue o phish server**.
- [ ] **Descarte os dados** conforme o prazo do termo (peça 02).
- [ ] Garanta que quem clicou passou pela **página educativa** (o momento ensinável).
- [ ] Gere o **relatório** (peça 05) com baseline vs. pós-treino.

---

## Boas práticas de conduta (o que te mantém contratável)

- **Baseline antes, re-teste depois** — a melhora é o seu argumento de venda e renovação.
- **Nunca exponha nem puna** ninguém individualmente. Reporte **agregado**, foco em melhoria coletiva.
- **Redirect na hora do clique** — treino no instante em que a pessoa erra.
- **Não** exponha o painel admin; **não** capture senha; **não** teste fora da lista/janela.

---

## Troubleshooting rápido

- **E-mail não chega:** peça o *allowlist* do seu IP/domínio à TI do cliente; configure SPF/DKIM; dilua o envio.
- **Cai no spam:** domínio de envio "aquecido", TLS no phish server, evite anexos.
- **Landing não carrega externamente:** cheque porta 80/443 aberta e o DNS do domínio de simulação.
