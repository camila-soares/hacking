# 01 — Proposta Comercial

## O problema (a dor do cliente)

A maioria dos ataques que fecham empresas começa com **uma pessoa clicando** — não com uma falha técnica sofisticada. PME quase nunca treina funcionário para isso e não sabe o quanto está exposta. Você entra medindo essa exposição e reduzindo ela.

## O serviço

Um programa que combina **medir → treinar → remedir → recomendar**:

1. Diagnóstico inicial: simulação de phishing autorizada para estabelecer a taxa de clique atual (baseline).
2. Treinamento dos funcionários.
3. Re-teste: nova simulação para provar a melhora.
4. Relatório executivo com recomendações técnicas priorizadas.

## Pacotes

### Pacote Diagnóstico (pontual)
- 1 simulação (baseline) + treinamento (workshop) + 1 re-teste + relatório.
- Bom como porta de entrada / prova de valor.

### Pacote Gestão Contínua (recorrente/mensal)
- Simulações periódicas (ex.: mensais/trimestrais) + microtreinos + relatório de evolução.
- Receita recorrente. É aqui que o serviço vira previsível.

### Add-ons
- Configuração de proteções de e-mail (SPF/DKIM/DMARC), 2FA, canal de reporte.
- Política de segurança / manual de conduta digital.

## Precificação (calibre ao seu mercado)

Use como âncora as faixas que o próprio setor pratica (consultoria de segurança para PME costuma girar em **R$1.000–5.000/mês** para gestão contínua). Fatores que movem o preço:

- Nº de funcionários (principal driver da simulação e do treino).
- Pontual vs recorrente.
- Presencial vs remoto (100% remoto é viável).
- Add-ons técnicos.

Dica: cobre o **diagnóstico** com preço acessível para entrar, e converta em **recorrente** com o relatório na mão mostrando o risco.

## Seu diferencial

Você é desenvolvedora. Não entrega só "não clique em link" — você entende o lado técnico (autenticação de e-mail, 2FA, cabeçalhos, o app da empresa). Isso te posiciona acima do consultor genérico e abre a porta pra vender também o hardening técnico.

## Entregáveis

- Relatório executivo (peça 05).
- Material de treinamento (peça 03) + certificado de participação, se quiser.
- Recomendações priorizadas com prazo.
