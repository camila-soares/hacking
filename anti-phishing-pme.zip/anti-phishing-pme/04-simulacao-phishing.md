# 04 — Simulação de Phishing Autorizada

Objetivo: medir **comportamento** (quem clica, quem reporta), não roubar senha. A diferença entre este serviço e um crime está inteira neste arquivo.

## Pré-requisitos

- [ ] Termo de autorização (peça 02) **assinado** pela direção.
- [ ] Lista de destinatários fornecida pela empresa (só colaboradores dela).
- [ ] Ferramenta: **GoPhish** (open source, self-host) — https://getgophish.com/. Roda numa VM/servidor seu.

## Configuração ética (não negociável)

- **Desative a captura de credenciais.** No GoPhish existe a opção de "capture submitted data / capture passwords" — deixe **desligada**. Você registra que a pessoa *enviou* o formulário, não o que ela digitou.
- **Landing page = página educativa.** Quem clicar/enviar cai numa página que revela "isto foi um teste de segurança" + as dicas da peça 03. Nada de página que só colhe dado.
- **Pretexto interno e genérico**, autorizado no escopo (ex.: "Portal de RH — confirme seus dados de benefício"). Evite clonar login de banco ou marca real cujo único propósito seria colher credencial.
- **Avise a gestão** do cronograma e tenha um canal de suporte durante a campanha.

## Passo a passo

1. Suba o GoPhish num ambiente seu.
2. Cadastre o **Sending Profile** (servidor de e-mail de envio autorizado).
3. Crie o **Email Template** com o pretexto aprovado.
4. Crie a **Landing Page** educativa (com captura de senha DESLIGADA).
5. Importe os **destinatários** (a lista autorizada).
6. Lance a **Campaign** dentro da janela do escopo.
7. Acompanhe os eventos no painel.

## Métricas que você entrega

- Taxa de **envio** e **entrega**.
- Taxa de **abertura**.
- Taxa de **clique**.
- Taxa de **envio de formulário** (interação, sem conteúdo da senha).
- Taxa de **reporte** e **tempo médio até reportar** (a métrica mais importante).

## Boas práticas de conduta

- Meça **baseline** antes do treino e **re-teste** depois — a melhora é o seu argumento de venda.
- **Não exponha nem puna** ninguém individualmente. Reporte agregado; foco em melhoria coletiva.
- Redirecione quem clicou para o microtreino na hora — o "momento ensinável" é logo após o clique.

## Encerramento

- Desligue a campanha ao fim da janela.
- Descarte os dados conforme o prazo do termo.
- Gere o relatório (peça 05).
