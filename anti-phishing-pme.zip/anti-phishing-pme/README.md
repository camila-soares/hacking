# Kit: Programa de Conscientização Anti-Phishing para PME

Um serviço de segurança **defensivo** que você pode vender para pequenas e médias empresas: treina os funcionários a reconhecer phishing, mede o quanto eles caem hoje (simulação autorizada) e entrega um relatório com o que melhorar.

É a "versão profissional" da engenharia social da Aula 5 — a que gera receita e não te expõe legalmente.

## As 5 peças

1. **`01-proposta-comercial.md`** — a oferta, os pacotes e como precificar.
2. **`02-autorizacao-escopo.md`** — o termo que o cliente assina **antes** de qualquer coisa. Sem isto, não começa.
3. **`03-treinamento-funcionarios.md`** — o conteúdo da capacitação.
4. **`04-simulacao-phishing.md`** — como rodar a simulação de forma autorizada e ética.
5. **`05-relatorio-modelo.md`** — o laudo final que você entrega.

## Fluxo do serviço

```
Proposta  ->  Autorização assinada  ->  Simulação (baseline)
      ->  Treinamento  ->  Simulação (re-teste)  ->  Relatório
```

## As 2 regras que sustentam o serviço

- **Nada roda sem autorização escrita** da direção da empresa (peça 02). Você só testa funcionários do próprio cliente, dentro do escopo assinado.
- **A simulação NÃO coleta senha real.** Ela registra o *evento* (abriu, clicou, enviou, reportou) e redireciona pra uma página educativa. Você mede comportamento, não rouba credencial. É isso que separa consultoria de crime.
