# RELATÓRIO DE TESTE DE SEGURANÇA EM APLICAÇÃO

**Cliente:** Cliente Exemplo LTDA
**Aplicação avaliada:** Portal de Contratos
**Período de execução:** 01/09/2026 a 05/09/2026
**Responsável técnico:** Camila — SuaEmpresa Segurança
**Data de emissão:** 09/09/2026

**Classificação:** CONFIDENCIAL — distribuição restrita

---

# 1. Sumário Executivo

Foi realizado teste de intrusão sobre **Portal de Contratos**, identificando **2 vulnerabilidades**. O nível de risco geral da aplicação foi classificado como **CRÍTICO**.

| Severidade | Quantidade |
|------------|-----------:|
| 🔴 Crítica | 1 |
| 🔵 Baixa | 1 |

### Principais riscos ao negócio

- **IDOR em consulta de contratos** — Usuário comum acessa contratos de outros clientes (LGPD art. 48).

---

# 2. Escopo e Metodologia

Os testes seguiram o OWASP WSTG, com classificação de severidade por CVSS v3.1.

## 2.5 Superfície de Ataque (OSINT)

O reconhecimento passivo do domínio **cliente.com.br** identificou **3 subdomínios**, dos quais **2** resolvem para um endereço IP ativo. **1** foram corroborados por duas ou mais fontes independentes. Foram ainda expostos **1 endereços de e-mail** em fontes públicas.

*Fontes consultadas: crtsh, dnsx, spiderfoot, subfinder.*

### Ativos identificados

| Subdomínio | IP(s) resolvido(s) | Fontes | Status |
|------------|--------------------|--------|--------|
| www.cliente.com.br | 187.1.2.3 | crtsh, spiderfoot | 🟢 Ativo |
| api.cliente.com.br | 187.1.2.4 | crtsh | 🟢 Ativo |
| hml.cliente.com.br | — | subfinder | ⚪ Não resolvido |

### Endereços de e-mail expostos

- ti@cliente.com.br

---

# 3. Resumo dos Achados

| ID | Vulnerabilidade | Severidade | CVSS | Ativo | Status |
|----|-----------------|-----------|-----:|-------|--------|
| VUL-001 | IDOR em consulta de contratos | 🔴 Crítica | 8.6 | GET /api/v1/contratos/{id} | Aberto |
| VUL-002 | Cabeçalhos de segurança ausentes | 🔵 Baixa | 3.1 | www.cliente.com.br | Aberto |

---

# 4. Achados Detalhados

## VUL-001 — IDOR em consulta de contratos

| Campo | Valor |
|-------|-------|
| **Severidade** | 🔴 Crítica |
| **CVSS v3.1** | 8.6 — `AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N` |
| **Classificação** | CWE-639 / OWASP A01:2021 |
| **Ativo afetado** | GET /api/v1/contratos/{id} |
| **Status** | Aberto |

### Descrição

Endpoint não valida propriedade do recurso.

### Impacto no negócio

Usuário comum acessa contratos de outros clientes (LGPD art. 48).

### Passos para reprodução

1. Autenticar como usuário comum
2. Trocar o id na URL
3. Recebe 200 com dado alheio

### Recomendação

Validar propriedade no servidor com @PreAuthorize.

---

## VUL-002 — Cabeçalhos de segurança ausentes

| Campo | Valor |
|-------|-------|
| **Severidade** | 🔵 Baixa |
| **CVSS v3.1** | 3.1 |
| **Ativo afetado** | www.cliente.com.br |
| **Status** | Aberto |

### Descrição

CSP e HSTS ausentes.

### Recomendação

Adicionar CSP e HSTS.

---

# 5. Plano de Remediação Priorizado

| # | Achado | Ação | Prazo sugerido |
|---|--------|------|----------------|
| 1 | VUL-001 | Validar propriedade no servidor com @PreAuthorize. | Imediato (7 dias) |
| 2 | VUL-002 | Adicionar CSP e HSTS. | Oportuno |

---

# 6. Reteste

Está previsto reteste das vulnerabilidades corrigidas até 05/10/2026, sem custo adicional.

---

*Documento confidencial. Reprodução total ou parcial mediante autorização escrita.*
