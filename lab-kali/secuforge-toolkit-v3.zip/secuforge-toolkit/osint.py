#!/usr/bin/env python3
"""
osint.py — Coleta OSINT passiva (versão enxuta para o Bug Bounty Toolkit).

Faz SÓ o que o recon do toolkit ainda não faz, para não duplicar trabalho:
  - crt.sh        (Certificate Transparency — corrobora subdomínios)
  - theHarvester  (E-MAILS e hosts em fontes públicas — o recon não coleta)

Descoberta ampla de subdomínios e resolução (httpx/subfinder) continuam a
cargo do recon.sh / recon-full.sh. Aqui o valor é a corroboração por crt.sh
e, principalmente, os e-mails expostos.

Saída no mesmo schema de merge.py / attack_surface.py, para consolidar com
o resultado do recon e com o SpiderFoot.

Uso avulso:
    python3 osint.py exemplo.com.br
    python3 osint.py exemplo.com.br -o osint.json --timeout 180
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from typing import Any

import requests

DEFAULT_TIMEOUT = 120
HTTP_TIMEOUT = 30
USER_AGENT = "bb-toolkit-osint/1.0"


@dataclass
class SourceResult:
    source: str
    status: str = "ok"            # ok | skipped | error
    detail: str = ""
    data: dict[str, Any] = field(default_factory=dict)


def _has_binary(name: str) -> bool:
    return shutil.which(name) is not None


# ── Fontes ───────────────────────────────────────────────────────────────

def crtsh_subdomains(domain: str) -> SourceResult:
    """Subdomínios via Certificate Transparency (crt.sh). Sem chave."""
    res = SourceResult(source="crtsh")
    try:
        r = requests.get(
            "https://crt.sh/",
            params={"q": f"%.{domain}", "output": "json"},
            headers={"User-Agent": USER_AGENT},
            timeout=HTTP_TIMEOUT,
        )
        r.raise_for_status()
        found: set[str] = set()
        for entry in r.json():
            for name in entry.get("name_value", "").splitlines():
                name = name.strip().lstrip("*.").lower()
                if name.endswith(domain):
                    found.add(name)
        res.data = {"subdomains": sorted(found)}
    except Exception as exc:
        res.status = "error"
        res.detail = str(exc)
    return res


def theharvester_hosts(domain: str, timeout: int) -> SourceResult:
    """E-mails e hosts via theHarvester (fontes públicas)."""
    res = SourceResult(source="theharvester")
    binary = ("theHarvester" if _has_binary("theHarvester")
              else "theharvester" if _has_binary("theharvester") else None)
    if binary is None:
        res.status = "skipped"
        res.detail = "theHarvester não instalado"
        return res

    tmp = f"/tmp/harvest_{domain.replace('.', '_')}"
    try:
        subprocess.run(
            [binary, "-d", domain, "-b", "crtsh,bing,duckduckgo,otx", "-f", tmp],
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        res.status = "error"
        res.detail = f"timeout após {timeout}s"
    except FileNotFoundError:
        res.status = "skipped"
        res.detail = "theHarvester não encontrado"
        return res

    emails: list[str] = []
    hosts: list[str] = []
    json_path = f"{tmp}.json"
    if os.path.exists(json_path):
        try:
            with open(json_path, encoding="utf-8") as fh:
                parsed = json.load(fh)
            emails = sorted(set(parsed.get("emails", [])))
            hosts = sorted({h.lower() for h in parsed.get("hosts", [])
                            if str(h).lower().endswith(domain)})
        except Exception as exc:
            res.status = "error"
            res.detail = (res.detail + f" | parse: {exc}").strip(" |")
        finally:
            try:
                os.remove(json_path)
            except OSError:
                pass
    res.data = {"emails": emails, "hosts": hosts}
    return res


# ── Agregação (mesmo schema de merge.py) ─────────────────────────────────

def collect_stream(domain: str, timeout: int = DEFAULT_TIMEOUT):
    """Gera eventos por fonte (para o SSE). crt.sh primeiro, theHarvester depois."""
    all_subs: set[str] = set()
    all_emails: set[str] = set()

    for produce in (
        lambda: crtsh_subdomains(domain),
        lambda: theharvester_hosts(domain, timeout),
    ):
        res = produce()
        all_subs.update(res.data.get("subdomains", []))
        all_subs.update(res.data.get("hosts", []))
        all_emails.update(res.data.get("emails", []))
        yield {"type": "source", **asdict(res)}

    all_subs = {s for s in all_subs if s.endswith(domain)}
    yield {"type": "summary", "target": domain,
           "subdomains": sorted(all_subs), "emails": sorted(all_emails)}


def collect(domain: str, timeout: int = DEFAULT_TIMEOUT) -> dict[str, Any]:
    """Versão batch — dict normalizado pronto para merge.py / report."""
    sources: dict[str, Any] = {}
    summary: dict[str, Any] = {"subdomains": [], "emails": []}
    for evt in collect_stream(domain, timeout):
        if evt["type"] == "source":
            sources[evt["source"]] = {
                k: evt[k] for k in ("source", "status", "detail", "data")
            }
        else:
            summary = evt
    return {
        "target": domain,
        "subdomains": summary["subdomains"],
        "emails": summary["emails"],
        "sources": sources,
    }


# ── CLI ──────────────────────────────────────────────────────────────────

def _main() -> int:
    p = argparse.ArgumentParser(description="Coleta OSINT passiva (crt.sh + theHarvester).")
    p.add_argument("domain", help="domínio alvo, ex.: exemplo.com.br")
    p.add_argument("-o", "--output", help="grava o JSON em arquivo")
    p.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    args = p.parse_args()

    result = collect(args.domain, timeout=args.timeout)
    payload = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(payload)
        print(f"[+] {result['target']}: {len(result['subdomains'])} subdomínios, "
              f"{len(result['emails'])} e-mails → {args.output}", file=sys.stderr)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
