#!/usr/bin/env python3
"""
laudo.py — Montagem do relatório final de teste de segurança.

Junta três insumos num único documento:
  1. metadados do engajamento (cliente, período, responsável);
  2. a seção "Superfície de Ataque" gerada por attack_surface.py;
  3. a lista de achados (findings).

Produz Markdown sempre; HTML e PDF são opcionais (dependem de markdown2 e
weasyprint, instalados no container).

Uso avulso:
    python laudo.py --meta meta.json --osint consolidado.json \
                    --findings findings.json -o relatorio.pdf
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from typing import Any

import attack_surface

SEV_ORDER = ["Crítica", "Alta", "Média", "Baixa", "Informativa"]
SEV_EMOJI = {
    "Crítica": "🔴", "Alta": "🟠", "Média": "🟡",
    "Baixa": "🔵", "Informativa": "⚪",
}


def _sev_key(finding: dict[str, Any]) -> int:
    sev = finding.get("severidade", "Informativa")
    return SEV_ORDER.index(sev) if sev in SEV_ORDER else len(SEV_ORDER)


def _risk_level(counts: dict[str, int]) -> str:
    if counts.get("Crítica"):
        return "CRÍTICO"
    if counts.get("Alta"):
        return "ALTO"
    if counts.get("Média"):
        return "MÉDIO"
    if counts.get("Baixa"):
        return "BAIXO"
    return "INFORMATIVO"


def _md_escape(text: Any) -> str:
    return str(text).replace("|", "\\|")


def _cabecalho(meta: dict[str, Any]) -> list[str]:
    hoje = date.today().strftime("%d/%m/%Y")
    return [
        "# RELATÓRIO DE TESTE DE SEGURANÇA EM APLICAÇÃO",
        "",
        f"**Cliente:** {meta.get('cliente', '—')}",
        f"**Aplicação avaliada:** {meta.get('aplicacao', '—')}",
        f"**Período de execução:** {meta.get('periodo', '—')}",
        f"**Responsável técnico:** {meta.get('responsavel', '—')} — "
        f"{meta.get('empresa', '—')}",
        f"**Data de emissão:** {meta.get('emissao', hoje)}",
        "",
        "**Classificação:** CONFIDENCIAL — distribuição restrita",
        "",
        "---",
        "",
    ]


def _sumario_executivo(meta: dict[str, Any], counts: dict[str, int],
                       findings: list[dict[str, Any]]) -> list[str]:
    total = sum(counts.values())
    nivel = _risk_level(counts)
    lines = ["# 1. Sumário Executivo", ""]
    lines.append(
        f"Foi realizado teste de intrusão sobre **{meta.get('aplicacao', '—')}**, "
        f"identificando **{total} vulnerabilidades**. O nível de risco geral da "
        f"aplicação foi classificado como **{nivel}**."
    )
    lines.append("")
    lines.append("| Severidade | Quantidade |")
    lines.append("|------------|-----------:|")
    for sev in SEV_ORDER:
        if counts.get(sev):
            lines.append(f"| {SEV_EMOJI[sev]} {sev} | {counts[sev]} |")
    lines.append("")

    principais = [f for f in findings
                  if f.get("severidade") in ("Crítica", "Alta")]
    if principais:
        lines.append("### Principais riscos ao negócio")
        lines.append("")
        for f in principais:
            resumo = f.get("impacto") or f.get("descricao") or f.get("titulo")
            lines.append(f"- **{_md_escape(f.get('titulo', f.get('id')))}** — "
                         f"{_md_escape(str(resumo).splitlines()[0])}")
        lines.append("")
    lines.append("---")
    lines.append("")
    return lines


def _resumo_achados(findings: list[dict[str, Any]]) -> list[str]:
    lines = ["# 3. Resumo dos Achados", ""]
    lines.append("| ID | Vulnerabilidade | Severidade | CVSS | Ativo | Status |")
    lines.append("|----|-----------------|-----------|-----:|-------|--------|")
    for f in findings:
        sev = f.get("severidade", "—")
        emoji = SEV_EMOJI.get(sev, "")
        lines.append(
            f"| {_md_escape(f.get('id', '—'))} "
            f"| {_md_escape(f.get('titulo', '—'))} "
            f"| {emoji} {sev} "
            f"| {f.get('cvss', '—')} "
            f"| {_md_escape(f.get('ativo', '—'))} "
            f"| {_md_escape(f.get('status', 'Aberto'))} |"
        )
    lines.append("")
    lines.append("---")
    lines.append("")
    return lines


def _achado_detalhado(f: dict[str, Any]) -> list[str]:
    sev = f.get("severidade", "—")
    emoji = SEV_EMOJI.get(sev, "")
    lines = [f"## {f.get('id', '—')} — {f.get('titulo', '—')}", ""]
    lines.append("| Campo | Valor |")
    lines.append("|-------|-------|")
    lines.append(f"| **Severidade** | {emoji} {sev} |")
    cvss = f.get("cvss")
    vetor = f.get("cvss_vetor", "")
    if cvss is not None:
        lines.append(f"| **CVSS v3.1** | {cvss}"
                     + (f" — `{vetor}`" if vetor else "") + " |")
    if f.get("classificacao"):
        lines.append(f"| **Classificação** | {_md_escape(f['classificacao'])} |")
    lines.append(f"| **Ativo afetado** | {_md_escape(f.get('ativo', '—'))} |")
    lines.append(f"| **Status** | {_md_escape(f.get('status', 'Aberto'))} |")
    lines.append("")

    if f.get("descricao"):
        lines += ["### Descrição", "", str(f["descricao"]), ""]
    if f.get("impacto"):
        lines += ["### Impacto no negócio", "", str(f["impacto"]), ""]

    repro = f.get("reproducao")
    if repro:
        lines += ["### Passos para reprodução", ""]
        if isinstance(repro, (list, tuple)):
            for i, passo in enumerate(repro, 1):
                lines.append(f"{i}. {passo}")
        else:
            lines.append(str(repro))
        lines.append("")

    if f.get("evidencia"):
        lines += ["### Evidência", "", f"`[{f['evidencia']}]`", ""]
    if f.get("recomendacao"):
        lines += ["### Recomendação", "", str(f["recomendacao"]), ""]

    refs = f.get("referencias")
    if refs:
        lines += ["### Referências", ""]
        for r in refs:
            lines.append(f"- {r}")
        lines.append("")

    lines += ["---", ""]
    return lines


def _plano_remediacao(findings: list[dict[str, Any]]) -> list[str]:
    lines = ["# 5. Plano de Remediação Priorizado", ""]
    lines.append("| # | Achado | Ação | Prazo sugerido |")
    lines.append("|---|--------|------|----------------|")
    prazos = {"Crítica": "Imediato (7 dias)", "Alta": "30 dias",
              "Média": "Próximo ciclo", "Baixa": "Oportuno",
              "Informativa": "Opcional"}
    for i, f in enumerate(findings, 1):
        acao = (f.get("recomendacao") or "—").splitlines()[0]
        prazo = prazos.get(f.get("severidade"), "—")
        lines.append(f"| {i} | {_md_escape(f.get('id', '—'))} "
                     f"| {_md_escape(acao)} | {prazo} |")
    lines.append("")
    lines.append("---")
    lines.append("")
    return lines


def build_markdown(meta: dict[str, Any], consolidated: dict[str, Any],
                   findings: list[dict[str, Any]]) -> str:
    findings = sorted(findings or [], key=_sev_key)
    counts: dict[str, int] = {}
    for f in findings:
        sev = f.get("severidade", "Informativa")
        counts[sev] = counts.get(sev, 0) + 1

    parts: list[str] = []
    parts += _cabecalho(meta)
    parts += _sumario_executivo(meta, counts, findings)

    parts += ["# 2. Escopo e Metodologia", "",
              "Os testes seguiram o OWASP WSTG, com classificação de "
              "severidade por CVSS v3.1.", ""]
    if consolidated:
        parts += [attack_surface.build_section(consolidated), ""]
    parts += ["---", ""]

    parts += _resumo_achados(findings)

    parts += ["# 4. Achados Detalhados", ""]
    if findings:
        for f in findings:
            parts += _achado_detalhado(f)
    else:
        parts += ["*Nenhuma vulnerabilidade identificada.*", "", "---", ""]

    parts += _plano_remediacao(findings)

    parts += [
        "# 6. Reteste", "",
        f"Está previsto reteste das vulnerabilidades corrigidas até "
        f"{meta.get('reteste', '—')}, sem custo adicional.", "",
        "---", "",
        "*Documento confidencial. Reprodução total ou parcial mediante "
        "autorização escrita.*",
    ]
    return "\n".join(parts)


def to_html(markdown_text: str, titulo: str = "Relatório") -> str:
    try:
        import markdown2
    except ImportError as exc:
        raise RuntimeError(
            "markdown2 não instalado (pip install markdown2)") from exc

    body = markdown2.markdown(
        markdown_text, extras=["tables", "fenced-code-blocks", "cuddled-lists"]
    )
    css = """
    @page { size: A4; margin: 2cm; }
    body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 11pt;
           color: #1a1a1a; line-height: 1.5; }
    h1 { border-bottom: 2px solid #444; padding-bottom: 4px; }
    table { border-collapse: collapse; width: 100%; margin: 12px 0;
            font-size: 10pt; }
    th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
    th { background: #f0f0f0; }
    code { background: #f4f4f4; padding: 1px 4px; border-radius: 3px; }
    pre { background: #f4f4f4; padding: 10px; border-radius: 4px;
          overflow-x: auto; }
    blockquote { border-left: 4px solid #bbb; margin: 8px 0; padding: 4px 12px;
                 color: #555; }
    """
    return (f"<!doctype html><html><head><meta charset='utf-8'>"
            f"<title>{titulo}</title><style>{css}</style></head>"
            f"<body>{body}</body></html>")


def to_pdf(html: str, output_path: str) -> None:
    try:
        from weasyprint import HTML
    except ImportError as exc:
        raise RuntimeError(
            "weasyprint não instalado (pip install weasyprint)") from exc
    HTML(string=html).write_pdf(output_path)


def generate(meta: dict[str, Any], consolidated: dict[str, Any],
             findings: list[dict[str, Any]], output_path: str) -> str:
    md = build_markdown(meta, consolidated, findings)

    if output_path.endswith(".md"):
        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write(md)
    elif output_path.endswith(".html"):
        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write(to_html(md, meta.get("cliente", "Relatório")))
    elif output_path.endswith(".pdf"):
        to_pdf(to_html(md, meta.get("cliente", "Relatório")), output_path)
    else:
        raise ValueError("extensão não suportada: use .md, .html ou .pdf")
    return output_path


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Monta o relatório final de teste de segurança.",
    )
    parser.add_argument("--meta", required=True, help="JSON de metadados")
    parser.add_argument("--osint", help="JSON consolidado do merge.py")
    parser.add_argument("--findings", required=True, help="JSON (lista) de achados")
    parser.add_argument("-o", "--output", required=True,
                        help="saída: .md, .html ou .pdf")
    args = parser.parse_args()

    meta = _load(args.meta)
    consolidated = _load(args.osint) if args.osint else {}
    findings = _load(args.findings)

    try:
        path = generate(meta, consolidated, findings, args.output)
    except RuntimeError as exc:
        print(f"[!] {exc}", file=sys.stderr)
        return 1

    print(f"[+] relatório gerado → {path}", file=sys.stderr)
    return 0


def _load(path: str) -> Any:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


if __name__ == "__main__":
    raise SystemExit(_main())
