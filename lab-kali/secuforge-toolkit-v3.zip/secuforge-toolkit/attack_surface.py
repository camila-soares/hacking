#!/usr/bin/env python3
"""
attack_surface.py — Gera a seção "Superfície de Ataque" do relatório.

Uso avulso:
    python attack_surface.py consolidado.json
    python attack_surface.py consolidado.json -o superficie.md
"""

from __future__ import annotations

import argparse
import ipaddress
import json
import re
import sys
from typing import Any

_IP_RE = re.compile(r"[\[\s]([0-9a-fA-F:.]+)\]?")


def _extract_ip_map(consolidated: dict[str, Any]) -> dict[str, list[str]]:
    ip_map: dict[str, set[str]] = {}
    for entry in (consolidated.get("sources") or {}).values():
        data = (entry or {}).get("data", {}) or {}
        for line in data.get("resolved", []) or []:
            parts = str(line).split()
            if not parts:
                continue
            host = parts[0].strip().lower().rstrip(".")
            for token in _IP_RE.findall(line):
                try:
                    ipaddress.ip_address(token)
                except ValueError:
                    continue
                ip_map.setdefault(host, set()).add(token)
    return {h: sorted(v) for h, v in ip_map.items()}


def _md_escape(text: str) -> str:
    return str(text).replace("|", "\\|")


def build_section(consolidated: dict[str, Any]) -> str:
    target = consolidated.get("target") or "—"
    subdomains: list[str] = consolidated.get("subdomains", []) or []
    emails: list[str] = consolidated.get("emails", []) or []
    provenance: dict[str, list[str]] = consolidated.get("provenance", {}) or {}
    stats: dict[str, Any] = consolidated.get("stats", {}) or {}
    ip_map = _extract_ip_map(consolidated)

    total = len(subdomains)
    corroborados = stats.get("corroborados", sum(
        1 for s in subdomains if len(provenance.get(s, [])) > 1
    ))
    resolvidos = sum(1 for s in subdomains if ip_map.get(s))
    fontes = stats.get("fontes") or sorted(consolidated.get("sources", {}).keys())

    lines: list[str] = []
    lines.append("## 2.5 Superfície de Ataque (OSINT)")
    lines.append("")
    lines.append(
        f"O reconhecimento passivo do domínio **{_md_escape(target)}** "
        f"identificou **{total} subdomínios**, dos quais **{resolvidos}** "
        f"resolvem para um endereço IP ativo. **{corroborados}** foram "
        f"corroborados por duas ou mais fontes independentes. Foram ainda "
        f"expostos **{len(emails)} endereços de e-mail** em fontes públicas."
    )
    lines.append("")
    lines.append(f"*Fontes consultadas: {', '.join(fontes) if fontes else '—'}.*")
    lines.append("")

    lines.append("### Ativos identificados")
    lines.append("")
    lines.append("| Subdomínio | IP(s) resolvido(s) | Fontes | Status |")
    lines.append("|------------|--------------------|--------|--------|")
    if subdomains:
        for sub in subdomains:
            ips = ip_map.get(sub, [])
            ip_cell = ", ".join(ips) if ips else "—"
            src_cell = ", ".join(provenance.get(sub, [])) or "—"
            status = "🟢 Ativo" if ips else "⚪ Não resolvido"
            lines.append(
                f"| {_md_escape(sub)} | {_md_escape(ip_cell)} "
                f"| {_md_escape(src_cell)} | {status} |"
            )
    else:
        lines.append("| — | — | — | Nenhum subdomínio identificado |")
    lines.append("")

    lines.append("### Endereços de e-mail expostos")
    lines.append("")
    if emails:
        for mail in emails:
            lines.append(f"- {_md_escape(mail)}")
    else:
        lines.append("*Nenhum endereço de e-mail identificado em fontes públicas.*")
    lines.append("")

    lines.append("### Observações")
    lines.append("")
    lines.append(
        "> A quantidade de subdomínios ativos define a superfície real de "
        "exposição da organização. Hosts esquecidos ou de homologação "
        "publicamente acessíveis são vetor comum de comprometimento e devem "
        "ser inventariados e, quando desnecessários, retirados do ar. "
        "E-mails expostos habilitam campanhas de phishing direcionado."
    )
    lines.append("")

    return "\n".join(lines)


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Gera a seção 'Superfície de Ataque' a partir do consolidado OSINT.",
    )
    parser.add_argument("consolidated", help="JSON consolidado do merge.py")
    parser.add_argument("-o", "--output", help="grava a seção .md em arquivo")
    args = parser.parse_args()

    with open(args.consolidated, encoding="utf-8") as fh:
        data = json.load(fh)

    section = build_section(data)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(section)
        print(f"[+] seção gerada → {args.output}", file=sys.stderr)
    else:
        print(section)
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
