#!/usr/bin/env python3
"""
spiderfoot_client.py — Cliente do serviço SpiderFoot para o toolkit.

Fala com o container `spiderfoot` (docker-compose, profile "osint") pela
REST API: dispara o scan, faz polling do status e coleta os resultados,
normalizando a saída no mesmo formato que osint.py produz — subdomains,
emails e sources — para o report.py consumir sem tratamento especial.

Uso avulso:
    python spiderfoot_client.py exemplo.com.br
    python spiderfoot_client.py exemplo.com.br -o sf.json --timeout 900
    SPIDERFOOT_URL=http://localhost:5001 python spiderfoot_client.py alvo.com
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Any, Iterator

import requests

# ----------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------

SPIDERFOOT_URL = os.getenv("SPIDERFOOT_URL", "http://spiderfoot:5001")

HTTP_TIMEOUT = 30
POLL_INTERVAL = 10
SCAN_TIMEOUT = 900
USER_AGENT = "osint-toolkit/1.0"

DEFAULT_MODULES = ",".join([
    "sfp_dnsresolve",
    "sfp_crt",
    "sfp_whois",
    "sfp_subdomain_enum",
    "sfp_email",
    "sfp_dnsbrute",
])

_TYPE_MAP = {
    "INTERNET_NAME": "subdomains",
    "CO_HOSTED_SITE": "subdomains",
    "SIMILARDOMAIN": "subdomains",
    "EMAILADDR": "emails",
    "IP_ADDRESS": "ips",
    "DOMAIN_NAME": "domains",
}


class SpiderFootError(RuntimeError):
    """Falha de comunicação ou de scan no SpiderFoot."""


# ----------------------------------------------------------------------------
# Sessão HTTP
# ----------------------------------------------------------------------------

def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT})
    return s


# ----------------------------------------------------------------------------
# Operações da API
# ----------------------------------------------------------------------------

def start_scan(
    target: str,
    modules: str = DEFAULT_MODULES,
    session: requests.Session | None = None,
) -> str:
    sess = session or _session()
    try:
        r = sess.post(
            f"{SPIDERFOOT_URL}/startscan",
            data={
                "scanname": target,
                "scantarget": target,
                "modulelist": modules,
                "typelist": "",
                "usecase": "",
            },
            timeout=HTTP_TIMEOUT,
        )
        r.raise_for_status()
    except requests.RequestException as exc:
        raise SpiderFootError(f"falha ao iniciar scan: {exc}") from exc

    scan_id = _extract_scan_id(r)
    if not scan_id:
        raise SpiderFootError(f"resposta inesperada do startscan: {r.text[:200]}")
    return scan_id


def _extract_scan_id(resp: requests.Response) -> str | None:
    try:
        data = resp.json()
        if isinstance(data, list) and len(data) >= 2 and data[0] == "SUCCESS":
            return str(data[1])
    except ValueError:
        pass
    if "id=" in resp.url:
        return resp.url.split("id=", 1)[1].split("&", 1)[0]
    return None


def scan_status(scan_id: str, session: requests.Session | None = None) -> str:
    sess = session or _session()
    try:
        r = sess.get(
            f"{SPIDERFOOT_URL}/scanopts",
            params={"id": scan_id},
            timeout=HTTP_TIMEOUT,
        )
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict):
            return str(data.get("status", "UNKNOWN"))
        if isinstance(data, list) and len(data) > 3:
            return str(data[3])
    except (requests.RequestException, ValueError) as exc:
        raise SpiderFootError(f"falha ao consultar status: {exc}") from exc
    return "UNKNOWN"


def scan_results(scan_id: str, session: requests.Session | None = None) -> list[list[Any]]:
    sess = session or _session()
    try:
        r = sess.get(
            f"{SPIDERFOOT_URL}/scaneventresultexport",
            params={"id": scan_id, "type": "ALL", "dialect": "json"},
            timeout=HTTP_TIMEOUT,
        )
        r.raise_for_status()
        return r.json()
    except (requests.RequestException, ValueError) as exc:
        raise SpiderFootError(f"falha ao exportar resultados: {exc}") from exc


# ----------------------------------------------------------------------------
# Polling
# ----------------------------------------------------------------------------

def wait(
    scan_id: str,
    timeout: int = SCAN_TIMEOUT,
    interval: int = POLL_INTERVAL,
    session: requests.Session | None = None,
) -> Iterator[dict[str, Any]]:
    sess = session or _session()
    started = time.monotonic()
    terminal = {"FINISHED", "ABORTED", "ERROR-FAILED", "FAILED"}

    while True:
        status = scan_status(scan_id, sess)
        elapsed = round(time.monotonic() - started)
        yield {"type": "status", "scan_id": scan_id,
               "status": status, "elapsed": elapsed}

        if status in terminal:
            yield {"type": "done", "scan_id": scan_id, "status": status}
            return
        if elapsed >= timeout:
            raise SpiderFootError(
                f"scan {scan_id} não terminou em {timeout}s (último: {status})"
            )
        time.sleep(interval)


# ----------------------------------------------------------------------------
# Normalização
# ----------------------------------------------------------------------------

def normalize(target: str, raw_events: list[list[Any]]) -> dict[str, Any]:
    buckets: dict[str, set[str]] = {v: set() for v in set(_TYPE_MAP.values())}
    by_module: dict[str, int] = {}

    for row in raw_events:
        if not isinstance(row, list) or len(row) < 4:
            continue
        event_type = next((c for c in row if c in _TYPE_MAP), None)
        if event_type is None:
            continue
        value = str(row[1]).strip().lower() if len(row) > 1 else ""
        module = str(row[2]) if len(row) > 2 else "?"
        if not value:
            continue

        key = _TYPE_MAP[event_type]
        if key in ("subdomains", "domains") and not value.endswith(target):
            continue
        buckets[key].add(value)
        by_module[module] = by_module.get(module, 0) + 1

    subdomains = sorted(buckets.get("subdomains", set()))
    emails = sorted(buckets.get("emails", set()))

    return {
        "target": target,
        "subdomains": subdomains,
        "emails": emails,
        "sources": {
            "spiderfoot": {
                "source": "spiderfoot",
                "status": "ok",
                "detail": "",
                "data": {
                    "subdomains": subdomains,
                    "emails": emails,
                    "ips": sorted(buckets.get("ips", set())),
                    "domains": sorted(buckets.get("domains", set())),
                    "events_por_modulo": by_module,
                },
            }
        },
    }


# ----------------------------------------------------------------------------
# Orquestração de alto nível
# ----------------------------------------------------------------------------

def run(
    target: str,
    modules: str = DEFAULT_MODULES,
    timeout: int = SCAN_TIMEOUT,
    progress: bool = False,
) -> dict[str, Any]:
    sess = _session()
    scan_id = start_scan(target, modules, sess)
    if progress:
        print(f"[+] scan iniciado: {scan_id}", file=sys.stderr)

    final_status = "UNKNOWN"
    for evt in wait(scan_id, timeout=timeout, session=sess):
        if evt["type"] == "status" and progress:
            print(f"    {evt['status']} ({evt['elapsed']}s)", file=sys.stderr)
        if evt["type"] == "done":
            final_status = evt["status"]

    if final_status != "FINISHED":
        raise SpiderFootError(f"scan terminou como {final_status}")

    raw = scan_results(scan_id, sess)
    result = normalize(target, raw)
    result["sources"]["spiderfoot"]["data"]["scan_id"] = scan_id
    return result


def run_stream(
    target: str,
    modules: str = DEFAULT_MODULES,
    timeout: int = SCAN_TIMEOUT,
) -> Iterator[dict[str, Any]]:
    sess = _session()
    scan_id = start_scan(target, modules, sess)
    yield {"type": "scan_started", "scan_id": scan_id, "target": target}

    final_status = "UNKNOWN"
    for evt in wait(scan_id, timeout=timeout, session=sess):
        yield evt
        if evt["type"] == "done":
            final_status = evt["status"]

    if final_status != "FINISHED":
        yield {"type": "error", "scan_id": scan_id, "status": final_status}
        return

    raw = scan_results(scan_id, sess)
    result = normalize(target, raw)
    result["sources"]["spiderfoot"]["data"]["scan_id"] = scan_id
    yield {"type": "summary", **result}


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Dispara e coleta um scan OSINT no SpiderFoot.",
    )
    parser.add_argument("target", help="domínio/alvo, ex.: exemplo.com.br")
    parser.add_argument("-o", "--output", help="grava o JSON em arquivo")
    parser.add_argument("-m", "--modules", default=DEFAULT_MODULES,
                        help="lista de módulos separada por vírgula")
    parser.add_argument("--timeout", type=int, default=SCAN_TIMEOUT,
                        help=f"teto do scan em segundos (padrão {SCAN_TIMEOUT})")
    args = parser.parse_args()

    try:
        result = run(args.target, modules=args.modules,
                     timeout=args.timeout, progress=True)
    except SpiderFootError as exc:
        print(f"[!] {exc}", file=sys.stderr)
        return 1

    payload = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(payload)
        print(f"[+] {result['target']}: "
              f"{len(result['subdomains'])} subdomínios, "
              f"{len(result['emails'])} e-mails → {args.output}",
              file=sys.stderr)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
