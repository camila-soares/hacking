#!/usr/bin/env python3
"""
merge.py — Unifica resultados OSINT de múltiplas fontes por alvo.

Recebe um ou mais dicts no schema comum produzido por osint.py e
spiderfoot_client.py e devolve um único dict consolidado.

Uso avulso:
    python merge.py osint.json spiderfoot.json -o consolidado.json
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any


def _as_list(value: Any) -> list[str]:
    if not value:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v).strip().lower() for v in value if str(v).strip()]
    return [str(value).strip().lower()]


def _subdomains_of_source(entry: dict[str, Any]) -> set[str]:
    data = entry.get("data", {}) or {}
    found: set[str] = set()
    found.update(_as_list(data.get("subdomains")))
    found.update(_as_list(data.get("hosts")))
    found.update(_as_list(data.get("domains")))
    return found


def merge(*results: dict[str, Any]) -> dict[str, Any]:
    results = tuple(r for r in results if r)
    if not results:
        return {"target": None, "subdomains": [], "emails": [],
                "sources": {}, "provenance": {}, "targets": []}

    targets = [r.get("target") for r in results if r.get("target")]
    canonical = targets[0] if targets else None

    all_subs: set[str] = set()
    all_emails: set[str] = set()
    sources: dict[str, Any] = {}
    provenance: dict[str, set[str]] = {}

    for res in results:
        all_subs.update(_as_list(res.get("subdomains")))
        all_emails.update(_as_list(res.get("emails")))

        for name, entry in (res.get("sources") or {}).items():
            if not isinstance(entry, dict):
                continue
            key = name
            n = 2
            while key in sources and sources[key] != entry:
                key = f"{name}#{n}"
                n += 1
            sources[key] = entry

            for sub in _subdomains_of_source(entry):
                provenance.setdefault(sub, set()).add(entry.get("source", name))

    if canonical:
        all_subs = {s for s in all_subs if s.endswith(canonical)}
        provenance = {s: v for s, v in provenance.items() if s.endswith(canonical)}

    return {
        "target": canonical,
        "targets": sorted(set(targets)),
        "subdomains": sorted(all_subs),
        "emails": sorted(all_emails),
        "sources": sources,
        "provenance": {s: sorted(v) for s, v in sorted(provenance.items())},
        "stats": {
            "total_subdomains": len(all_subs),
            "total_emails": len(all_emails),
            "fontes": sorted(sources.keys()),
            "corroborados": sum(1 for v in provenance.values() if len(v) > 1),
        },
    }


def merge_files(paths: list[str]) -> dict[str, Any]:
    loaded: list[dict[str, Any]] = []
    for p in paths:
        with open(p, encoding="utf-8") as fh:
            loaded.append(json.load(fh))
    return merge(*loaded)


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Consolida resultados OSINT de múltiplas fontes.",
    )
    parser.add_argument("files", nargs="+",
                        help="JSONs gerados por osint.py / spiderfoot_client.py")
    parser.add_argument("-o", "--output", help="grava o JSON consolidado")
    args = parser.parse_args()

    result = merge_files(args.files)
    payload = json.dumps(result, indent=2, ensure_ascii=False)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(payload)
        st = result["stats"]
        print(f"[+] {result['target']}: {st['total_subdomains']} subdomínios "
              f"({st['corroborados']} corroborados por 2+ fontes), "
              f"{st['total_emails']} e-mails → {args.output}",
              file=sys.stderr)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
