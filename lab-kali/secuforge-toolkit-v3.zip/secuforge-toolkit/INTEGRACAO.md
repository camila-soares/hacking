# Integração OSINT no Bug Bounty Toolkit

Pacote com os módulos OSINT enxutos + arquivos de infraestrutura já ajustados
ao toolkit real (serviço único `toolkit`, porta 8080, Dockerfile Ubuntu/root).

## Conteúdo

| Arquivo | O que é |
|---|---|
| `osint.py` | Coleta enxuta: **crt.sh** (cert transparency) + **theHarvester** (e-mails). |
| `spiderfoot_client.py` | Cliente do serviço SpiderFoot (scan profundo sob demanda). |
| `merge.py` | Consolida OSINT + recon num único resultado, com proveniência. |
| `attack_surface.py` | Gera a seção "Superfície de Ataque" (Markdown) a partir do consolidado. |
| `laudo.py` | Laudo de pentest em PDF (report.py renomeado). |
| `docker-compose.yml` | Compose + serviço `spiderfoot` opcional (profile `osint`). |

## Como aplicar

1. **Copie os 5 `.py`** para a raiz do toolkit (ao lado de `recon-full.sh`):
   `osint.py spiderfoot_client.py merge.py attack_surface.py laudo.py`

2. **Substitua** `docker-compose.yml` pelos deste pacote.

3. **Ligue o OSINT no fluxo do scan** — em `api.py`, dentro de
   `_executar_scan`, logo após encontrar `output_dir` e antes do report:

   ```python
   import osint, json
   try:
       _log(scan_id, "[→] OSINT (crt.sh + theHarvester)...")
       dados = osint.collect(dominio)
       (output_dir / "osint.json").write_text(
           json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
       _log(scan_id, f"[✔] OSINT: {len(dados['subdomains'])} subs, "
                     f"{len(dados['emails'])} e-mails")
   except Exception as e:
       _log(scan_id, f"[!] OSINT: {e}")
   ```

4. **Build e validação:**
   ```bash
   docker compose build
   docker compose run --rm --entrypoint python3 toolkit osint.py exemplo.com.br
   docker compose --profile osint up -d spiderfoot
   docker compose run --rm --entrypoint python3 toolkit spiderfoot_client.py exemplo.com.br
   ```

## Nota de escopo

Só rode contra alvos com autorização escrita (art. 154-A CP). O OSINT aqui é
passivo, mas ao atender empresas mantenha a coleta dentro do escopo do termo.
